/****************************************************************************
** Meta object code from reading C++ file 'NGTreeWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Dialog/NGTreeWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'NGTreeWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_NGTreeWidget_t {
    QByteArrayData data[23];
    char stringdata0[522];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NGTreeWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NGTreeWidget_t qt_meta_stringdata_NGTreeWidget = {
    {
QT_MOC_LITERAL(0, 0, 12), // "NGTreeWidget"
QT_MOC_LITERAL(1, 13, 17), // "ActiveTree_Signal"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 18), // "CompareTree_Signal"
QT_MOC_LITERAL(4, 51, 24), // "ToggleTreeVisible_Signal"
QT_MOC_LITERAL(5, 76, 15), // "GotoDiff_Signal"
QT_MOC_LITERAL(6, 92, 26), // "ToggleShowDiffArrow_Signal"
QT_MOC_LITERAL(7, 119, 20), // "ResetTraverse_Signal"
QT_MOC_LITERAL(8, 140, 29), // "ToggleShowTraverseFlag_Signal"
QT_MOC_LITERAL(9, 170, 35), // "ParallelTrace_DisplayARegion_..."
QT_MOC_LITERAL(10, 206, 31), // "ParallelTrace_ReviseTree_Signal"
QT_MOC_LITERAL(11, 238, 30), // "ParallelTrace_ResetMODE_Signal"
QT_MOC_LITERAL(12, 269, 17), // "ActivateTree_Slot"
QT_MOC_LITERAL(13, 287, 16), // "CompareTree_Slot"
QT_MOC_LITERAL(14, 304, 22), // "ToggleTreeVisible_Slot"
QT_MOC_LITERAL(15, 327, 13), // "GotoDiff_Slot"
QT_MOC_LITERAL(16, 341, 24), // "TriggeredCheckState_Slot"
QT_MOC_LITERAL(17, 366, 19), // "DeleteAnnotate_Slot"
QT_MOC_LITERAL(18, 386, 24), // "ToggleShowDiffArrow_Slot"
QT_MOC_LITERAL(19, 411, 18), // "ResetTraverse_Slot"
QT_MOC_LITERAL(20, 430, 27), // "ToggleShowTraverseFlag_Slot"
QT_MOC_LITERAL(21, 458, 33), // "ParallelTrace_DisplayARegion_..."
QT_MOC_LITERAL(22, 492, 29) // "ParallelTrace_ReviseTree_Slot"

    },
    "NGTreeWidget\0ActiveTree_Signal\0\0"
    "CompareTree_Signal\0ToggleTreeVisible_Signal\0"
    "GotoDiff_Signal\0ToggleShowDiffArrow_Signal\0"
    "ResetTraverse_Signal\0ToggleShowTraverseFlag_Signal\0"
    "ParallelTrace_DisplayARegion_Signal\0"
    "ParallelTrace_ReviseTree_Signal\0"
    "ParallelTrace_ResetMODE_Signal\0"
    "ActivateTree_Slot\0CompareTree_Slot\0"
    "ToggleTreeVisible_Slot\0GotoDiff_Slot\0"
    "TriggeredCheckState_Slot\0DeleteAnnotate_Slot\0"
    "ToggleShowDiffArrow_Slot\0ResetTraverse_Slot\0"
    "ToggleShowTraverseFlag_Slot\0"
    "ParallelTrace_DisplayARegion_Slot\0"
    "ParallelTrace_ReviseTree_Slot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NGTreeWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  119,    2, 0x06 /* Public */,
       3,    1,  122,    2, 0x06 /* Public */,
       4,    1,  125,    2, 0x06 /* Public */,
       5,    1,  128,    2, 0x06 /* Public */,
       6,    1,  131,    2, 0x06 /* Public */,
       7,    0,  134,    2, 0x06 /* Public */,
       8,    0,  135,    2, 0x06 /* Public */,
       9,    3,  136,    2, 0x06 /* Public */,
      10,    0,  143,    2, 0x06 /* Public */,
      11,    0,  144,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    0,  145,    2, 0x0a /* Public */,
      13,    0,  146,    2, 0x0a /* Public */,
      14,    0,  147,    2, 0x0a /* Public */,
      15,    0,  148,    2, 0x0a /* Public */,
      16,    0,  149,    2, 0x0a /* Public */,
      17,    0,  150,    2, 0x0a /* Public */,
      18,    1,  151,    2, 0x0a /* Public */,
      19,    0,  154,    2, 0x0a /* Public */,
      20,    0,  155,    2, 0x0a /* Public */,
      21,    0,  156,    2, 0x0a /* Public */,
      22,    0,  157,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void NGTreeWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        NGTreeWidget *_t = static_cast<NGTreeWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ActiveTree_Signal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->CompareTree_Signal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->ToggleTreeVisible_Signal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->GotoDiff_Signal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->ToggleShowDiffArrow_Signal((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->ResetTraverse_Signal(); break;
        case 6: _t->ToggleShowTraverseFlag_Signal(); break;
        case 7: _t->ParallelTrace_DisplayARegion_Signal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 8: _t->ParallelTrace_ReviseTree_Signal(); break;
        case 9: _t->ParallelTrace_ResetMODE_Signal(); break;
        case 10: _t->ActivateTree_Slot(); break;
        case 11: _t->CompareTree_Slot(); break;
        case 12: _t->ToggleTreeVisible_Slot(); break;
        case 13: _t->GotoDiff_Slot(); break;
        case 14: _t->TriggeredCheckState_Slot(); break;
        case 15: _t->DeleteAnnotate_Slot(); break;
        case 16: _t->ToggleShowDiffArrow_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->ResetTraverse_Slot(); break;
        case 18: _t->ToggleShowTraverseFlag_Slot(); break;
        case 19: _t->ParallelTrace_DisplayARegion_Slot(); break;
        case 20: _t->ParallelTrace_ReviseTree_Slot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (NGTreeWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ActiveTree_Signal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::CompareTree_Signal)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ToggleTreeVisible_Signal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::GotoDiff_Signal)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ToggleShowDiffArrow_Signal)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ResetTraverse_Signal)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ToggleShowTraverseFlag_Signal)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)(int , int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ParallelTrace_DisplayARegion_Signal)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ParallelTrace_ReviseTree_Signal)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (NGTreeWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NGTreeWidget::ParallelTrace_ResetMODE_Signal)) {
                *result = 9;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject NGTreeWidget::staticMetaObject = {
    { &QTreeWidget::staticMetaObject, qt_meta_stringdata_NGTreeWidget.data,
      qt_meta_data_NGTreeWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *NGTreeWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NGTreeWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NGTreeWidget.stringdata0))
        return static_cast<void*>(this);
    return QTreeWidget::qt_metacast(_clname);
}

int NGTreeWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void NGTreeWidget::ActiveTree_Signal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void NGTreeWidget::CompareTree_Signal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void NGTreeWidget::ToggleTreeVisible_Signal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void NGTreeWidget::GotoDiff_Signal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void NGTreeWidget::ToggleShowDiffArrow_Signal(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void NGTreeWidget::ResetTraverse_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void NGTreeWidget::ToggleShowTraverseFlag_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void NGTreeWidget::ParallelTrace_DisplayARegion_Signal(int _t1, int _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void NGTreeWidget::ParallelTrace_ReviseTree_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void NGTreeWidget::ParallelTrace_ResetMODE_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
