#pragma once
#include <QDialog>
#include <QString>


namespace Ui {
	class CalcRadiusDialog;
}

class CalcRadiusDialog : public QDialog
{
	Q_OBJECT

public:
	explicit CalcRadiusDialog(QWidget *parent = 0);
	~CalcRadiusDialog();
	const QString GetOpenImageName() const;
	const QString GetOpenSwcListName() const;
	const QString GetSaveDir() const;
	const QString GetSavePre() const;
	void GetResolution(double *xres, double *yres, double *zres);
private slots:

	void on_openImgButton_clicked();
	void on_openSwcListButton_clicked();
	void on_openSaveDirButton_clicked();
private:
	Ui::CalcRadiusDialog *ui;
	QString oldDirPath_;
};

