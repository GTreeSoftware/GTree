/**
 * @file ineuronio.h
 * @brief Pure virtual class for data I/O class
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef INEURONIO_H
#define INEURONIO_H

#include "ineuronprocessobject.h"
struct ParamPack;
NG_SMART_POINTER_TYPEDEF(ParamPack, NGParamPack);
/**
* @brief Pure virtual class for data I/O class
* Pure virtual class for data I/O class. All of data read/write class will inherit this class.
*/
class INeuronIO : public INeuronProcessObject
{
public:
    virtual ~INeuronIO(){}
    virtual bool SetInputFileName(const std::string&)=0;
    virtual bool SetOutputFileName(const std::string&)=0;
};

class INeuronBigReader : public INeuronIO
{
public:
    virtual ~INeuronBigReader(){}
	/**
	* @brief Virtual function for importing the wrapper of common paramters and data.
	* param arg The wrapper of common paramters and data.
	*
	* @return void.
	*/
    virtual void SetParam(NGParamPack arg)=0;//TODO:
    virtual void GetMaxRange(int& x, int& y, int& z)=0;
    virtual DATATYPE GetImageType()const=0;
};

#endif // INEURONIO_H
