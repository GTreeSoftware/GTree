/**
 * @file imagereader.h
 * @brief Implementation class for reading single tiff image.
 * @details Implementation class for reading 8bit and 16bit single tiff image.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef IMAGEREADER_H
#define IMAGEREADER_H
#include <memory>
#include <string>
#include "../ineuronio.h"
#include "../../ngtypes/ParamPack.h"
template<typename T> class Volume;
typedef Volume<unsigned char> CVolume;
typedef Volume<unsigned short> SVolume;
class INeuronDateObject;
class ImageReader;

typedef std::shared_ptr<ImageReader> NGImageReader;
/**
* @brief Implementation class for reading tiff image.
*  It can read 8bit and 16bit single tiff image. The dependency library is libtiff.
*/
class ImageReader : public INeuronIO
{
public:
    typedef std::shared_ptr<SVolume> VolumePointer;
    static NGImageReader New(){return NGImageReader(new ImageReader());}

    ImageReader();
    ~ImageReader();
    INEURONPROCESSOBJECT_DEFINE
    bool SetInputFileName(const std::string&);
    void SetParam(NGParamPack arg){paramPack = arg;}
    bool GetImageInfo(const std::string&);//save information into paramPack
    DATATYPE GetImageType()const{ return dataType; }
    
protected:
	/**
	* @brief Forbidden.
	*/
    void SetInput(ConstIDataPointer&){}
	/**
	* @brief Forbidden.
	*/
    bool SetOutputFileName(const std::string&){ return false; }
	/**
	* @brief The implementation of reading tiff image.
	* @param name The path of target single tiff image.
	* @return The reading status.
	*/
    bool ReadImage(const char* name);
    
private:
    bool isFileValid;
    std::string filename; //read path
    DATATYPE dataType;
    NGParamPack paramPack;
};

#endif // IMAGEREADER_H
