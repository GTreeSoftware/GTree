/**
 * @file SampleMaker.h
 * @brief Make sub-block samples from big data files (mostd and hdf5).
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#pragma once
#include <QtGui>
#include <QtWidgets>
#include <QWidget>
#include "ngtypes/basetypes.h"
#include "ngtypes/ineurondataobject.h"
#include "ngtypes/ParamPack.h"

class SampleMaker;
class INeuronBigReader;
NG_SMART_POINTER_TYPEDEF(SampleMaker, NGSampleMaker);
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);

namespace Ui {
	class SampleMakerWidget;
}
/**
* @brief The function class for making sub-block samples from big data files (mostd and hdf5).
* Deprecated.
*/
class SampleMaker : public QWidget
{
	Q_OBJECT
public:
	SampleMaker(QWidget *parent = 0);
	virtual ~SampleMaker();

private slots:
	void on_mostdPathButton_clicked();
	void on_dstPathButton_clicked();
	void on_startButton_clicked();
	void on_stopButton_clicked();
	void on_initTxtButton_clicked();

private:
	Ui::SampleMakerWidget *ui;
	NGNeuronBigReader mostdReader_;
	NGParamPack param_;//dependent
	QString mostdInfo;
	int xMin, xMax, yMin, yMax, zMin, zMax;
	int xMaxRange, yMaxRange, zMaxRange;
	int xBlockSize, yBlockSize, zBlockSize;
	bool Validate();
	bool MakeSamples();
};
