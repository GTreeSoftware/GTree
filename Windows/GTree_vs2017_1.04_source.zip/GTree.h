/**
 * @file GTree.h
 * @brief mainwindow of GTree
 * @details 
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef NEURONTRACER_H
#define NEURONTRACER_H

#include <QMainWindow>
#include <QtGui>
#include <QtWidgets>
#include <QTimer>
#include <ctime>
#include <memory>
#include "creathdf5dialog.h"

#include "ngtypes/basetypes.h"
#include "ngtypes/ineurondataobject.h"
#include "ngtypes/ParamPack.h"
#include "Thread/binarythread.h"
#include "Function/IO/Prestore.h"
#include "Function/IO/DeepTraverse.h"

class BinaryFilter;
class BinarySettingsDockWidget;
class NeuroGLWidget;
class SparseTraceFilter;
class LargeSparseTraceFilter;
class INeuronBigReader;
class TraceStackReader;
class TraceStackWriter;
class HDF5Writer;
class SparseBigDataReader;
NG_SMART_POINTER_TYPEDEF(BinaryFilter, NGBinaryFilter);
NG_SMART_POINTER_TYPEDEF(SparseTraceFilter, NGSparseTraceFilter);
NG_SMART_POINTER_TYPEDEF(LargeSparseTraceFilter, NGLargeSparseTraceFilter);
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
NG_SMART_POINTER_TYPEDEF(std::vector<VectorVec5d>, SMARTTREE);
NG_SMART_POINTER_TYPEDEF(TraceStackReader, NGTraceStackReader);
NG_SMART_POINTER_TYPEDEF(TraceStackWriter, NGTraceStackWriter);
NG_SMART_POINTER_TYPEDEF(HDF5Writer, NGHDF5Writer);

namespace Ui {
	class SparseTracerClass;
}

/**
* @brief Mainwindow class for GTree
* The main GUI of GTree based on Qt. Due to user's operation, correponding function module will be invoked.
*/
class GTree : public QMainWindow
{
	Q_OBJECT

public:
	explicit GTree(QWidget *parent = 0);
	~GTree();

signals:
	void renderCaliber();
	void BuildAllSeparateTreeCaliber_Signal();

private slots:
	void on_actionOpenImage_triggered();
	void on_actionOpenTree_triggered();
	void on_actionSaveTree_triggered();
	void on_actionClear_triggered();
	void on_actionRun_triggered();
	void EndRunThread();
	void on_actionStop_triggered();
	void UpdateStatus_Slot();
	void ApplyReadNewImage_Slot();
	void on_actionSaveImage_triggered();
	void on_actionSaveBack_triggered();
	void on_actionBatchTracing_triggered();
	void on_actionCalcRadius_triggered();
	void on_actionSampleMaker_triggered();
	void UpdateImgResolution_Slot();
	void on_actionBuildAllCaliber_triggered();
	//for big data
	void SetROIByBoxWidget_Slot();
	//Manual Edit
	void on_actionChoose_Line_toggled(bool);
	void on_actionChoose_Vertex_toggled(bool);
	void on_actionDelete_Line_triggered();
	void on_actionCut_Vertex_triggered();
	void on_actionDraw_Line_toggled(bool);
	void on_action2DView_toggled(bool);
	void on_actionZoom_in_triggered();
	void on_actionZoom_out_triggered();
	void on_actionVisible_toggled(bool);
	void on_actionSaveSVM_triggered();
	void ChangeMoveCursor_Slot(bool);//
	void TimingSave_Slot();
	void on_actionPick_Soma_toggled(bool arg);
	void on_actionSelect_Tree_toggled(bool arg);
	void on_actionNGTree_toggled(bool arg);
	void on_actionSBWT_toggled(bool arg);
	void on_actionNGTree_Trace_triggered();
	void on_actionDelete_Soma_triggered();
	void on_actionDelete_Tree_triggered();
	void on_actionTest_triggered();
	void on_actionTest_for_Reconstruction_triggered();
	void EditActionGroup_triggered(QAction *);
	void SetProjectMaxThickness_Slot(int);
	void MaxBoundNumChanged_Slot(int);
	void Set2DViewStatus_Slot(bool);
	void SetDrawStatus_Slot(bool);
	void on_actionTrain_triggered();
	void on_actionTreeChecker_triggered();
	void UpdateGLBoxWidget_Slot();
	void on_actionLocal_Run_triggered();

	void on_actionSaveLayerImage_triggered();
	void on_actionSaveLayerSwc_triggered();
	void ClearMOSTDCache_Slot();//action_ClearCache_Button
	//tree widget
	void ActivateTree_Slot(int arg);
	void CompareTree_Slot(int arg);
	void ToggleTreeVisible_Slot(int);
	void GotoDiff_Slot(int);
	//traverse
	void ToggleTraverse_Slot(bool);
	void BackTraverse_Slot();
	void NextTraverse_Slot();
	void ToggleShowDiffArrow_Slot(bool);
	void StartTraverseFromHere_Slot(int, int);
	void ResetTraverse_Slot();
	//timer
	void on_actionStart_triggered();
	void on_actionHalt_triggered();
	void on_actionReset_triggered();
	void AddRunningTime_Slot();
	//
	void CacheComplete_Slot();
	//Soma operateion
	void on_actionNeuroGPS_triggered();
	void on_actionSaveSoma_triggered();
	void on_actionOpenSoma_triggered();
	//save mid data
	void on_actionSavePreview_triggered();
	void on_actionSaveCaliber_triggered();//2018-3-22
	//visualization operation
	void OpacAdjustApply_Slot();
	void PreviewOpacAdjust_Slot(bool);
	void PreviewBinary_Slot(bool);
	void PreviewAxonBinary_Slot(bool);
	void on_actionSnapshot_triggered();
	//HDF5
	void on_actionCreate_HDF5_triggered();
	void EndCreateHDF5_Slot();
	void UpdateHDF5ProgressBar_Slot(int);
	void StopCreateHDF5_Slot();
	void Test_slot();

protected:
	//auxilary
	bool GetDrawLineIsChecked();
	bool CheckReadImageRangeValid();
	virtual void closeEvent(QCloseEvent * event);
	QString TranslateLayerListIntoText(const std::vector<int>& layerList);
	bool TranslateTextIntoLayerList(const QString&, std::vector<int>& layerList);
	/**
	* @brief Implemention of image reading
	*
	* @return Reading success status.
	*/
	bool ReadImage();
	/**
	* @brief Calculate the image scale ratio according to the resolution ratio. It will be removed.
	*
	* @deprecated
	*
	* @return Void
	*/
	int SetScale(double res);
	/**
	* @brief Clear all data
	*
	* @return Void
	*/
	void ClearAll();
	void ClearAllexceptOrigImage();
	/**
	* @brief Support drag file into software.
	*
	* @param event The event-driven class in Qt.
	* @return Void
	*/
	void dragEnterEvent(QDragEnterEvent * event);
	/**
	* @brief Analysis the dragged file in software.
	*
	* @param event The event-driven class in Qt.
	* @return Void
	*/
	void dropEvent(QDropEvent * event);
	/**
	* @brief The wrapper of image reading.Invoke ReadImage(). Depite image reading, some post processes are invoked.
	*
	* @param arg The target image path.
	* @return The save status.
	*/
	void OpenImageImplement(QString arg);
	/**
	* @brief Save neurons into swc files
	*
	* @param arg The target files to save swc.
	* @return void
	*/
	void OpenTreeImplement(QStringList arg);
	/**
	* @brief Save neurons into swc files
	*
	* @param savePath The target directory to save swc.
	* @return The save status.
	*/
	bool SaveSeperateTreeAsOne(QString savePath);

private:
	Ui::SparseTracerClass *ui;
	QGridLayout *grid;
	QFrame *frame;//style, for beautiful
	QHBoxLayout *frameLayout;
	BinarySettingsDockWidget *settingDock;
	QSplitter* splitter;
	NeuroGLWidget *glbox;
	QActionGroup *toolBarButtonGroup;
	QProgressDialog *progressDialog;
	//! Processing multi-thread.
	BinaryThread *worker;
	//! Manual editing status
	enum EDITTOOLBARTAG { NONE, LINE, VERTEX, BOX, SOMA, TREE, CONNECT, DRAW } oldEditToolbarTag, newEditToolbarTag;
	bool hasSoma_ = true;
	int layerRadiusDisplay_ = 7;
	int sumSteps_;
	int statusTip_;
	int timerForSaveTime_ = 600000;
	QTimer *timer;
	QTimer *runningTimer_;
	clock_t beg, end;
	QString statusString_;
	//Data
	int xScale_, yScale_, zScale_;
	NGParamPack paramPack;
	double boxWidgetBound[6];
	QString imageFileName_;
	QString reconFileName_;
	int traceStepLength_;
	IDataPointer soma;
	IDataPointer resTree_;
	IDataPointer treeConInfo;
	SMARTTREE manualLabelCurve_;
	VectorVec3i binPtSet;
	IDataPointer m_Source;
	/** Binary module */
	NGBinaryFilter filter;
	NGSparseTraceFilter sparseFilter;
	/** Brain-wide tracing module */
	NGLargeSparseTraceFilter largeFilter;
	/** Brain-wide data importing module */
	NGNeuronBigReader mostdReader;
	/** Brain-wide traverse data importing module */
	NGNeuronBigReader mostdTraverseReader;
	std::shared_ptr<SparseBigDataReader> sbdReader;
	/** HDF5 generation module */
	NGHDF5Writer writer;
	//other
	QStringList previousSaveTime_;//date time
	bool traverseMode_ = false;
	bool deepMode_ = false;
	//! Operation mode.
	enum MODE { NORMOLMODE, TRAVERSEMODE, DEEPMODE, REDUCTIONMODE };
	MODE mode_;
	NGPrestore preStore;
	//deep
	NGDeepTraverse deepTraverse;
	QDialog *snapDialog;
};

#endif // NEURONTRACER_H
