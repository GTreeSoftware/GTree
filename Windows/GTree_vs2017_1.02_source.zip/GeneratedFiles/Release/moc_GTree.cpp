/****************************************************************************
** Meta object code from reading C++ file 'GTree.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../GTree.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GTree.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GTree_t {
    QByteArrayData data[82];
    char stringdata0[1971];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GTree_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GTree_t qt_meta_stringdata_GTree = {
    {
QT_MOC_LITERAL(0, 0, 5), // "GTree"
QT_MOC_LITERAL(1, 6, 13), // "renderCaliber"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 34), // "BuildAllSeparateTreeCaliber_S..."
QT_MOC_LITERAL(4, 56, 28), // "on_actionOpenImage_triggered"
QT_MOC_LITERAL(5, 85, 27), // "on_actionSaveTree_triggered"
QT_MOC_LITERAL(6, 113, 24), // "on_actionClear_triggered"
QT_MOC_LITERAL(7, 138, 22), // "on_actionRun_triggered"
QT_MOC_LITERAL(8, 161, 12), // "EndRunThread"
QT_MOC_LITERAL(9, 174, 23), // "on_actionStop_triggered"
QT_MOC_LITERAL(10, 198, 17), // "UpdateStatus_Slot"
QT_MOC_LITERAL(11, 216, 22), // "ApplyReadNewImage_Slot"
QT_MOC_LITERAL(12, 239, 28), // "on_actionSaveImage_triggered"
QT_MOC_LITERAL(13, 268, 27), // "on_actionSaveBack_triggered"
QT_MOC_LITERAL(14, 296, 22), // "SetROIByBoxWidget_Slot"
QT_MOC_LITERAL(15, 319, 28), // "on_actionChoose_Line_toggled"
QT_MOC_LITERAL(16, 348, 30), // "on_actionChoose_Vertex_toggled"
QT_MOC_LITERAL(17, 379, 30), // "on_actionDelete_Line_triggered"
QT_MOC_LITERAL(18, 410, 29), // "on_actionCut_Vertex_triggered"
QT_MOC_LITERAL(19, 440, 26), // "on_actionDraw_Line_toggled"
QT_MOC_LITERAL(20, 467, 23), // "on_action2DView_toggled"
QT_MOC_LITERAL(21, 491, 26), // "on_actionZoom_in_triggered"
QT_MOC_LITERAL(22, 518, 27), // "on_actionZoom_out_triggered"
QT_MOC_LITERAL(23, 546, 24), // "on_actionVisible_toggled"
QT_MOC_LITERAL(24, 571, 26), // "on_actionSaveSVM_triggered"
QT_MOC_LITERAL(25, 598, 21), // "ChangeMoveCursor_Slot"
QT_MOC_LITERAL(26, 620, 15), // "TimingSave_Slot"
QT_MOC_LITERAL(27, 636, 26), // "on_actionPick_Soma_toggled"
QT_MOC_LITERAL(28, 663, 3), // "arg"
QT_MOC_LITERAL(29, 667, 28), // "on_actionSelect_Tree_toggled"
QT_MOC_LITERAL(30, 696, 23), // "on_actionNGTree_toggled"
QT_MOC_LITERAL(31, 720, 21), // "on_actionSBWT_toggled"
QT_MOC_LITERAL(32, 742, 31), // "on_actionNGTree_Trace_triggered"
QT_MOC_LITERAL(33, 774, 30), // "on_actionDelete_Soma_triggered"
QT_MOC_LITERAL(34, 805, 30), // "on_actionDelete_Tree_triggered"
QT_MOC_LITERAL(35, 836, 23), // "on_actionTest_triggered"
QT_MOC_LITERAL(36, 860, 42), // "on_actionTest_for_Reconstruct..."
QT_MOC_LITERAL(37, 903, 25), // "EditActionGroup_triggered"
QT_MOC_LITERAL(38, 929, 8), // "QAction*"
QT_MOC_LITERAL(39, 938, 27), // "SetProjectMaxThickness_Slot"
QT_MOC_LITERAL(40, 966, 23), // "MaxBoundNumChanged_Slot"
QT_MOC_LITERAL(41, 990, 20), // "Set2DViewStatus_Slot"
QT_MOC_LITERAL(42, 1011, 18), // "SetDrawStatus_Slot"
QT_MOC_LITERAL(43, 1030, 24), // "on_actionTrain_triggered"
QT_MOC_LITERAL(44, 1055, 30), // "on_actionTreeChecker_triggered"
QT_MOC_LITERAL(45, 1086, 22), // "UpdateGLBoxWidget_Slot"
QT_MOC_LITERAL(46, 1109, 28), // "on_actionLocal_Run_triggered"
QT_MOC_LITERAL(47, 1138, 33), // "on_actionSaveLayerImage_trigg..."
QT_MOC_LITERAL(48, 1172, 31), // "on_actionSaveLayerSwc_triggered"
QT_MOC_LITERAL(49, 1204, 20), // "ClearMOSTDCache_Slot"
QT_MOC_LITERAL(50, 1225, 17), // "ActivateTree_Slot"
QT_MOC_LITERAL(51, 1243, 16), // "CompareTree_Slot"
QT_MOC_LITERAL(52, 1260, 22), // "ToggleTreeVisible_Slot"
QT_MOC_LITERAL(53, 1283, 13), // "GotoDiff_Slot"
QT_MOC_LITERAL(54, 1297, 19), // "ToggleTraverse_Slot"
QT_MOC_LITERAL(55, 1317, 17), // "BackTraverse_Slot"
QT_MOC_LITERAL(56, 1335, 17), // "NextTraverse_Slot"
QT_MOC_LITERAL(57, 1353, 24), // "ToggleShowDiffArrow_Slot"
QT_MOC_LITERAL(58, 1378, 26), // "StartTraverseFromHere_Slot"
QT_MOC_LITERAL(59, 1405, 18), // "ResetTraverse_Slot"
QT_MOC_LITERAL(60, 1424, 24), // "on_actionStart_triggered"
QT_MOC_LITERAL(61, 1449, 23), // "on_actionHalt_triggered"
QT_MOC_LITERAL(62, 1473, 24), // "on_actionReset_triggered"
QT_MOC_LITERAL(63, 1498, 19), // "AddRunningTime_Slot"
QT_MOC_LITERAL(64, 1518, 18), // "CacheComplete_Slot"
QT_MOC_LITERAL(65, 1537, 27), // "on_actionNeuroGPS_triggered"
QT_MOC_LITERAL(66, 1565, 27), // "on_actionSaveSoma_triggered"
QT_MOC_LITERAL(67, 1593, 27), // "on_actionOpenSoma_triggered"
QT_MOC_LITERAL(68, 1621, 30), // "on_actionSavePreview_triggered"
QT_MOC_LITERAL(69, 1652, 30), // "on_actionSaveCaliber_triggered"
QT_MOC_LITERAL(70, 1683, 20), // "OpacAdjustApply_Slot"
QT_MOC_LITERAL(71, 1704, 22), // "PreviewOpacAdjust_Slot"
QT_MOC_LITERAL(72, 1727, 18), // "PreviewBinary_Slot"
QT_MOC_LITERAL(73, 1746, 22), // "PreviewAxonBinary_Slot"
QT_MOC_LITERAL(74, 1769, 27), // "on_actionSnapshot_triggered"
QT_MOC_LITERAL(75, 1797, 30), // "on_actionCreate_HDF5_triggered"
QT_MOC_LITERAL(76, 1828, 18), // "EndCreateHDF5_Slot"
QT_MOC_LITERAL(77, 1847, 26), // "UpdateHDF5ProgressBar_Slot"
QT_MOC_LITERAL(78, 1874, 19), // "StopCreateHDF5_Slot"
QT_MOC_LITERAL(79, 1894, 9), // "Test_slot"
QT_MOC_LITERAL(80, 1904, 35), // "on_actionBatchProcessFunc_tri..."
QT_MOC_LITERAL(81, 1940, 30) // "on_actionSampleMaker_triggered"

    },
    "GTree\0renderCaliber\0\0"
    "BuildAllSeparateTreeCaliber_Signal\0"
    "on_actionOpenImage_triggered\0"
    "on_actionSaveTree_triggered\0"
    "on_actionClear_triggered\0"
    "on_actionRun_triggered\0EndRunThread\0"
    "on_actionStop_triggered\0UpdateStatus_Slot\0"
    "ApplyReadNewImage_Slot\0"
    "on_actionSaveImage_triggered\0"
    "on_actionSaveBack_triggered\0"
    "SetROIByBoxWidget_Slot\0"
    "on_actionChoose_Line_toggled\0"
    "on_actionChoose_Vertex_toggled\0"
    "on_actionDelete_Line_triggered\0"
    "on_actionCut_Vertex_triggered\0"
    "on_actionDraw_Line_toggled\0"
    "on_action2DView_toggled\0"
    "on_actionZoom_in_triggered\0"
    "on_actionZoom_out_triggered\0"
    "on_actionVisible_toggled\0"
    "on_actionSaveSVM_triggered\0"
    "ChangeMoveCursor_Slot\0TimingSave_Slot\0"
    "on_actionPick_Soma_toggled\0arg\0"
    "on_actionSelect_Tree_toggled\0"
    "on_actionNGTree_toggled\0on_actionSBWT_toggled\0"
    "on_actionNGTree_Trace_triggered\0"
    "on_actionDelete_Soma_triggered\0"
    "on_actionDelete_Tree_triggered\0"
    "on_actionTest_triggered\0"
    "on_actionTest_for_Reconstruction_triggered\0"
    "EditActionGroup_triggered\0QAction*\0"
    "SetProjectMaxThickness_Slot\0"
    "MaxBoundNumChanged_Slot\0Set2DViewStatus_Slot\0"
    "SetDrawStatus_Slot\0on_actionTrain_triggered\0"
    "on_actionTreeChecker_triggered\0"
    "UpdateGLBoxWidget_Slot\0"
    "on_actionLocal_Run_triggered\0"
    "on_actionSaveLayerImage_triggered\0"
    "on_actionSaveLayerSwc_triggered\0"
    "ClearMOSTDCache_Slot\0ActivateTree_Slot\0"
    "CompareTree_Slot\0ToggleTreeVisible_Slot\0"
    "GotoDiff_Slot\0ToggleTraverse_Slot\0"
    "BackTraverse_Slot\0NextTraverse_Slot\0"
    "ToggleShowDiffArrow_Slot\0"
    "StartTraverseFromHere_Slot\0"
    "ResetTraverse_Slot\0on_actionStart_triggered\0"
    "on_actionHalt_triggered\0"
    "on_actionReset_triggered\0AddRunningTime_Slot\0"
    "CacheComplete_Slot\0on_actionNeuroGPS_triggered\0"
    "on_actionSaveSoma_triggered\0"
    "on_actionOpenSoma_triggered\0"
    "on_actionSavePreview_triggered\0"
    "on_actionSaveCaliber_triggered\0"
    "OpacAdjustApply_Slot\0PreviewOpacAdjust_Slot\0"
    "PreviewBinary_Slot\0PreviewAxonBinary_Slot\0"
    "on_actionSnapshot_triggered\0"
    "on_actionCreate_HDF5_triggered\0"
    "EndCreateHDF5_Slot\0UpdateHDF5ProgressBar_Slot\0"
    "StopCreateHDF5_Slot\0Test_slot\0"
    "on_actionBatchProcessFunc_triggered\0"
    "on_actionSampleMaker_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GTree[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      78,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  404,    2, 0x06 /* Public */,
       3,    0,  405,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  406,    2, 0x08 /* Private */,
       5,    0,  407,    2, 0x08 /* Private */,
       6,    0,  408,    2, 0x08 /* Private */,
       7,    0,  409,    2, 0x08 /* Private */,
       8,    0,  410,    2, 0x08 /* Private */,
       9,    0,  411,    2, 0x08 /* Private */,
      10,    0,  412,    2, 0x08 /* Private */,
      11,    0,  413,    2, 0x08 /* Private */,
      12,    0,  414,    2, 0x08 /* Private */,
      13,    0,  415,    2, 0x08 /* Private */,
      14,    0,  416,    2, 0x08 /* Private */,
      15,    1,  417,    2, 0x08 /* Private */,
      16,    1,  420,    2, 0x08 /* Private */,
      17,    0,  423,    2, 0x08 /* Private */,
      18,    0,  424,    2, 0x08 /* Private */,
      19,    1,  425,    2, 0x08 /* Private */,
      20,    1,  428,    2, 0x08 /* Private */,
      21,    0,  431,    2, 0x08 /* Private */,
      22,    0,  432,    2, 0x08 /* Private */,
      23,    1,  433,    2, 0x08 /* Private */,
      24,    0,  436,    2, 0x08 /* Private */,
      25,    1,  437,    2, 0x08 /* Private */,
      26,    0,  440,    2, 0x08 /* Private */,
      27,    1,  441,    2, 0x08 /* Private */,
      29,    1,  444,    2, 0x08 /* Private */,
      30,    1,  447,    2, 0x08 /* Private */,
      31,    1,  450,    2, 0x08 /* Private */,
      32,    0,  453,    2, 0x08 /* Private */,
      33,    0,  454,    2, 0x08 /* Private */,
      34,    0,  455,    2, 0x08 /* Private */,
      35,    0,  456,    2, 0x08 /* Private */,
      36,    0,  457,    2, 0x08 /* Private */,
      37,    1,  458,    2, 0x08 /* Private */,
      39,    1,  461,    2, 0x08 /* Private */,
      40,    1,  464,    2, 0x08 /* Private */,
      41,    1,  467,    2, 0x08 /* Private */,
      42,    1,  470,    2, 0x08 /* Private */,
      43,    0,  473,    2, 0x08 /* Private */,
      44,    0,  474,    2, 0x08 /* Private */,
      45,    0,  475,    2, 0x08 /* Private */,
      46,    0,  476,    2, 0x08 /* Private */,
      47,    0,  477,    2, 0x08 /* Private */,
      48,    0,  478,    2, 0x08 /* Private */,
      49,    0,  479,    2, 0x08 /* Private */,
      50,    1,  480,    2, 0x08 /* Private */,
      51,    1,  483,    2, 0x08 /* Private */,
      52,    1,  486,    2, 0x08 /* Private */,
      53,    1,  489,    2, 0x08 /* Private */,
      54,    1,  492,    2, 0x08 /* Private */,
      55,    0,  495,    2, 0x08 /* Private */,
      56,    0,  496,    2, 0x08 /* Private */,
      57,    1,  497,    2, 0x08 /* Private */,
      58,    2,  500,    2, 0x08 /* Private */,
      59,    0,  505,    2, 0x08 /* Private */,
      60,    0,  506,    2, 0x08 /* Private */,
      61,    0,  507,    2, 0x08 /* Private */,
      62,    0,  508,    2, 0x08 /* Private */,
      63,    0,  509,    2, 0x08 /* Private */,
      64,    0,  510,    2, 0x08 /* Private */,
      65,    0,  511,    2, 0x08 /* Private */,
      66,    0,  512,    2, 0x08 /* Private */,
      67,    0,  513,    2, 0x08 /* Private */,
      68,    0,  514,    2, 0x08 /* Private */,
      69,    0,  515,    2, 0x08 /* Private */,
      70,    0,  516,    2, 0x08 /* Private */,
      71,    1,  517,    2, 0x08 /* Private */,
      72,    1,  520,    2, 0x08 /* Private */,
      73,    1,  523,    2, 0x08 /* Private */,
      74,    0,  526,    2, 0x08 /* Private */,
      75,    0,  527,    2, 0x08 /* Private */,
      76,    0,  528,    2, 0x08 /* Private */,
      77,    1,  529,    2, 0x08 /* Private */,
      78,    0,  532,    2, 0x08 /* Private */,
      79,    0,  533,    2, 0x08 /* Private */,
      80,    0,  534,    2, 0x08 /* Private */,
      81,    0,  535,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   28,
    QMetaType::Void, QMetaType::Bool,   28,
    QMetaType::Void, QMetaType::Bool,   28,
    QMetaType::Void, QMetaType::Bool,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 38,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GTree::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GTree *_t = static_cast<GTree *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->renderCaliber(); break;
        case 1: _t->BuildAllSeparateTreeCaliber_Signal(); break;
        case 2: _t->on_actionOpenImage_triggered(); break;
        case 3: _t->on_actionSaveTree_triggered(); break;
        case 4: _t->on_actionClear_triggered(); break;
        case 5: _t->on_actionRun_triggered(); break;
        case 6: _t->EndRunThread(); break;
        case 7: _t->on_actionStop_triggered(); break;
        case 8: _t->UpdateStatus_Slot(); break;
        case 9: _t->ApplyReadNewImage_Slot(); break;
        case 10: _t->on_actionSaveImage_triggered(); break;
        case 11: _t->on_actionSaveBack_triggered(); break;
        case 12: _t->SetROIByBoxWidget_Slot(); break;
        case 13: _t->on_actionChoose_Line_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->on_actionChoose_Vertex_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->on_actionDelete_Line_triggered(); break;
        case 16: _t->on_actionCut_Vertex_triggered(); break;
        case 17: _t->on_actionDraw_Line_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->on_action2DView_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->on_actionZoom_in_triggered(); break;
        case 20: _t->on_actionZoom_out_triggered(); break;
        case 21: _t->on_actionVisible_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->on_actionSaveSVM_triggered(); break;
        case 23: _t->ChangeMoveCursor_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->TimingSave_Slot(); break;
        case 25: _t->on_actionPick_Soma_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->on_actionSelect_Tree_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->on_actionNGTree_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->on_actionSBWT_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->on_actionNGTree_Trace_triggered(); break;
        case 30: _t->on_actionDelete_Soma_triggered(); break;
        case 31: _t->on_actionDelete_Tree_triggered(); break;
        case 32: _t->on_actionTest_triggered(); break;
        case 33: _t->on_actionTest_for_Reconstruction_triggered(); break;
        case 34: _t->EditActionGroup_triggered((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 35: _t->SetProjectMaxThickness_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->MaxBoundNumChanged_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: _t->Set2DViewStatus_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: _t->SetDrawStatus_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 39: _t->on_actionTrain_triggered(); break;
        case 40: _t->on_actionTreeChecker_triggered(); break;
        case 41: _t->UpdateGLBoxWidget_Slot(); break;
        case 42: _t->on_actionLocal_Run_triggered(); break;
        case 43: _t->on_actionSaveLayerImage_triggered(); break;
        case 44: _t->on_actionSaveLayerSwc_triggered(); break;
        case 45: _t->ClearMOSTDCache_Slot(); break;
        case 46: _t->ActivateTree_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 47: _t->CompareTree_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 48: _t->ToggleTreeVisible_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 49: _t->GotoDiff_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 50: _t->ToggleTraverse_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 51: _t->BackTraverse_Slot(); break;
        case 52: _t->NextTraverse_Slot(); break;
        case 53: _t->ToggleShowDiffArrow_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 54: _t->StartTraverseFromHere_Slot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 55: _t->ResetTraverse_Slot(); break;
        case 56: _t->on_actionStart_triggered(); break;
        case 57: _t->on_actionHalt_triggered(); break;
        case 58: _t->on_actionReset_triggered(); break;
        case 59: _t->AddRunningTime_Slot(); break;
        case 60: _t->CacheComplete_Slot(); break;
        case 61: _t->on_actionNeuroGPS_triggered(); break;
        case 62: _t->on_actionSaveSoma_triggered(); break;
        case 63: _t->on_actionOpenSoma_triggered(); break;
        case 64: _t->on_actionSavePreview_triggered(); break;
        case 65: _t->on_actionSaveCaliber_triggered(); break;
        case 66: _t->OpacAdjustApply_Slot(); break;
        case 67: _t->PreviewOpacAdjust_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 68: _t->PreviewBinary_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 69: _t->PreviewAxonBinary_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 70: _t->on_actionSnapshot_triggered(); break;
        case 71: _t->on_actionCreate_HDF5_triggered(); break;
        case 72: _t->EndCreateHDF5_Slot(); break;
        case 73: _t->UpdateHDF5ProgressBar_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 74: _t->StopCreateHDF5_Slot(); break;
        case 75: _t->Test_slot(); break;
        case 76: _t->on_actionBatchProcessFunc_triggered(); break;
        case 77: _t->on_actionSampleMaker_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 34:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GTree::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GTree::renderCaliber)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GTree::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GTree::BuildAllSeparateTreeCaliber_Signal)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GTree::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_GTree.data,
      qt_meta_data_GTree,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *GTree::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GTree::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GTree.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int GTree::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 78)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 78;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 78)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 78;
    }
    return _id;
}

// SIGNAL 0
void GTree::renderCaliber()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void GTree::BuildAllSeparateTreeCaliber_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
