/**
 * @file Prestore.h
 * @brief Function class for data preload used in traverse mode.
 * @details This class can preload data from MOSTD/TDat file in traverse mode. Cache list and data import thread are introduced.
 * @author Zhou Hang, Chen yijun
 * @license CopyRight Huazhong University of Science and Technology
 */
#ifndef PRESTORE_H
#define PRESTORE_H
#include <QObject>
#include <algorithm>
#include "../../ngtypes/basetypes.h"
#include "../../ngtypes/tree.h"
#include "../ineuronprocessobject.h"
#include "../../ngtypes/ParamPack.h"
#include "../../Thread/binarythread.h"
#include "../ineuronio.h"
#include "../../ngtypes/volume.h"
#include "../../Thread/StoreThread.h"
#include <tuple>

NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
class Prestore;
NG_SMART_POINTER_TYPEDEF(Prestore, NGPrestore);
/**
* @brief Function class for data preload used in traverse mode.
* This class can preload data from MOSTD/TDat file in traverse mode. Cache list and data import thread are introduced.
* In traverse mode, as the traced neurites are known, the subsequent ROIs have been determined.
* Thus a data import thread is running in the backend to preload the subsequent ROI images.
* The cache list is refreshed according to LRU algorithm. 
* 
*/
class Prestore : public QObject, public INeuronProcessObject
{
	Q_OBJECT
public:
	static NGPrestore New(){ return NGPrestore(new Prestore()); };
	Prestore();
	~Prestore();
	/**
	* @brief Deprecated.
	*/
    virtual ProcStatPointer Update(){
        MAKEPROCESSSTATUS(resSta, true, className_, "");
        return resSta;
    }//get image and start read thread 

	
	bool GetNextImage(IDataPointer &arg);//get check start thread
    bool GetPreviousImage(IDataPointer &arg);//get check start thread
	/**
	* @brief Get the current traversed neurite ID.
	*/
	size_t GetCurrentLine(){ return traverseIterCp->curLineID; };
	/**
	* @brief Get the beginning curve node ID of current traversed neurite.
	*/
	size_t GetCurrentpBeg(){ return traverseIterCp->curBeg; };
	/**
	* @brief Get the ending curve node ID of current traversed neurite.
	*/
	size_t GetCurrentpEnd(){ return traverseIterCp->curEnd; };
	/**
	* @brief Deprecated.
	*/
	void AppendNewROI();//check start thread

	size_t GetWaitingROINum(){ return waitingROIDeque_.size(); }
    void SetParam(NGNeuronBigReader arg2, NGParamPack arg3);

	IDataPointer previousImgptr;
	void BackTrace();

    bool Initial();
    bool Finish();
    void Reset();
	/**
	* @brief User can customize the starting position of traverse mode.
	* @param lineID The starting neurite ID number.
	* @param beginNodeID The starting node ID number of the starting neurite.
	*/
    void SetTraversePosition(int lineID, int beginNodeID);

protected slots:
	void EndThread_Slot();
	
signals:
    void CacheComplete_Signal();

protected:
	ConstIDataPointer GetOutput(){ return m_Source; }
	IDataPointer ReleaseData(){ return IDataPointer(new TreeCurve()); }
	bool CheckThreadStart();
	//void PopROI();//
	bool IsImageDequeValid();
	/**
	* @brief Start the data preload backed thread..
	*/
    void StartThread();
	//void applyread();
	
	//void buildFrame();
	void FowardTrace();
	//void calculateRange();
private:
    struct RangeIterator{
        RangeIterator(const tree<LineID>* t, const std::vector<VectorVec5d> *c)
            :treePointer(t), curvePointer(c){}
        ~RangeIterator(){}
        int curBeg = std::numeric_limits<int>::max(), curEnd = 0, curLineID = 0;
        const tree<LineID>* treePointer = NULL;
        const std::vector<VectorVec5d> *curvePointer = NULL;
        tree<LineID>::pre_order_iterator treeIter;
        void Next(int arg);
        void Back(int arg);
    };
    RangeIterator  *traverseIter = NULL;//pre read
    RangeIterator  *traverseIterCp= NULL;//current read
    bool forceThreadStop_ = false;
	Vec6i FrameCoo;
	//size_t curLineID, preLineID;
	int numPoints_ = 40;
    int preBeg = std::numeric_limits<int>::max(), preEnd = 0, preLineID = 0;
	bool firstWork_ = true;
	bool firstWork_2 = true;
    bool directionFlag_ = true;
    int direction_;
	IDataPointer ImageData;
	size_t numBox, readingBox = 0;
	int storageImageMaxNum_ = 3;
	NGParamPack paramPack;
	NGParamPack paramPackCp;
	//VectorVec6i FrameCoordinate;
    NGNeuronBigReader mostdReader;
	std::deque<size_t> waitingROIDeque_;
	std::deque<std::tuple<std::shared_ptr<SVolume>, Vec6i, Vec3i> > imageDeque_;
	//std::deque<std::pair<std::shared_ptr<SVolume>, size_t>> imageDeque_;
	std::shared_ptr<SVolume> recentdata;
	StoreThread* worker;
};

#endif // NEURONPROCESS
