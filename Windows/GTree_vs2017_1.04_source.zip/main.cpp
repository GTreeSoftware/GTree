#include "GTree.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	GTree w;
	w.show();
	return a.exec();
}
