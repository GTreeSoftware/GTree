/****************************************************************************
** Meta object code from reading C++ file 'GTree.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../GTree.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GTree.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GTree_t {
    QByteArrayData data[86];
    char stringdata0[2085];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GTree_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GTree_t qt_meta_stringdata_GTree = {
    {
QT_MOC_LITERAL(0, 0, 5), // "GTree"
QT_MOC_LITERAL(1, 6, 13), // "renderCaliber"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 34), // "BuildAllSeparateTreeCaliber_S..."
QT_MOC_LITERAL(4, 56, 28), // "on_actionOpenImage_triggered"
QT_MOC_LITERAL(5, 85, 27), // "on_actionOpenTree_triggered"
QT_MOC_LITERAL(6, 113, 27), // "on_actionSaveTree_triggered"
QT_MOC_LITERAL(7, 141, 24), // "on_actionClear_triggered"
QT_MOC_LITERAL(8, 166, 22), // "on_actionRun_triggered"
QT_MOC_LITERAL(9, 189, 12), // "EndRunThread"
QT_MOC_LITERAL(10, 202, 23), // "on_actionStop_triggered"
QT_MOC_LITERAL(11, 226, 17), // "UpdateStatus_Slot"
QT_MOC_LITERAL(12, 244, 22), // "ApplyReadNewImage_Slot"
QT_MOC_LITERAL(13, 267, 28), // "on_actionSaveImage_triggered"
QT_MOC_LITERAL(14, 296, 27), // "on_actionSaveBack_triggered"
QT_MOC_LITERAL(15, 324, 31), // "on_actionBatchTracing_triggered"
QT_MOC_LITERAL(16, 356, 29), // "on_actionCalcRadius_triggered"
QT_MOC_LITERAL(17, 386, 30), // "on_actionSampleMaker_triggered"
QT_MOC_LITERAL(18, 417, 24), // "UpdateImgResolution_Slot"
QT_MOC_LITERAL(19, 442, 34), // "on_actionBuildAllCaliber_trig..."
QT_MOC_LITERAL(20, 477, 22), // "SetROIByBoxWidget_Slot"
QT_MOC_LITERAL(21, 500, 28), // "on_actionChoose_Line_toggled"
QT_MOC_LITERAL(22, 529, 30), // "on_actionChoose_Vertex_toggled"
QT_MOC_LITERAL(23, 560, 30), // "on_actionDelete_Line_triggered"
QT_MOC_LITERAL(24, 591, 29), // "on_actionCut_Vertex_triggered"
QT_MOC_LITERAL(25, 621, 26), // "on_actionDraw_Line_toggled"
QT_MOC_LITERAL(26, 648, 23), // "on_action2DView_toggled"
QT_MOC_LITERAL(27, 672, 26), // "on_actionZoom_in_triggered"
QT_MOC_LITERAL(28, 699, 27), // "on_actionZoom_out_triggered"
QT_MOC_LITERAL(29, 727, 24), // "on_actionVisible_toggled"
QT_MOC_LITERAL(30, 752, 26), // "on_actionSaveSVM_triggered"
QT_MOC_LITERAL(31, 779, 21), // "ChangeMoveCursor_Slot"
QT_MOC_LITERAL(32, 801, 15), // "TimingSave_Slot"
QT_MOC_LITERAL(33, 817, 26), // "on_actionPick_Soma_toggled"
QT_MOC_LITERAL(34, 844, 3), // "arg"
QT_MOC_LITERAL(35, 848, 28), // "on_actionSelect_Tree_toggled"
QT_MOC_LITERAL(36, 877, 23), // "on_actionNGTree_toggled"
QT_MOC_LITERAL(37, 901, 21), // "on_actionSBWT_toggled"
QT_MOC_LITERAL(38, 923, 31), // "on_actionNGTree_Trace_triggered"
QT_MOC_LITERAL(39, 955, 30), // "on_actionDelete_Soma_triggered"
QT_MOC_LITERAL(40, 986, 30), // "on_actionDelete_Tree_triggered"
QT_MOC_LITERAL(41, 1017, 23), // "on_actionTest_triggered"
QT_MOC_LITERAL(42, 1041, 42), // "on_actionTest_for_Reconstruct..."
QT_MOC_LITERAL(43, 1084, 25), // "EditActionGroup_triggered"
QT_MOC_LITERAL(44, 1110, 8), // "QAction*"
QT_MOC_LITERAL(45, 1119, 27), // "SetProjectMaxThickness_Slot"
QT_MOC_LITERAL(46, 1147, 23), // "MaxBoundNumChanged_Slot"
QT_MOC_LITERAL(47, 1171, 20), // "Set2DViewStatus_Slot"
QT_MOC_LITERAL(48, 1192, 18), // "SetDrawStatus_Slot"
QT_MOC_LITERAL(49, 1211, 24), // "on_actionTrain_triggered"
QT_MOC_LITERAL(50, 1236, 30), // "on_actionTreeChecker_triggered"
QT_MOC_LITERAL(51, 1267, 22), // "UpdateGLBoxWidget_Slot"
QT_MOC_LITERAL(52, 1290, 28), // "on_actionLocal_Run_triggered"
QT_MOC_LITERAL(53, 1319, 33), // "on_actionSaveLayerImage_trigg..."
QT_MOC_LITERAL(54, 1353, 31), // "on_actionSaveLayerSwc_triggered"
QT_MOC_LITERAL(55, 1385, 20), // "ClearMOSTDCache_Slot"
QT_MOC_LITERAL(56, 1406, 17), // "ActivateTree_Slot"
QT_MOC_LITERAL(57, 1424, 16), // "CompareTree_Slot"
QT_MOC_LITERAL(58, 1441, 22), // "ToggleTreeVisible_Slot"
QT_MOC_LITERAL(59, 1464, 13), // "GotoDiff_Slot"
QT_MOC_LITERAL(60, 1478, 19), // "ToggleTraverse_Slot"
QT_MOC_LITERAL(61, 1498, 17), // "BackTraverse_Slot"
QT_MOC_LITERAL(62, 1516, 17), // "NextTraverse_Slot"
QT_MOC_LITERAL(63, 1534, 24), // "ToggleShowDiffArrow_Slot"
QT_MOC_LITERAL(64, 1559, 26), // "StartTraverseFromHere_Slot"
QT_MOC_LITERAL(65, 1586, 18), // "ResetTraverse_Slot"
QT_MOC_LITERAL(66, 1605, 24), // "on_actionStart_triggered"
QT_MOC_LITERAL(67, 1630, 23), // "on_actionHalt_triggered"
QT_MOC_LITERAL(68, 1654, 24), // "on_actionReset_triggered"
QT_MOC_LITERAL(69, 1679, 19), // "AddRunningTime_Slot"
QT_MOC_LITERAL(70, 1699, 18), // "CacheComplete_Slot"
QT_MOC_LITERAL(71, 1718, 27), // "on_actionNeuroGPS_triggered"
QT_MOC_LITERAL(72, 1746, 27), // "on_actionSaveSoma_triggered"
QT_MOC_LITERAL(73, 1774, 27), // "on_actionOpenSoma_triggered"
QT_MOC_LITERAL(74, 1802, 30), // "on_actionSavePreview_triggered"
QT_MOC_LITERAL(75, 1833, 30), // "on_actionSaveCaliber_triggered"
QT_MOC_LITERAL(76, 1864, 20), // "OpacAdjustApply_Slot"
QT_MOC_LITERAL(77, 1885, 22), // "PreviewOpacAdjust_Slot"
QT_MOC_LITERAL(78, 1908, 18), // "PreviewBinary_Slot"
QT_MOC_LITERAL(79, 1927, 22), // "PreviewAxonBinary_Slot"
QT_MOC_LITERAL(80, 1950, 27), // "on_actionSnapshot_triggered"
QT_MOC_LITERAL(81, 1978, 30), // "on_actionCreate_HDF5_triggered"
QT_MOC_LITERAL(82, 2009, 18), // "EndCreateHDF5_Slot"
QT_MOC_LITERAL(83, 2028, 26), // "UpdateHDF5ProgressBar_Slot"
QT_MOC_LITERAL(84, 2055, 19), // "StopCreateHDF5_Slot"
QT_MOC_LITERAL(85, 2075, 9) // "Test_slot"

    },
    "GTree\0renderCaliber\0\0"
    "BuildAllSeparateTreeCaliber_Signal\0"
    "on_actionOpenImage_triggered\0"
    "on_actionOpenTree_triggered\0"
    "on_actionSaveTree_triggered\0"
    "on_actionClear_triggered\0"
    "on_actionRun_triggered\0EndRunThread\0"
    "on_actionStop_triggered\0UpdateStatus_Slot\0"
    "ApplyReadNewImage_Slot\0"
    "on_actionSaveImage_triggered\0"
    "on_actionSaveBack_triggered\0"
    "on_actionBatchTracing_triggered\0"
    "on_actionCalcRadius_triggered\0"
    "on_actionSampleMaker_triggered\0"
    "UpdateImgResolution_Slot\0"
    "on_actionBuildAllCaliber_triggered\0"
    "SetROIByBoxWidget_Slot\0"
    "on_actionChoose_Line_toggled\0"
    "on_actionChoose_Vertex_toggled\0"
    "on_actionDelete_Line_triggered\0"
    "on_actionCut_Vertex_triggered\0"
    "on_actionDraw_Line_toggled\0"
    "on_action2DView_toggled\0"
    "on_actionZoom_in_triggered\0"
    "on_actionZoom_out_triggered\0"
    "on_actionVisible_toggled\0"
    "on_actionSaveSVM_triggered\0"
    "ChangeMoveCursor_Slot\0TimingSave_Slot\0"
    "on_actionPick_Soma_toggled\0arg\0"
    "on_actionSelect_Tree_toggled\0"
    "on_actionNGTree_toggled\0on_actionSBWT_toggled\0"
    "on_actionNGTree_Trace_triggered\0"
    "on_actionDelete_Soma_triggered\0"
    "on_actionDelete_Tree_triggered\0"
    "on_actionTest_triggered\0"
    "on_actionTest_for_Reconstruction_triggered\0"
    "EditActionGroup_triggered\0QAction*\0"
    "SetProjectMaxThickness_Slot\0"
    "MaxBoundNumChanged_Slot\0Set2DViewStatus_Slot\0"
    "SetDrawStatus_Slot\0on_actionTrain_triggered\0"
    "on_actionTreeChecker_triggered\0"
    "UpdateGLBoxWidget_Slot\0"
    "on_actionLocal_Run_triggered\0"
    "on_actionSaveLayerImage_triggered\0"
    "on_actionSaveLayerSwc_triggered\0"
    "ClearMOSTDCache_Slot\0ActivateTree_Slot\0"
    "CompareTree_Slot\0ToggleTreeVisible_Slot\0"
    "GotoDiff_Slot\0ToggleTraverse_Slot\0"
    "BackTraverse_Slot\0NextTraverse_Slot\0"
    "ToggleShowDiffArrow_Slot\0"
    "StartTraverseFromHere_Slot\0"
    "ResetTraverse_Slot\0on_actionStart_triggered\0"
    "on_actionHalt_triggered\0"
    "on_actionReset_triggered\0AddRunningTime_Slot\0"
    "CacheComplete_Slot\0on_actionNeuroGPS_triggered\0"
    "on_actionSaveSoma_triggered\0"
    "on_actionOpenSoma_triggered\0"
    "on_actionSavePreview_triggered\0"
    "on_actionSaveCaliber_triggered\0"
    "OpacAdjustApply_Slot\0PreviewOpacAdjust_Slot\0"
    "PreviewBinary_Slot\0PreviewAxonBinary_Slot\0"
    "on_actionSnapshot_triggered\0"
    "on_actionCreate_HDF5_triggered\0"
    "EndCreateHDF5_Slot\0UpdateHDF5ProgressBar_Slot\0"
    "StopCreateHDF5_Slot\0Test_slot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GTree[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      82,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  424,    2, 0x06 /* Public */,
       3,    0,  425,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  426,    2, 0x08 /* Private */,
       5,    0,  427,    2, 0x08 /* Private */,
       6,    0,  428,    2, 0x08 /* Private */,
       7,    0,  429,    2, 0x08 /* Private */,
       8,    0,  430,    2, 0x08 /* Private */,
       9,    0,  431,    2, 0x08 /* Private */,
      10,    0,  432,    2, 0x08 /* Private */,
      11,    0,  433,    2, 0x08 /* Private */,
      12,    0,  434,    2, 0x08 /* Private */,
      13,    0,  435,    2, 0x08 /* Private */,
      14,    0,  436,    2, 0x08 /* Private */,
      15,    0,  437,    2, 0x08 /* Private */,
      16,    0,  438,    2, 0x08 /* Private */,
      17,    0,  439,    2, 0x08 /* Private */,
      18,    0,  440,    2, 0x08 /* Private */,
      19,    0,  441,    2, 0x08 /* Private */,
      20,    0,  442,    2, 0x08 /* Private */,
      21,    1,  443,    2, 0x08 /* Private */,
      22,    1,  446,    2, 0x08 /* Private */,
      23,    0,  449,    2, 0x08 /* Private */,
      24,    0,  450,    2, 0x08 /* Private */,
      25,    1,  451,    2, 0x08 /* Private */,
      26,    1,  454,    2, 0x08 /* Private */,
      27,    0,  457,    2, 0x08 /* Private */,
      28,    0,  458,    2, 0x08 /* Private */,
      29,    1,  459,    2, 0x08 /* Private */,
      30,    0,  462,    2, 0x08 /* Private */,
      31,    1,  463,    2, 0x08 /* Private */,
      32,    0,  466,    2, 0x08 /* Private */,
      33,    1,  467,    2, 0x08 /* Private */,
      35,    1,  470,    2, 0x08 /* Private */,
      36,    1,  473,    2, 0x08 /* Private */,
      37,    1,  476,    2, 0x08 /* Private */,
      38,    0,  479,    2, 0x08 /* Private */,
      39,    0,  480,    2, 0x08 /* Private */,
      40,    0,  481,    2, 0x08 /* Private */,
      41,    0,  482,    2, 0x08 /* Private */,
      42,    0,  483,    2, 0x08 /* Private */,
      43,    1,  484,    2, 0x08 /* Private */,
      45,    1,  487,    2, 0x08 /* Private */,
      46,    1,  490,    2, 0x08 /* Private */,
      47,    1,  493,    2, 0x08 /* Private */,
      48,    1,  496,    2, 0x08 /* Private */,
      49,    0,  499,    2, 0x08 /* Private */,
      50,    0,  500,    2, 0x08 /* Private */,
      51,    0,  501,    2, 0x08 /* Private */,
      52,    0,  502,    2, 0x08 /* Private */,
      53,    0,  503,    2, 0x08 /* Private */,
      54,    0,  504,    2, 0x08 /* Private */,
      55,    0,  505,    2, 0x08 /* Private */,
      56,    1,  506,    2, 0x08 /* Private */,
      57,    1,  509,    2, 0x08 /* Private */,
      58,    1,  512,    2, 0x08 /* Private */,
      59,    1,  515,    2, 0x08 /* Private */,
      60,    1,  518,    2, 0x08 /* Private */,
      61,    0,  521,    2, 0x08 /* Private */,
      62,    0,  522,    2, 0x08 /* Private */,
      63,    1,  523,    2, 0x08 /* Private */,
      64,    2,  526,    2, 0x08 /* Private */,
      65,    0,  531,    2, 0x08 /* Private */,
      66,    0,  532,    2, 0x08 /* Private */,
      67,    0,  533,    2, 0x08 /* Private */,
      68,    0,  534,    2, 0x08 /* Private */,
      69,    0,  535,    2, 0x08 /* Private */,
      70,    0,  536,    2, 0x08 /* Private */,
      71,    0,  537,    2, 0x08 /* Private */,
      72,    0,  538,    2, 0x08 /* Private */,
      73,    0,  539,    2, 0x08 /* Private */,
      74,    0,  540,    2, 0x08 /* Private */,
      75,    0,  541,    2, 0x08 /* Private */,
      76,    0,  542,    2, 0x08 /* Private */,
      77,    1,  543,    2, 0x08 /* Private */,
      78,    1,  546,    2, 0x08 /* Private */,
      79,    1,  549,    2, 0x08 /* Private */,
      80,    0,  552,    2, 0x08 /* Private */,
      81,    0,  553,    2, 0x08 /* Private */,
      82,    0,  554,    2, 0x08 /* Private */,
      83,    1,  555,    2, 0x08 /* Private */,
      84,    0,  558,    2, 0x08 /* Private */,
      85,    0,  559,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 44,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   34,
    QMetaType::Void, QMetaType::Int,   34,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GTree::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GTree *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->renderCaliber(); break;
        case 1: _t->BuildAllSeparateTreeCaliber_Signal(); break;
        case 2: _t->on_actionOpenImage_triggered(); break;
        case 3: _t->on_actionOpenTree_triggered(); break;
        case 4: _t->on_actionSaveTree_triggered(); break;
        case 5: _t->on_actionClear_triggered(); break;
        case 6: _t->on_actionRun_triggered(); break;
        case 7: _t->EndRunThread(); break;
        case 8: _t->on_actionStop_triggered(); break;
        case 9: _t->UpdateStatus_Slot(); break;
        case 10: _t->ApplyReadNewImage_Slot(); break;
        case 11: _t->on_actionSaveImage_triggered(); break;
        case 12: _t->on_actionSaveBack_triggered(); break;
        case 13: _t->on_actionBatchTracing_triggered(); break;
        case 14: _t->on_actionCalcRadius_triggered(); break;
        case 15: _t->on_actionSampleMaker_triggered(); break;
        case 16: _t->UpdateImgResolution_Slot(); break;
        case 17: _t->on_actionBuildAllCaliber_triggered(); break;
        case 18: _t->SetROIByBoxWidget_Slot(); break;
        case 19: _t->on_actionChoose_Line_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->on_actionChoose_Vertex_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->on_actionDelete_Line_triggered(); break;
        case 22: _t->on_actionCut_Vertex_triggered(); break;
        case 23: _t->on_actionDraw_Line_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->on_action2DView_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->on_actionZoom_in_triggered(); break;
        case 26: _t->on_actionZoom_out_triggered(); break;
        case 27: _t->on_actionVisible_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->on_actionSaveSVM_triggered(); break;
        case 29: _t->ChangeMoveCursor_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->TimingSave_Slot(); break;
        case 31: _t->on_actionPick_Soma_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->on_actionSelect_Tree_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->on_actionNGTree_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: _t->on_actionSBWT_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->on_actionNGTree_Trace_triggered(); break;
        case 36: _t->on_actionDelete_Soma_triggered(); break;
        case 37: _t->on_actionDelete_Tree_triggered(); break;
        case 38: _t->on_actionTest_triggered(); break;
        case 39: _t->on_actionTest_for_Reconstruction_triggered(); break;
        case 40: _t->EditActionGroup_triggered((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 41: _t->SetProjectMaxThickness_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->MaxBoundNumChanged_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 43: _t->Set2DViewStatus_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->SetDrawStatus_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 45: _t->on_actionTrain_triggered(); break;
        case 46: _t->on_actionTreeChecker_triggered(); break;
        case 47: _t->UpdateGLBoxWidget_Slot(); break;
        case 48: _t->on_actionLocal_Run_triggered(); break;
        case 49: _t->on_actionSaveLayerImage_triggered(); break;
        case 50: _t->on_actionSaveLayerSwc_triggered(); break;
        case 51: _t->ClearMOSTDCache_Slot(); break;
        case 52: _t->ActivateTree_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 53: _t->CompareTree_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 54: _t->ToggleTreeVisible_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 55: _t->GotoDiff_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->ToggleTraverse_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 57: _t->BackTraverse_Slot(); break;
        case 58: _t->NextTraverse_Slot(); break;
        case 59: _t->ToggleShowDiffArrow_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 60: _t->StartTraverseFromHere_Slot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 61: _t->ResetTraverse_Slot(); break;
        case 62: _t->on_actionStart_triggered(); break;
        case 63: _t->on_actionHalt_triggered(); break;
        case 64: _t->on_actionReset_triggered(); break;
        case 65: _t->AddRunningTime_Slot(); break;
        case 66: _t->CacheComplete_Slot(); break;
        case 67: _t->on_actionNeuroGPS_triggered(); break;
        case 68: _t->on_actionSaveSoma_triggered(); break;
        case 69: _t->on_actionOpenSoma_triggered(); break;
        case 70: _t->on_actionSavePreview_triggered(); break;
        case 71: _t->on_actionSaveCaliber_triggered(); break;
        case 72: _t->OpacAdjustApply_Slot(); break;
        case 73: _t->PreviewOpacAdjust_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 74: _t->PreviewBinary_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 75: _t->PreviewAxonBinary_Slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 76: _t->on_actionSnapshot_triggered(); break;
        case 77: _t->on_actionCreate_HDF5_triggered(); break;
        case 78: _t->EndCreateHDF5_Slot(); break;
        case 79: _t->UpdateHDF5ProgressBar_Slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 80: _t->StopCreateHDF5_Slot(); break;
        case 81: _t->Test_slot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 40:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GTree::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GTree::renderCaliber)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GTree::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GTree::BuildAllSeparateTreeCaliber_Signal)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GTree::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_GTree.data,
    qt_meta_data_GTree,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GTree::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GTree::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GTree.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int GTree::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 82)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 82;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 82)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 82;
    }
    return _id;
}

// SIGNAL 0
void GTree::renderCaliber()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void GTree::BuildAllSeparateTreeCaliber_Signal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
