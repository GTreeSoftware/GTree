#ifndef DEEPIMAGETHREAD_H
#define DEEPIMAGETHREAD_H
#include <QApplication> 
#include <QThread>
#include <memory>
#include <algorithm>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include <QReadWriteLock>
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
class DeepImageThread : public QThread
{
	Q_OBJECT

public:
	DeepImageThread(QObject *parent = nullptr);
	~DeepImageThread();
	void SetParam(NGParamPack &arg1, NGNeuronBigReader arg2);
	void stop();
protected:
	void run();
private:
	NGNeuronBigReader mostdReader;
	NGParamPack paramPack;
	QReadWriteLock readwriteLock;
	bool isInit;
};

#endif // DEEPIMAGETHREAD_H
