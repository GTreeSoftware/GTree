/**
 * @file OpenImageDialog.h
 * @brief A dialog for opening image and configure
 * @details GTree can read image in formats such as .tif, .mostd, .h5 and .sbd.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef OPENIMAGEDIALOG_H
#define OPENIMAGEDIALOG_H

#include <QDialog>
#include <QString>
#include "ngtypes/ParamPack.h"

namespace Ui {
	class OpenImageDialog;
}
/**
* @brief The dialog class for opening image.
*  GTree can read image in formats such as .tif, .mostd, .h5 and .sbd. The resolution can be also set here.
*/
class OpenImageDialog : public QDialog
{
	Q_OBJECT

public:
	explicit OpenImageDialog(QWidget *parent = 0);
	~OpenImageDialog();
	/**
	* @brief Get the name of the opening image.
	*
	* @return The name of the opening image.
	*/
	const QString GetOpenImageName() const;
	/**
	* @brief Get the name of the open files including swc, sta, sbd, except image files.
	*
	* @return The name of the open files.
	*/
	const QString GetOpenStackName() const;
	/**
	* @brief Set the parameters wrapper of common parameters. They can be modified in this class.
	*
	* @return The name of the open files.
	*/
	void SetParam(NGParamPack arg);
	/**
	* @brief Get the datatype of the opening image.
	*/
	DATATYPE GetDataType()const { return dataType_; }
	void SetImageName(QString);

private slots:
	void on_OpenButton_clicked();
	void on_OpenStackButton_clicked();

	void on_xResSpinBox_valueChanged(double arg);

	void on_yResSpinBox_valueChanged(double arg);

	void on_zResSpinBox_valueChanged(double arg);

private:
	Ui::OpenImageDialog *ui;
	QString readImageName_;
	QString readStackName_;
	QString readReconName_;
	QStringList readSwcList_;
	int bitsPerPixel_;
	int x_;
	int y_;
	int z_;
	/*double xResolution_;
	double yResolution_;
	double zResolution_;*/
	DATATYPE dataType_;
	NGParamPack paramPack;

	//function
	void SetDialogFileInfo(const QString&);//real time display current file info
	void GetImageInfo(const char*);
};

#endif // OPENIMAGEDIALOG_H
