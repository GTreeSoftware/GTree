#include "dataruduction.h"
#include <QVector>
#include "Function/IO/MOSTDReader.h"
//#include "../DockWidget/datareductiondockwidget.h"
#include "../ngtypes/volume.h"

DataReduction::DataReduction() 
{
	className_ = std::string("DataReduction");
	dataReduThreadworker = Q_NULLPTR;
}


DataReduction::~DataReduction()
{
}
/*Set mostdReader & ParamPack */
void DataReduction::SetParam(const std::string &pth, NGParamPack &paramPack){
	paramPack4Redu = std::make_shared<ParamPack>();
	*paramPack4Redu = *paramPack;
	//bug
	paramPack4Redu->OrigImage=std::make_shared<SVolume>();
	paramPack4Redu->BinImage = std::make_shared<CVolume>();
	paramPack4Redu->BackImage=std::make_shared<SVolume>();
	paramPack4Redu->SomaList=std::make_shared<Soma>();
	paramPack4Redu->LayerImage=std::make_shared<SVolume>();
	paramPack4Redu->previewImage=std::make_shared<SVolume>();
	paramPack4Redu->separateTree=std::make_shared<NeuronPopulation>();
	mostdReader = MOSTDReader::New();
	MostdFileName = pth;
	mostdReader->SetParam(paramPack4Redu);
	if ( ! (mostdReader->SetInputFileName(pth))){
		printf("Failed to read mostd in SetParam Function, DataReduction class.\n");
		return;
	}
	
}

/*Set Extract(Block Size) & Rendundancy */
void DataReduction::SetExtractandRendundancy(int a1, int a2, int a3,int b1,int b2,int b3){
	xExtract = a1;
	yExtract = a2;
	zExtract = a3;
	xRendundancy = b1;
	yRendundancy = b2;
	zRendundancy = b3;
}

bool DataReduction::Initial(){
	/*Set RangeMax*/
	if (xRendundancy > xExtract*0.8 || yRendundancy > yExtract*0.8 || zRendundancy > zExtract*0.8){
		printf("Rendundancy is more than extract value in Initial Function, DataReduction class.\n");
		return false;
	}
	if (paramPack4Redu->dataMode_!=READMODE::MOSTD){
		printf("data is not mostd, Initial Function, DataReduction class.\n");
		return false;
	}
	xRangeMax = paramPack4Redu->xRangeMax_;
	yRangeMax = paramPack4Redu->yRangeMax_;
	zRangeMax = paramPack4Redu->zRangeMax_;

	xStride = xExtract - xRendundancy;
	yStride = yExtract - yRendundancy;
	zStride = zExtract - zRendundancy;

	xVecMax = 1 + floor(xRangeMax / xStride);
	yVecMax = 1 + floor(yRangeMax / yStride);
	zVecMax = 1 + floor(zRangeMax / zStride);
	VecTotal = xVecMax*yVecMax*zVecMax;
	printf("Initial finish.\n");
	return true;
	
}

void DataReduction::ParallelTracer(){

	if (dataReduThreadworker ==Q_NULLPTR){
		dataReduThreadworker = new DataReduThread(this);
		QObject::connect(dataReduThreadworker, SIGNAL(finished()), this, SLOT(EndDataReduThread_Slot()));
		dataReduThreadworker->SetParam(MostdFileName,paramPack4Redu);
		Vec3i VecMax, Vec, Stride, Extract;
		VecMax << xVecMax, yVecMax, zVecMax;
		Vec << xVec, yVec, zVec;
		Stride << xStride, yStride, zStride;
		Extract << xExtract, yExtract, zExtract;
		dataReduThreadworker->SetVecParam(VecTotal, VecMax, Vec, Stride, Extract);
		//DataReductionDockWidget *reduDock = new DataReductionDockWidget();
		QObject::connect(dataReduThreadworker, SIGNAL(ParallelTracerImagePosition_Signal(int, int, int)), this, SLOT(ParallelTraceImagePosition1_Slot(int, int, int)));
	}
	//omp_set_num_threads(5);
	dataReduThreadworker->start();

}
void DataReduction::ParallelTracerStart(){
	ParallelTracer();
}

void DataReduction::EndDataReduThread_Slot(){
	return;
}

void DataReduction::ParallelTraceImagePosition1_Slot(int x, int y, int z){
	emit ParallelTraceImagePosition_Signal(x, y, z);
}




