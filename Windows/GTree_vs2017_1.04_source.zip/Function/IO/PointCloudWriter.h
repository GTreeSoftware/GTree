#pragma once
#include <memory>
#include <string>
#include "../ineuronio.h"
#include "../../ngtypes/ParamPack.h"
template<typename T> class Volume;
typedef Volume<unsigned char> CVolume;
typedef Volume<unsigned short> SVolume;
class INeuronDateObject;
class PointCloudWriter;

typedef std::shared_ptr<PointCloudWriter> NGPointCloudWriter;

class PointCloudWriter:public INeuronIO
{
public:
	typedef std::shared_ptr<const SVolume> CSVolumePointer;
	typedef std::shared_ptr<SVolume> SVolumePointer;
	static NGPointCloudWriter New() { return NGPointCloudWriter(new PointCloudWriter()); }
	PointCloudWriter();
	virtual ~PointCloudWriter();
	//void SetInput(ConstDataPointer&);derived function
	bool SetOutputFileName(const std::string&);
	ProcStatPointer Update();

private:
	//private function
	IDataPointer ReleaseData();
	ConstIDataPointer GetOutput();
	bool SetInputFileName(const std::string&) { return false; }
	bool WriteImage(const char *path);


	//output jpg
	//bool WriteJPEG(const char* path, CVolumePointer &pData);
	//
	std::string filename;
	bool isFileValid;
};

