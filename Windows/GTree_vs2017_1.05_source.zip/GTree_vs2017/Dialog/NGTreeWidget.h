/**
 * @file NGTreeWidget.h
 * @brief Sub component widget of BinarySettingsDockWidget
 * @details Record the number of traced trees and operate trees according to the number.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef NGTREEWIDGET_H
#define NGTREEWIDGET_H
#include <QTreeWidget>
#include <QAction>
#include "../ngtypes/ParamPack.h"
#include "../ngtypes/tree.h"
class QTreeWidgetItem;

/**
* @brief Sub component widget of BinarySettingsDockWidget.
* Operate the tree directly according to its serial number.
*/
class NGTreeWidget :
	public QTreeWidget
{
	Q_OBJECT
public:
	enum WIDGETMODE { TREEWIDGETMODE, CHECKWIDGETMODE, TRACEWIDGETMODE } widgetMode_;

	NGTreeWidget(QWidget *par = nullptr, WIDGETMODE = TREEWIDGETMODE);
	~NGTreeWidget();

	//enum ITEMTYPE{TREETYPE, CHECKTYPE};
	void addRoot(const QStringList&);
	void SetParam(NGParamPack arg) { paramPack_ = arg; }


public slots:
	/**
	* @brief Set the selected neuron tree as the active tree. Only the active tree can be operated. 
	*/
	void ActivateTree_Slot();
	/**
	* @brief Performing on-line differences matching and localization in reconstructions of same neuron
	*/
	void CompareTree_Slot();
	void ToggleTreeVisible_Slot();
	/**
	* @brief Go to differences matching node and visualize.
	*/
	void GotoDiff_Slot();
	/**
	* @brief Set the status of differences matching node as checked.
	*/
	void TriggeredCheckState_Slot();
	void DeleteAnnotate_Slot();
	/**
	* @brief Render the 3d arrow which point to the differences matching node.
	*/
	void ToggleShowDiffArrow_Slot(bool);
	void ResetTraverse_Slot();
	void ToggleShowTraverseFlag_Slot();
	void ParallelTrace_DisplayARegion_Slot();
	void ParallelTrace_ReviseTree_Slot();

protected:
	/**
	* @brief Create buttons for GUI menu and context menu.
	*
	* @return void
	*/
	void CreateAction();
	/**
	* @brief Right click and context menu pops up.
	*
	* @return void
	*/
	virtual void contextMenuEvent(QContextMenuEvent *ev);

signals:
	void ActiveTree_Signal(int);
	void CompareTree_Signal(int);
	void ToggleTreeVisible_Signal(int);
	void GotoDiff_Signal(int);
	void ToggleShowDiffArrow_Signal(bool);
	void ResetTraverse_Signal();
	void ToggleShowTraverseFlag_Signal();
	//dataReduction
	void ParallelTrace_DisplayARegion_Signal(int, int, int);
	void ParallelTrace_ReviseTree_Signal();
	void ParallelTrace_ResetMODE_Signal();
private:
	QTreeWidgetItem *choosedTreeWidgetItem;
	QAction *pActivate_, *pCompare_, *pToggleTreeShow_, *pGotoDiff_, *pToggleCheckState_, *pDeleteAnnotate_, *pToggleShowDiffArrow_,
		*pClearTraverseRecord_, *pToggleShowTraverseFlag_;
	//action for datareduction
	QAction *pDisplay_, *pReviseTree;
	NGParamPack paramPack_;
	Vec4i Pos_4parallelTrace;
};

#endif