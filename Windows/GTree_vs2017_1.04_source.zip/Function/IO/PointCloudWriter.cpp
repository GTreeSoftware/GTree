#include "PointCloudWriter.h"



#include "../ngtypes/basetypes.h"
#include "../ngtypes/volume.h"

PointCloudWriter::PointCloudWriter(void) :isFileValid(false)
{
	className_ = std::string("ImageWriter");
	m_Source = std::shared_ptr<SVolume>(new SVolume(this));
}

PointCloudWriter::~PointCloudWriter(void)
{
}

bool PointCloudWriter::SetOutputFileName(const std::string& path)
{
	filename = path;
	isFileValid = true;
	return true;
}

INEURONPROCESSOBJECT_GETOUTPUT_IMPLE(PointCloudWriter, SVolume)
INEURONPROCESSOBJECT_RELEASEDATA_IMPLE(PointCloudWriter)

ProcStatPointer PointCloudWriter::Update()
{
	if (isFileValid && m_Input) {
		if (m_Input->GetProcessObject()) {
			ProcStatPointer res = m_Input->GetProcessObject()->Update();
			if (!res->success()) {
				printf("error occurred in %s\n", className_.c_str());
				//LOG(ERROR) << "error occurred in "<<className_<<" when check m_Input.";
				return res;
			}
		}
		if (WriteImage(filename.c_str())) {
			MAKEPROCESSSTATUS(resSta, true, className_, "");
			return resSta;
		}
		//printf("can not read image file.this is %s", identifyName.c_str());
	}
	NG_ERROR_MESSAGE("error occurred in ImageWriter.");
	MAKEPROCESSSTATUS(resSta, false, className_, "Cannot write image.");
	return resSta;
}

bool PointCloudWriter::WriteImage(const char *path)
{
	SVolumePointer imageS = std::const_pointer_cast<SVolume>(std::dynamic_pointer_cast<const SVolume>(m_Input));
	auto &img = *imageS;
	FILE *fp = fopen(path, "wb");
	if (!fp) {
		printf("cannot write point cloud data.\n");
		return false;
	}
	int num = 0;
	for (size_t x = 0; x < img.x(); ++x) {
		for (size_t y = 0; y < img.y(); ++y) {
			for (size_t z = 0; z < img.z(); ++z) {
				if (img(x,y,z) > 50 ) {
					++num;
				}
			}
		}
	}
	fprintf(fp, "num=%d", num);
	fprintf(fp, "x=%llu,y=%llu,z=%llu\n", img.x(), img.y(), img.z());
	for (size_t x = 0; x < img.x(); ++x) {
		for (size_t y = 0; y < img.y(); ++y) {
			for (size_t z = 0; z < img.z(); ++z) {
				if (img(x, y, z) > 50) {
					fprintf(fp,"%llu %llu %llu %d ", x, y, z, img(x, y, z));
				}
			}
		}
	}
	fclose(fp);
	return true;
}
