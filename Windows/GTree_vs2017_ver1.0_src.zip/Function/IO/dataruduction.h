#ifndef DATARUDUCTION_H
#define DATARUDUCTION_H

#include <QObject>
#include "../ineuronprocessobject.h"
#include "../../ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include ".././Thread/datareduthread.h"

NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
class DataReduction;
NG_SMART_POINTER_TYPEDEF(DataReduction, NGDataReduction);
class DataReduction : public QObject, public INeuronProcessObject
{
	Q_OBJECT
public:
	static NGDataReduction New(){ return NGDataReduction(new DataReduction()); };
	DataReduction();
	~DataReduction();
	void SetParam(const std::string &, NGParamPack &);
	void SetExtractandRendundancy(int, int, int, int, int, int);
	void StartThread();
	
	bool Initial();//data preparation
	void ParallelTracerStart();

signals:
	void ParallelTraceImagePosition_Signal(int, int, int);
protected:
	virtual ProcStatPointer Update(){
		MAKEPROCESSSTATUS(resSta, true, className_, "");
		return resSta;
	}
	virtual ConstIDataPointer GetOutput(){ return m_Source; };
	virtual IDataPointer ReleaseData(){ return nullptr; };
private slots:
	void EndDataReduThread_Slot();
	void ParallelTraceImagePosition1_Slot(int, int, int);
private:
	/*struct ReductoinPointer
	{
	ReductoinPointer(int a, int b, int c) :xStart(a), yStart(b), zStart(c){}
	~ReductoinPointer(){}
	
	};*/
	int xStart = 0;
	int yStart = 0;
	int zStart = 0;
	//ReductoinPointer *reduPtr;
	int xMin, yMin, zMin, xMax, yMax, zMax;
	int xRendundancy, yRendundancy, zRendundancy;
	int xExtract, yExtract, zExtract;// block size, Max-Min
	int xStride, yStride, zStride;// Extract - Rendundancy
	int xRangeMax, yRangeMax, zRangeMax;
	int xVecMax, yVecMax, zVecMax;
	int xVec, yVec, zVec;
	int VecTotal;
	std::string MostdFileName;
	NGParamPack paramPack, paramPack4Redu;
	NGNeuronBigReader mostdReader;
	DataReduThread *dataReduThreadworker;
	void ParallelTracer();
};

#endif // DATARUDUCTION_H
