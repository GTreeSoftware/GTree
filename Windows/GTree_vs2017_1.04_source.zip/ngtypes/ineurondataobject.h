/**
 * @file ineurondataobject.h
 * @brief Pure virtual class for data classes
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef INEURONDATAOBJECT_H
#define INEURONDATAOBJECT_H
#include <memory>
#include <string>
#include "basetypes.h"
class INeuronProcessObject;
class INeuronDataObject;

//#ifdef _WIN32
//#define NG_SMART_POINTER_TYPEDEF(type, name) typedef std::tr1::shared_ptr<type> name
//#else
#define NG_SMART_POINTER_TYPEDEF(type, name) typedef std::shared_ptr<type> name
//#endif 
NG_SMART_POINTER_TYPEDEF(INeuronDataObject, IDataPointer);
NG_SMART_POINTER_TYPEDEF(INeuronDataObject, ConstIDataPointer);

/**
* @brief Pure virtual class of data classes.
* Pure virtual class of data classes. The data structures which inherit from this class can be pointed by base pointer IDataPointer.
* This class includes a pointer (m_ProcessObject) which points to the corresponding function class which generate this data.
* The function classes also include the pointer to the input data and generated data.
* Thus, the datum inherit from this base class can be connected as pipeline using the built-in pointer to function class.
*/
class INeuronDataObject
{
public:
    virtual bool IsEmpty()const=0;
    virtual void SetProcessObject(INeuronProcessObject* p){m_ProcessObject = p;}
    virtual INeuronProcessObject *GetProcessObject()const{return m_ProcessObject;}
    virtual void ReleaseProcessObject(){m_ProcessObject = NULL;}
	/**
	* @brief Get the class name.
	*/
    const std::string& GetIdentifyName()const{return identifyName;}
    DATATYPE DataType()const{ return dataType; }
    void SetDataType(DATATYPE arg){ dataType = arg; }
    virtual ~INeuronDataObject(){}
protected:
    std::string identifyName;
    DATATYPE dataType;
    INeuronProcessObject* m_ProcessObject;//father process

};

#endif // NEURONDATAOBJECT_H
