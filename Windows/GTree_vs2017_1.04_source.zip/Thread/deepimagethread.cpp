#include "deepimagethread.h"
#include "Function/IO/MOSTDReader.h"
DeepImageThread::DeepImageThread(QObject *parent)
	: QThread(parent)
{
	isInit = false;
}

DeepImageThread::~DeepImageThread()
{

}
void DeepImageThread::SetParam(NGParamPack &arg1, NGNeuronBigReader arg2)
{
	paramPack = arg1;
	mostdReader = arg2;
	isInit = true;
}
void DeepImageThread::run(){
	if (isInit)
	{
		mostdReader->SetParam(paramPack);
		printf("INThread %d %d %d %d %d %d\n", paramPack->xMin_, paramPack->xMax_, paramPack->yMin_, paramPack->yMax_, paramPack->zMin_, paramPack->zMax_);
		if (!mostdReader->Update()->success()){
			printf("!!!\n");
			return;
		}
		printf("Deep Traverse image thread.");
	}
}
