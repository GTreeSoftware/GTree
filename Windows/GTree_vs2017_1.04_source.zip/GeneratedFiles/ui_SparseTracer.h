/********************************************************************************
** Form generated from reading UI file 'SparseTracer.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPARSETRACER_H
#define UI_SPARSETRACER_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SparseTracerClass
{
public:
    QAction *actionOpenSoma;
    QAction *actionSaveSoma;
    QAction *actionSaveTree;
    QAction *actionSaveCaliber;
    QAction *action2DView;
    QAction *actionZoom_in;
    QAction *actionZoom_out;
    QAction *actionVisible;
    QAction *actionNeuroGPS;
    QAction *actionNGTree_Trace;
    QAction *actionLocal_Run;
    QAction *actionTreeChecker;
    QAction *actionRun;
    QAction *actionTrain;
    QAction *actionStop;
    QAction *actionNGTree;
    QAction *actionSBWT;
    QAction *actionDataReduction;
    QAction *actionBatchTracing;
    QAction *actionSaveSVM;
    QAction *actionSaveBack;
    QAction *actionSaveLayerImage;
    QAction *actionSaveLayerSwc;
    QAction *actionChoose_Line;
    QAction *actionChoose_Vertex;
    QAction *actionDelete_Line;
    QAction *actionCut_Vertex;
    QAction *actionDraw_Line;
    QAction *actionPick_Soma;
    QAction *actionDelete_Soma;
    QAction *actionSelect_Tree;
    QAction *actionDelete_Tree;
    QAction *actionTest_for_Reconstruction;
    QAction *actionStart;
    QAction *actionHalt;
    QAction *actionReset;
    QAction *actionSaveImage1;
    QAction *actionCreate_HDF5;
    QAction *actionBackTrack;
    QAction *actionTest;
    QAction *actionOpenImage;
    QAction *actionSaveImage;
    QAction *actionSnapshot;
    QAction *actionClear;
    QAction *actionSampleMaker;
    QAction *actionBatchThinner;
    QAction *actionSavePreview;
    QAction *actionCalcRadius;
    QAction *actionOpenTree;
    QAction *actionBuildAllCaliber;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *mainLayout;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QMenu *menuTrace;
    QMenu *menuMode;
    QMenu *menuDebug;
    QMenu *menuTimer;
    QMenu *menuTool;
    QStatusBar *statusBar;
    QToolBar *toolBar;
    QToolBar *toolBar_2;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *SparseTracerClass)
    {
        if (SparseTracerClass->objectName().isEmpty())
            SparseTracerClass->setObjectName(QString::fromUtf8("SparseTracerClass"));
        SparseTracerClass->resize(698, 599);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/trace/Resources/Science.png"), QSize(), QIcon::Normal, QIcon::Off);
        SparseTracerClass->setWindowIcon(icon);
        actionOpenSoma = new QAction(SparseTracerClass);
        actionOpenSoma->setObjectName(QString::fromUtf8("actionOpenSoma"));
        actionSaveSoma = new QAction(SparseTracerClass);
        actionSaveSoma->setObjectName(QString::fromUtf8("actionSaveSoma"));
        actionSaveTree = new QAction(SparseTracerClass);
        actionSaveTree->setObjectName(QString::fromUtf8("actionSaveTree"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/trace/Resources/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSaveTree->setIcon(icon1);
        actionSaveCaliber = new QAction(SparseTracerClass);
        actionSaveCaliber->setObjectName(QString::fromUtf8("actionSaveCaliber"));
        action2DView = new QAction(SparseTracerClass);
        action2DView->setObjectName(QString::fromUtf8("action2DView"));
        action2DView->setCheckable(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/trace/Resources/view.png"), QSize(), QIcon::Normal, QIcon::Off);
        action2DView->setIcon(icon2);
        actionZoom_in = new QAction(SparseTracerClass);
        actionZoom_in->setObjectName(QString::fromUtf8("actionZoom_in"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/trace/Resources/zoomin.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionZoom_in->setIcon(icon3);
        actionZoom_out = new QAction(SparseTracerClass);
        actionZoom_out->setObjectName(QString::fromUtf8("actionZoom_out"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/trace/Resources/zoomout.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionZoom_out->setIcon(icon4);
        actionVisible = new QAction(SparseTracerClass);
        actionVisible->setObjectName(QString::fromUtf8("actionVisible"));
        actionVisible->setCheckable(true);
        actionVisible->setChecked(true);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/trace/Resources/visible.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionVisible->setIcon(icon5);
        actionNeuroGPS = new QAction(SparseTracerClass);
        actionNeuroGPS->setObjectName(QString::fromUtf8("actionNeuroGPS"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/trace/Resources/seed.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNeuroGPS->setIcon(icon6);
        actionNGTree_Trace = new QAction(SparseTracerClass);
        actionNGTree_Trace->setObjectName(QString::fromUtf8("actionNGTree_Trace"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/trace/Resources/NGTree.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNGTree_Trace->setIcon(icon7);
        actionLocal_Run = new QAction(SparseTracerClass);
        actionLocal_Run->setObjectName(QString::fromUtf8("actionLocal_Run"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/trace/Resources/step.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionLocal_Run->setIcon(icon8);
        actionTreeChecker = new QAction(SparseTracerClass);
        actionTreeChecker->setObjectName(QString::fromUtf8("actionTreeChecker"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/trace/Resources/tree.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionTreeChecker->setIcon(icon9);
        actionRun = new QAction(SparseTracerClass);
        actionRun->setObjectName(QString::fromUtf8("actionRun"));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/trace/Resources/run.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRun->setIcon(icon10);
        actionTrain = new QAction(SparseTracerClass);
        actionTrain->setObjectName(QString::fromUtf8("actionTrain"));
        actionStop = new QAction(SparseTracerClass);
        actionStop->setObjectName(QString::fromUtf8("actionStop"));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/trace/Resources/stop.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStop->setIcon(icon11);
        actionNGTree = new QAction(SparseTracerClass);
        actionNGTree->setObjectName(QString::fromUtf8("actionNGTree"));
        actionNGTree->setCheckable(true);
        actionNGTree->setChecked(true);
        actionSBWT = new QAction(SparseTracerClass);
        actionSBWT->setObjectName(QString::fromUtf8("actionSBWT"));
        actionSBWT->setCheckable(true);
        actionSBWT->setChecked(true);
        actionDataReduction = new QAction(SparseTracerClass);
        actionDataReduction->setObjectName(QString::fromUtf8("actionDataReduction"));
        actionBatchTracing = new QAction(SparseTracerClass);
        actionBatchTracing->setObjectName(QString::fromUtf8("actionBatchTracing"));
        actionSaveSVM = new QAction(SparseTracerClass);
        actionSaveSVM->setObjectName(QString::fromUtf8("actionSaveSVM"));
        actionSaveBack = new QAction(SparseTracerClass);
        actionSaveBack->setObjectName(QString::fromUtf8("actionSaveBack"));
        actionSaveLayerImage = new QAction(SparseTracerClass);
        actionSaveLayerImage->setObjectName(QString::fromUtf8("actionSaveLayerImage"));
        actionSaveLayerSwc = new QAction(SparseTracerClass);
        actionSaveLayerSwc->setObjectName(QString::fromUtf8("actionSaveLayerSwc"));
        actionChoose_Line = new QAction(SparseTracerClass);
        actionChoose_Line->setObjectName(QString::fromUtf8("actionChoose_Line"));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/trace/Resources/chooseline.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionChoose_Line->setIcon(icon12);
        actionChoose_Vertex = new QAction(SparseTracerClass);
        actionChoose_Vertex->setObjectName(QString::fromUtf8("actionChoose_Vertex"));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/trace/Resources/choosepoint.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionChoose_Vertex->setIcon(icon13);
        actionDelete_Line = new QAction(SparseTracerClass);
        actionDelete_Line->setObjectName(QString::fromUtf8("actionDelete_Line"));
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/trace/Resources/deleteline.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDelete_Line->setIcon(icon14);
        actionCut_Vertex = new QAction(SparseTracerClass);
        actionCut_Vertex->setObjectName(QString::fromUtf8("actionCut_Vertex"));
        QIcon icon15;
        icon15.addFile(QString::fromUtf8(":/trace/Resources/cut.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCut_Vertex->setIcon(icon15);
        actionDraw_Line = new QAction(SparseTracerClass);
        actionDraw_Line->setObjectName(QString::fromUtf8("actionDraw_Line"));
        QIcon icon16;
        icon16.addFile(QString::fromUtf8(":/trace/Resources/drawline.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDraw_Line->setIcon(icon16);
        actionPick_Soma = new QAction(SparseTracerClass);
        actionPick_Soma->setObjectName(QString::fromUtf8("actionPick_Soma"));
        QIcon icon17;
        icon17.addFile(QString::fromUtf8(":/trace/Resources/choosesoma.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPick_Soma->setIcon(icon17);
        actionDelete_Soma = new QAction(SparseTracerClass);
        actionDelete_Soma->setObjectName(QString::fromUtf8("actionDelete_Soma"));
        QIcon icon18;
        icon18.addFile(QString::fromUtf8(":/trace/Resources/deletesoma.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDelete_Soma->setIcon(icon18);
        actionSelect_Tree = new QAction(SparseTracerClass);
        actionSelect_Tree->setObjectName(QString::fromUtf8("actionSelect_Tree"));
        QIcon icon19;
        icon19.addFile(QString::fromUtf8(":/trace/Resources/choosetree.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSelect_Tree->setIcon(icon19);
        actionDelete_Tree = new QAction(SparseTracerClass);
        actionDelete_Tree->setObjectName(QString::fromUtf8("actionDelete_Tree"));
        QIcon icon20;
        icon20.addFile(QString::fromUtf8(":/trace/Resources/deletetree.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionDelete_Tree->setIcon(icon20);
        actionTest_for_Reconstruction = new QAction(SparseTracerClass);
        actionTest_for_Reconstruction->setObjectName(QString::fromUtf8("actionTest_for_Reconstruction"));
        actionStart = new QAction(SparseTracerClass);
        actionStart->setObjectName(QString::fromUtf8("actionStart"));
        actionHalt = new QAction(SparseTracerClass);
        actionHalt->setObjectName(QString::fromUtf8("actionHalt"));
        actionReset = new QAction(SparseTracerClass);
        actionReset->setObjectName(QString::fromUtf8("actionReset"));
        actionSaveImage1 = new QAction(SparseTracerClass);
        actionSaveImage1->setObjectName(QString::fromUtf8("actionSaveImage1"));
        actionCreate_HDF5 = new QAction(SparseTracerClass);
        actionCreate_HDF5->setObjectName(QString::fromUtf8("actionCreate_HDF5"));
        actionBackTrack = new QAction(SparseTracerClass);
        actionBackTrack->setObjectName(QString::fromUtf8("actionBackTrack"));
        actionTest = new QAction(SparseTracerClass);
        actionTest->setObjectName(QString::fromUtf8("actionTest"));
        actionOpenImage = new QAction(SparseTracerClass);
        actionOpenImage->setObjectName(QString::fromUtf8("actionOpenImage"));
        QIcon icon21;
        icon21.addFile(QString::fromUtf8(":/trace/Resources/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpenImage->setIcon(icon21);
        actionSaveImage = new QAction(SparseTracerClass);
        actionSaveImage->setObjectName(QString::fromUtf8("actionSaveImage"));
        actionSnapshot = new QAction(SparseTracerClass);
        actionSnapshot->setObjectName(QString::fromUtf8("actionSnapshot"));
        QIcon icon22;
        icon22.addFile(QString::fromUtf8(":/trace/Resources/snap.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSnapshot->setIcon(icon22);
        actionClear = new QAction(SparseTracerClass);
        actionClear->setObjectName(QString::fromUtf8("actionClear"));
        QIcon icon23;
        icon23.addFile(QString::fromUtf8(":/trace/Resources/sweep.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionClear->setIcon(icon23);
        actionSampleMaker = new QAction(SparseTracerClass);
        actionSampleMaker->setObjectName(QString::fromUtf8("actionSampleMaker"));
        actionSampleMaker->setEnabled(false);
        actionBatchThinner = new QAction(SparseTracerClass);
        actionBatchThinner->setObjectName(QString::fromUtf8("actionBatchThinner"));
        actionBatchThinner->setEnabled(false);
        actionSavePreview = new QAction(SparseTracerClass);
        actionSavePreview->setObjectName(QString::fromUtf8("actionSavePreview"));
        actionCalcRadius = new QAction(SparseTracerClass);
        actionCalcRadius->setObjectName(QString::fromUtf8("actionCalcRadius"));
        actionOpenTree = new QAction(SparseTracerClass);
        actionOpenTree->setObjectName(QString::fromUtf8("actionOpenTree"));
        actionBuildAllCaliber = new QAction(SparseTracerClass);
        actionBuildAllCaliber->setObjectName(QString::fromUtf8("actionBuildAllCaliber"));
        centralWidget = new QWidget(SparseTracerClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        mainLayout = new QHBoxLayout();
        mainLayout->setSpacing(6);
        mainLayout->setObjectName(QString::fromUtf8("mainLayout"));

        gridLayout->addLayout(mainLayout, 0, 0, 1, 1);

        SparseTracerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SparseTracerClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 698, 26));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuTrace = new QMenu(menuBar);
        menuTrace->setObjectName(QString::fromUtf8("menuTrace"));
        menuMode = new QMenu(menuBar);
        menuMode->setObjectName(QString::fromUtf8("menuMode"));
        menuDebug = new QMenu(menuBar);
        menuDebug->setObjectName(QString::fromUtf8("menuDebug"));
        menuTimer = new QMenu(menuDebug);
        menuTimer->setObjectName(QString::fromUtf8("menuTimer"));
        menuTool = new QMenu(menuBar);
        menuTool->setObjectName(QString::fromUtf8("menuTool"));
        SparseTracerClass->setMenuBar(menuBar);
        statusBar = new QStatusBar(SparseTracerClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SparseTracerClass->setStatusBar(statusBar);
        toolBar = new QToolBar(SparseTracerClass);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        SparseTracerClass->addToolBar(Qt::TopToolBarArea, toolBar);
        toolBar_2 = new QToolBar(SparseTracerClass);
        toolBar_2->setObjectName(QString::fromUtf8("toolBar_2"));
        SparseTracerClass->addToolBar(Qt::TopToolBarArea, toolBar_2);
        mainToolBar = new QToolBar(SparseTracerClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        SparseTracerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuTrace->menuAction());
        menuBar->addAction(menuMode->menuAction());
        menuBar->addAction(menuDebug->menuAction());
        menuBar->addAction(menuTool->menuAction());
        menuFile->addAction(actionOpenImage);
        menuFile->addAction(actionSaveImage);
        menuFile->addAction(actionOpenTree);
        menuFile->addAction(actionSaveTree);
        menuFile->addAction(actionOpenSoma);
        menuFile->addAction(actionSaveSoma);
        menuFile->addAction(actionSaveCaliber);
        menuFile->addAction(actionSnapshot);
        menuFile->addAction(actionClear);
        menuFile->addAction(actionSavePreview);
        menuEdit->addAction(action2DView);
        menuEdit->addAction(actionZoom_in);
        menuEdit->addAction(actionZoom_out);
        menuEdit->addAction(actionVisible);
        menuEdit->addSeparator();
        menuEdit->addAction(actionCreate_HDF5);
        menuTrace->addAction(actionNeuroGPS);
        menuTrace->addAction(actionNGTree_Trace);
        menuTrace->addAction(actionLocal_Run);
        menuTrace->addAction(actionTreeChecker);
        menuTrace->addAction(actionRun);
        menuTrace->addAction(actionTrain);
        menuTrace->addAction(actionStop);
        menuTrace->addAction(actionBackTrack);
        menuMode->addAction(actionNGTree);
        menuMode->addAction(actionSBWT);
        menuDebug->addAction(actionSaveSVM);
        menuDebug->addAction(actionSaveBack);
        menuDebug->addAction(actionSaveLayerImage);
        menuDebug->addAction(actionSaveLayerSwc);
        menuDebug->addAction(actionChoose_Line);
        menuDebug->addAction(actionChoose_Vertex);
        menuDebug->addAction(actionDelete_Line);
        menuDebug->addAction(actionCut_Vertex);
        menuDebug->addAction(actionDraw_Line);
        menuDebug->addAction(actionPick_Soma);
        menuDebug->addAction(actionDelete_Soma);
        menuDebug->addAction(actionSelect_Tree);
        menuDebug->addAction(actionDelete_Tree);
        menuDebug->addAction(menuTimer->menuAction());
        menuDebug->addAction(actionTest_for_Reconstruction);
        menuDebug->addAction(actionTest);
        menuTimer->addAction(actionStart);
        menuTimer->addAction(actionHalt);
        menuTimer->addAction(actionReset);
        menuTool->addAction(actionBatchTracing);
        menuTool->addAction(actionBuildAllCaliber);
        menuTool->addAction(actionCalcRadius);
        menuTool->addAction(actionSampleMaker);
        menuTool->addAction(actionBatchThinner);
        toolBar->addAction(actionRun);
        toolBar->addAction(actionStop);
        toolBar->addAction(actionTrain);
        toolBar_2->addAction(actionTreeChecker);
        toolBar_2->addAction(actionLocal_Run);
        toolBar_2->addAction(actionNeuroGPS);
        toolBar_2->addAction(actionNGTree_Trace);
        mainToolBar->addAction(actionOpenImage);
        mainToolBar->addAction(actionSaveTree);
        mainToolBar->addAction(actionSnapshot);
        mainToolBar->addAction(actionClear);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionNGTree);
        mainToolBar->addAction(actionSBWT);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionZoom_in);
        mainToolBar->addAction(actionZoom_out);
        mainToolBar->addAction(actionVisible);

        retranslateUi(SparseTracerClass);

        QMetaObject::connectSlotsByName(SparseTracerClass);
    } // setupUi

    void retranslateUi(QMainWindow *SparseTracerClass)
    {
        SparseTracerClass->setWindowTitle(QApplication::translate("SparseTracerClass", "GTree", nullptr));
        actionOpenSoma->setText(QApplication::translate("SparseTracerClass", "OpenSoma", nullptr));
        actionSaveSoma->setText(QApplication::translate("SparseTracerClass", "SaveSoma", nullptr));
        actionSaveTree->setText(QApplication::translate("SparseTracerClass", "SaveTree", nullptr));
#ifndef QT_NO_SHORTCUT
        actionSaveTree->setShortcut(QApplication::translate("SparseTracerClass", "Ctrl+S", nullptr));
#endif // QT_NO_SHORTCUT
        actionSaveCaliber->setText(QApplication::translate("SparseTracerClass", "SaveCaliber", nullptr));
        action2DView->setText(QApplication::translate("SparseTracerClass", "2DView", nullptr));
#ifndef QT_NO_SHORTCUT
        action2DView->setShortcut(QApplication::translate("SparseTracerClass", "2", nullptr));
#endif // QT_NO_SHORTCUT
        actionZoom_in->setText(QApplication::translate("SparseTracerClass", "Zoom in", nullptr));
        actionZoom_out->setText(QApplication::translate("SparseTracerClass", "Zoom out", nullptr));
        actionVisible->setText(QApplication::translate("SparseTracerClass", "Visible", nullptr));
#ifndef QT_NO_SHORTCUT
        actionVisible->setShortcut(QApplication::translate("SparseTracerClass", "A", nullptr));
#endif // QT_NO_SHORTCUT
        actionNeuroGPS->setText(QApplication::translate("SparseTracerClass", "NeuroGPS", nullptr));
        actionNGTree_Trace->setText(QApplication::translate("SparseTracerClass", "NGTree Trace", nullptr));
        actionLocal_Run->setText(QApplication::translate("SparseTracerClass", "Local Run", nullptr));
        actionTreeChecker->setText(QApplication::translate("SparseTracerClass", "TreeChecker", nullptr));
        actionRun->setText(QApplication::translate("SparseTracerClass", "Run", nullptr));
#ifndef QT_NO_SHORTCUT
        actionRun->setShortcut(QApplication::translate("SparseTracerClass", "T", nullptr));
#endif // QT_NO_SHORTCUT
        actionTrain->setText(QApplication::translate("SparseTracerClass", "Train", nullptr));
        actionStop->setText(QApplication::translate("SparseTracerClass", "Stop", nullptr));
        actionNGTree->setText(QApplication::translate("SparseTracerClass", "NGTree", nullptr));
        actionSBWT->setText(QApplication::translate("SparseTracerClass", "SBWT", nullptr));
        actionDataReduction->setText(QApplication::translate("SparseTracerClass", "DataReduction", nullptr));
        actionBatchTracing->setText(QApplication::translate("SparseTracerClass", "BatchTracing", nullptr));
        actionSaveSVM->setText(QApplication::translate("SparseTracerClass", "SaveSVM", nullptr));
        actionSaveBack->setText(QApplication::translate("SparseTracerClass", "SaveBack", nullptr));
        actionSaveLayerImage->setText(QApplication::translate("SparseTracerClass", "SaveLayerImage", nullptr));
        actionSaveLayerSwc->setText(QApplication::translate("SparseTracerClass", "SaveLayerSwc", nullptr));
        actionChoose_Line->setText(QApplication::translate("SparseTracerClass", "Choose Line", nullptr));
        actionChoose_Vertex->setText(QApplication::translate("SparseTracerClass", "Choose Vertex", nullptr));
        actionDelete_Line->setText(QApplication::translate("SparseTracerClass", "Delete Line", nullptr));
        actionCut_Vertex->setText(QApplication::translate("SparseTracerClass", "Cut Vertex", nullptr));
        actionDraw_Line->setText(QApplication::translate("SparseTracerClass", "Draw Line", nullptr));
        actionPick_Soma->setText(QApplication::translate("SparseTracerClass", "Pick Soma", nullptr));
        actionDelete_Soma->setText(QApplication::translate("SparseTracerClass", "Delete Soma", nullptr));
        actionSelect_Tree->setText(QApplication::translate("SparseTracerClass", "Select Tree", nullptr));
        actionDelete_Tree->setText(QApplication::translate("SparseTracerClass", "Delete Tree", nullptr));
        actionTest_for_Reconstruction->setText(QApplication::translate("SparseTracerClass", "Test for Reconstruction", nullptr));
        actionStart->setText(QApplication::translate("SparseTracerClass", "Start", nullptr));
        actionHalt->setText(QApplication::translate("SparseTracerClass", "Halt", nullptr));
        actionReset->setText(QApplication::translate("SparseTracerClass", "Reset", nullptr));
        actionSaveImage1->setText(QApplication::translate("SparseTracerClass", "SaveImage", nullptr));
        actionCreate_HDF5->setText(QApplication::translate("SparseTracerClass", "Create HDF5", nullptr));
        actionBackTrack->setText(QApplication::translate("SparseTracerClass", "BackTrack", nullptr));
        actionTest->setText(QApplication::translate("SparseTracerClass", "Test", nullptr));
        actionOpenImage->setText(QApplication::translate("SparseTracerClass", "OpenImage", nullptr));
#ifndef QT_NO_SHORTCUT
        actionOpenImage->setShortcut(QApplication::translate("SparseTracerClass", "Ctrl+O", nullptr));
#endif // QT_NO_SHORTCUT
        actionSaveImage->setText(QApplication::translate("SparseTracerClass", "SaveImage", nullptr));
        actionSnapshot->setText(QApplication::translate("SparseTracerClass", "Snapshot", nullptr));
        actionClear->setText(QApplication::translate("SparseTracerClass", "Clear", nullptr));
        actionSampleMaker->setText(QApplication::translate("SparseTracerClass", "SampleMaker", nullptr));
        actionBatchThinner->setText(QApplication::translate("SparseTracerClass", "BatchThinner", nullptr));
        actionSavePreview->setText(QApplication::translate("SparseTracerClass", "SavePreview", nullptr));
        actionCalcRadius->setText(QApplication::translate("SparseTracerClass", "CalcRadius", nullptr));
        actionOpenTree->setText(QApplication::translate("SparseTracerClass", "OpenTree", nullptr));
        actionBuildAllCaliber->setText(QApplication::translate("SparseTracerClass", "BuildAllCaliber", nullptr));
        menuFile->setTitle(QApplication::translate("SparseTracerClass", "File", nullptr));
        menuEdit->setTitle(QApplication::translate("SparseTracerClass", "Edit", nullptr));
        menuTrace->setTitle(QApplication::translate("SparseTracerClass", "Trace", nullptr));
        menuMode->setTitle(QApplication::translate("SparseTracerClass", "Mode", nullptr));
        menuDebug->setTitle(QApplication::translate("SparseTracerClass", "Debug", nullptr));
        menuTimer->setTitle(QApplication::translate("SparseTracerClass", "Timer", nullptr));
        menuTool->setTitle(QApplication::translate("SparseTracerClass", "Tool", nullptr));
        toolBar->setWindowTitle(QApplication::translate("SparseTracerClass", "toolBar", nullptr));
        toolBar_2->setWindowTitle(QApplication::translate("SparseTracerClass", "toolBar_2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SparseTracerClass: public Ui_SparseTracerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPARSETRACER_H
