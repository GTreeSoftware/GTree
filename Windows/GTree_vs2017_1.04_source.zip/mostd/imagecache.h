/**
 * @file imagecache.h
 * @brief Brain-wide data cache manager
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef IMAGECACHE_H
#define IMAGECACHE_H
#include <sstream>
#include <iostream>
#include <math.h>
#include <memory>
#include <algorithm>
#include <list>
#include <deque>
#include <vector>
#include <time.h>
using namespace std;
class ImageCache;
#ifdef _WIN32
typedef std::tr1::shared_ptr<ImageCache> SmartCache;
#else
typedef std::shared_ptr<ImageCache> SmartCache;
#endif

/**
* @brief Brain-wide data cache blocks
* Brain-wide data cache blocks. It is part of ImageCaches.
*/
class ImageCache{
public:
    ImageCache(size_t bitsNumArg);
    ~ImageCache();
	/**
	* @brief Update the time stamp.
	*
	* @return void
	*/
    void Modified();
	/**
	* @brief Acquire the 8bit cache image pointer.
	*
	* @param arg The cache image pointer.
	* @return Void
	*/
    void GetImagePtr(unsigned char* &arg){arg = imageData8_;}
	/**
	* @brief Acquire the 16bit cache image pointer.
	*
	* @param arg The cache image pointer.
	* @return Void
	*/
    void GetImagePtr(unsigned short* &arg){arg = imageData16_;}
	/**
	* @brief Set the name of cache image. Usually the name is the full image path.
	*
	* @return Cache image time stamp.
	*/
    void SetImageName(const string &arg){imageName_ = arg;}
	/**
	* @brief Acquire the cache image type.
	*
	* @return Cache image type
	*/
    size_t GetImageBits(){return imageBits_;}
	/**
	* @brief Acquire the time stamp of cache image type.
	*
	* @return Cache image time stamp.
	*/
    time_t GetLastUsedTime(){return lastUsedTime_;}
    string GetImageName(){return imageName_;}

private:
    size_t imageBits_;
    unsigned char *imageData8_;
    unsigned short *imageData16_;
    time_t lastUsedTime_;
    string imageName_;
};

/**
* @brief The manager of brain-wide data cache blocks
* Brain-wide data cache blocks are sorted by time stamp. cache blocks are removed according to LRU algorithm.
*/
class ImageCaches{
public:
    ImageCaches(size_t numArg, size_t bitsArg);
    ~ImageCaches();
	/**
	* @brief Acquire target cache image by name.
	* @param nameArg The name of cache blocks.
	*
	* @return Smart pointer to the target cache.
	*/
    SmartCache GetSmartCache(const string &nameArg);
	/**
	* @brief Debug the cache
	* @deprecated
	* @return void
	*/
    void TravelCaches();
    bool isCacheExisting(const string &nameArg);  
    void ClearCache();

private:
	/**
	* @brief The compare function used in sorting.
	* @param arg1 One of cache blocks.
	* @param arg2 One of cache blocks.
	*
	* @return bool
	*/
    static bool CachSortFun(const SmartCache &arg1, const SmartCache &arg2);
	/**
	* @brief Sort the image cache blocks according to the time stamps.
	*
	* @return bool
	*/
    void SortCaches();
    void DeleteUnusedCache();
    void AddCache(const string &nameArg);
    std::deque<SmartCache> cachePtrs_;
    size_t cacheMaxNum_;
    size_t imageBits_;
};

#endif