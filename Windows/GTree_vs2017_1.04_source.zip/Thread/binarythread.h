/**
 * @file binarythread.h
 * @brief The multi-thread class for function module
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef BINARYTHREAD_H
#define BINARYTHREAD_H
#include <QThread>
#include <memory>
#include "../Function/ineuronprocessobject.h"
 /**
 * @brief The multi-thread class for function module
 * Any function module inherits ineuronprocessobject can use this thread class. This class is based on Qt threading module.
 */
class BinaryThread : public QThread
{
	Q_OBJECT
public:
	BinaryThread(QObject *parent);
	~BinaryThread();
	/**
	* @brief Set the working class pointer.
	* @param arg The base pointer to working class that inherit ineuronprocessobject
	*/
    void setParam(INeuronProcessPointer arg);
	void stop();
	/**
	* @brief Return the working status.
	* @return Working status.
	*/
    ProcStatPointer RetVal()const{ return retVal; }

protected:
	void run();

signals:

private:
	volatile bool stopped;//no use
	///--------------data------------------------------
	bool			isInit;//
    INeuronProcessPointer filter;
	//run status----//
    ProcStatPointer retVal;
};

#endif