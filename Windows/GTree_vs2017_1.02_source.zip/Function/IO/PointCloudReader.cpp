#include "PointCloudReader.h"
#include "../../ngtypes/volume.h"
#include "Function/volumealgo.h"
#include "Function/NGUtility.h"


PointCloudReader::PointCloudReader()
{
	className_ = std::string("PointCloudReader");
	m_Source = std::shared_ptr<SVolume>(new SVolume(this));//2015-6-8
	isFileValid = false;
}


PointCloudReader::~PointCloudReader()
{
}

bool PointCloudReader::SetInputFileName(const std::string &path)
{
	FILE* fp = fopen(path.c_str(), "r");
	if (NULL == fp) {
		printf("can not open file : %s.\n error from %s", path.c_str(), className_.c_str());
		return false;
	}
	else {
		filename = path;
		isFileValid = true;
	}
	fclose(fp);
	return true;
}

ProcStatPointer PointCloudReader::Update()
{
	if (isFileValid) {
		if (!ReadImage(filename.c_str())) {
			printf("error occurred in %s\n", className_.c_str());
			MAKEPROCESSSTATUS(resSta, false, className_, "File is invalid.");
			return resSta;
		}
		//printf("can not read image file.this is %s", identifyName.c_str());
	}
	MAKEPROCESSSTATUS(resSta, true, className_, "");
	return resSta;
}

INEURONPROCESSOBJECT_RELEASEDATA_IMPLE(PointCloudReader)
INEURONPROCESSOBJECT_GETOUTPUT_IMPLE(PointCloudReader, SVolume)

bool PointCloudReader::ReadImage(const char* path) {
	FILE *fp = fopen(path, "r");
	if (!fp) {
		printf("cannot write point cloud data.\n");
		return false;
	}
	int num, val; size_t x, y, z;
	fscanf(fp, "num=%d", &num);
	fscanf(fp, "x=%llu,y=%llu,z=%llu\n", &x, &y, &z);
	if (!m_Source) m_Source = std::shared_ptr<SVolume>(new SVolume(this));
	m_Source->SetProcessObject(this);//Attach m_Source/OrigImage to this module.
	VolumePointer image = std::dynamic_pointer_cast<SVolume>(m_Source);//2015-6-8 type conversion
	image->SetDataType(DATATYPE::IMAGE16);
	image->SetSize(x, y, z);
	image->SetResolution(1,1,1);
	auto &img = *image;
	size_t i, j, k; 
	while (!feof(fp)) {
		fscanf(fp, "%llu %llu %llu %d ", &i, &j, &k, &val);
		img(i, j, k) = val;
	}
	fclose(fp);
	return true;
}
