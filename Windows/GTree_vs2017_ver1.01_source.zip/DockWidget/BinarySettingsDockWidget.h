#ifndef BINARYSETTINGSDOCKWIDGET_H
#define BINARYSETTINGSDOCKWIDGET_H

#include <QDockWidget>
#include <QCloseEvent>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QImage>
#include <QGridLayout>
#include <QPushButton>
#include "../ngtypes/ParamPack.h"
#include "./NGTreeWidget.h"
#include "Render/neuroglwidget.h"
#include "Function/IO/Prestore.h"

namespace Ui {
	class BinarySettingsDockWidget;
}

#define DEFINE_VALUECHANGED(supername, uiname, varname, type) void supername::on_##uiname##_valueChanged(type arg) \
{ \
    paramPack->varname = arg; \
}

#define DEFINE_EDITINGFINISHED_SIGNAL(supername, uiname, varname, signal) void supername::on_##uiname##_editingFinished() \
{ \
    if(paramPack->varname != ui->uiname->value()){\
        paramPack->varname = ui->uiname->value(); \
        if(!xyzSpinBoxSignalControl_) emit signal; }\
}

#define IMPL_SETFUNC(funcname, type) void funcname(type arg)

#define DEFINE_SETFUNC(supername, funcname, varname, uiname, type) void supername::funcname(type arg) \
{ \
    paramPack->varname = arg; \
    ui->uiname->setValue(arg); \
}

class BinarySettingsDockWidget : public QDockWidget
{
	Q_OBJECT

public:
	explicit BinarySettingsDockWidget(QWidget *parent = 0, NGParamPack param = NGParamPack());
	virtual ~BinarySettingsDockWidget();
	void SetApplyReadImageButton(bool arg);
	void SetAxonDiffuseValue(double);
	void SetAxonTraceValue(double);
	void SetAxonSemiautoTraceThreshold(double);//2018-1-22
	void SetAxonSemiautoConnectResample(double);//2018-2-9
	void SetBinaryApplyButtonEnable(bool arg);
	void SetDiffuseValue(double);
	void SetDisplayOpacValue(int, int);
	void SetImageRange(int x, int y, int z);
	void SetMaxThickness(int arg);
	void SetMaxBoundNum(int arg);
	void SetParam(NGParamPack arg);
	void SetTraceValue(double);
	void GetROIValues(double *);
	void UpdateGUI();
	void UpdateImageROILabel();
	void UpdateImageROILabel(double *arg);
	void UpdateParam();
	void UpdateImageExtractLabel();
	void UpdateTreeWidget();
	void UpdateCheckWidget();
	void UpdateImageScale();

	//deep
	void SetDeepRangeValues(int *);
	void SetDeepStartPosition(int *);
	void SetDeepBlockSizeAndRedun(int *);
	void UpdateDeepModeImageRangeLabel();
	void UpdateDeepNext(bool);
	void UpdateDeepDockWidgetEnabled(bool);
	void GetDeepEmptyData(bool &);
	void GetDeepCurves(bool &);
	void GetDeepShapes(bool &);
	void GetDeepRangeValues(int *);
	void GetDeepStartPosition(int *);
	void GetDeepBlockSizeAndRedun(int *);

signals:
	void ApplyReadImage_Signal();
	void DisplayNewOpac_Signal();
	void MaxBoundNumChanged_Signal(int);
	void NeedBinary_Signal();
	void NeedTrace_Signal();
	void ROIChanged_Signal();
	void ThicknessChanged_Signal(int);
	void ClearCache_Signal();

	void ActiveTree_Signal(int);
	void CompareTree_Signal(int);
	void ToggleTreeVisible_Signal(int);
	void GotoDiff_Signal(int);
	void ToggleTraverse_Signal(bool);
	void Annotate_Signal();
	void BackTraverse_Signal();
	void NextTraverse_Signal();
	void ToggleShowDiffArrow_Signal(bool);
	void ResetTraverse_Signal();
	void ToggleShowTraverseFlag_Signal();
	void OpacAdjustApply_Signal();
	void PreviewOpacAdjust_Signal(bool);
	void PreviewBinary_Signal(bool);
	void PreviewAxonBinary_Signal(bool);

	void Test_Signal();

	//deep
	void ToggleDeepTraverse_Signal(bool);
	void NextDeepTraverse_Signal();
	void DeepTraverseMaker_Signal();
	void ReadCurPosButton_Signal();
	void DeepInitial_Signal();

protected:
	void closeEvent(QCloseEvent * event);
	//QTreeWidgetItem* AddTreeNode(QTreeWidgetItem* parent, QString, double x, double y, double z );
	//void CreateActions();
	bool IsActiveTree(int arg);
	//void UpdateSuspiciousWidget();

private slots:
	void on_xMinspinBox_editingFinished();
	void on_xMaxspinBox_editingFinished();
	void on_yMinspinBox_editingFinished();
	void on_yMaxspinBox_editingFinished();
	void on_zMinspinBox_editingFinished();
	void on_zMaxspinBox_editingFinished();

	void on_applyImageReadButton_clicked();
	void on_axonDiffuseValueSpinBox_valueChanged(double);
	void on_axonThresholdSpinBox_valueChanged(double);
	void on_axonTraceValueSpinBox_valueChanged(double);
	void on_axonSemiautoTraceTresholdSpinBox_valueChanged(double);//2018-1-22
	void on_axonSemiautoConnectResampleSpinBox_valueChanged(double);//2018-2-9
	void on_diffuseValueSpinBox_valueChanged(double);
	void on_highOpacSpinBox_valueChanged(int);
	void on_lowOpacSpinBox_valueChanged(int);
	void on_maxBoundNumSpinBox_editingFinished();
	void on_thicknessspinBox_valueChanged(int);
	void on_thresholdSpinBox_valueChanged(double);
	void on_traceValueSpinBox_valueChanged(double);
	void OpacValueChanged(int);
	void SetThickness_Slot(int);
	void on_xBlockSizespinBox_valueChanged(int);//radius
	void on_yBlockSizespinBox_valueChanged(int);
	void on_zBlockSizespinBox_valueChanged(int);

	void on_action_ClearCache_Button_clicked();//action_ClearCache_Button

	void ActivateTree_Slot(int);
	void CompareTree_Slot(int);
	void ToggleTreeVisible_Slot(int);
	void GotoDiff_Slot(int);
	void ToggleTraverse_Slot(bool);
	void Annotate_Slot();
	void BackTraverse_Slot();
	void NextTraverse_Slot();

	void Test_Slot();

	//void UpdateHistogram();//2018-2-10

	void ToggleShowDiffArrow_Slot(bool);

	void ResetTraverse_Slot();

	//void on_SmoothCombox_currentTextChanged(const QString &arg1);
	void on_SmoothSlider_valueChanged(int arg1);//2018 03 29


	void UpdateTreeWidget_Slot();
	void UpdateCheckWidget_Slot();
	void ToggleShowTraverseFlag_Slot();

	void on_enableSVMBox_toggled(bool);
	void on_GPSSVMcheckBox_toggled(bool);
	void on_strongSignalCheckBox_toggled(bool);
	void on_AveragecheckBox_toggled(bool);
	void on_CrudeShapecheckBox_toggled(bool);
	void on_BigSomacheckBox_toggled(bool);


	void on_xScaleSpinBox_valueChanged(int);
	void on_yScaleSpinBox_valueChanged(int);
	void on_zScaleSpinBox_valueChanged(int);
	void on_origLowOpacSpinBox_valueChanged(int);
	void on_origHighOpacSpinBox_valueChanged(int);
	void on_destLowOpacSpinBox_valueChanged(int);
	void on_destHighOpacSpinBox_valueChanged(int);

	//more button
	void on_imageOpacInfoButton_clicked();
	void on_opacApplyButton_clicked();
	void on_previewIlluminationMapButton_clicked(bool);
	void on_previewBinaryButton_clicked(bool);
	void on_previewAxonBinaryButton_clicked(bool);

	//deep
	void ToggleDeepTraverse_Slot(bool);
	void NextDeepTraverse_Slot();
	void ReadCurPosButton_Slot();
	void DeepInitial_Slot();

	//void mouseMoveEvent(QMouseEvent *);
private:
	Ui::BinarySettingsDockWidget *ui;
	NGParamPack paramPack;
	bool xyzSpinBoxSignalControl_;
	QPushButton *startTraverse_, *backButton_, *nextButton_, *annotateLabel_;
	QPushButton *testButton_, *DeepButton_;
	QWidget *buttonWidget_1, *buttonWidget_2;
	NGTreeWidget *treeWidget, *checkWidget;
	NeuroGLWidget *nn;
	NGPrestore preStore;
	//QGridLayout *gridLayout;
	//QImage _histimage;//2018-2-10
	//unsigned short grayRange;//2018-2-10
};

#endif // BINARYSETTINGSDOCKWIDGET_H

