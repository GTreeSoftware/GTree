#ifndef DATAREDUTHREAD_H
#define DATAREDUTHREAD_H

#include <QThread>
#include <memory>
#include <algorithm>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include "../ngtypes/soma.h"
#include "../Function/Trace/NeuroGPSTreeFilter.h"
#include "../ngtypes/tree.h"
#include "../ngtypes/basetypes.h"
#include "../Function/IO/MOSTDReader.h"
#include <QReadWriteLock>
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
class DataReduThread : public QThread
{
	Q_OBJECT

public:
	DataReduThread(QObject *parent);
	~DataReduThread();
	void SetParam(const std::string &pth, NGParamPack &paramPack);
	void SetVecParam(int &, Vec3i &, Vec3i &, Vec3i &, Vec3i &);

signals:
	void ParallelTracerImagePosition_Signal(int, int, int);

private:
	NGNeuronBigReader mostdReader;
	NGParamPack paramPack4Redu;
	bool isInitParam,isInitVecParam;
	int xExtract, yExtract, zExtract;// block size, Max-Min
	int xStride, yStride, zStride;// Extract - Rendundancy
	int xRangeMax, yRangeMax, zRangeMax;
	int xVecMax, yVecMax, zVecMax;
	std::string MostdFilePath;
	int VecTotal;
	QReadWriteLock readwriteLock;
	void run();
	void Save(NGParamPack&,IDataPointer &, int &, int &, int &);

};

#endif // DATAREDUTHREAD_H
