#pragma once

#include <memory>
#include <string>
#include "../ineuronio.h"
#include "../../ngtypes/ParamPack.h"
template<typename T> class Volume;
typedef Volume<unsigned char> CVolume;
typedef Volume<unsigned short> SVolume;
class INeuronDateObject;
class PointCloudReader;

typedef std::shared_ptr<PointCloudReader> NGPointCloudReader;

class PointCloudReader:public INeuronIO
{
public:
	typedef std::shared_ptr<SVolume> VolumePointer;
	static NGPointCloudReader New() { return NGPointCloudReader(new PointCloudReader()); }

	PointCloudReader();
	virtual ~PointCloudReader();
	INEURONPROCESSOBJECT_DEFINE
	bool SetInputFileName(const std::string&);
	void SetParam(NGParamPack arg) { paramPack = arg; }
	bool GetImageInfo(const std::string&);//save information into paramPack
	DATATYPE GetImageType()const { return dataType; }

protected:
	//--- do not use--//
	void SetInput(ConstIDataPointer&) {}
	bool SetOutputFileName(const std::string&) { return false; }
	//---//
	bool ReadImage(const char*);

private:
	bool isFileValid;
	std::string filename; //read path
	DATATYPE dataType;
	NGParamPack paramPack;
};

