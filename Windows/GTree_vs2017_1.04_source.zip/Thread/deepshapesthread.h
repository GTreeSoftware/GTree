#ifndef DEEPSHAPESTHREAD_H
#define DEEPSHAPESTHREAD_H

#include <QApplication> 
#include <QThread>
#include <memory>
#include <algorithm>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include <QReadWriteLock>
class CaliberBuilder;
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);

class deepshapesthread : public QThread
{
	Q_OBJECT

public:
	deepshapesthread(QObject *parent);
	~deepshapesthread();
	void SetParam(NGParamPack &arg1);
	void stop();
protected:
	void run();
private:
	NGNeuronBigReader mostdReader;
	NGParamPack paramPack;
	QReadWriteLock readwriteLock;
	std::vector<Line5d> curves;
	//NGCaliberBuilder caliberBuilder;
	CellVec3d shapes;
	bool isInit;
	bool Save_();
	
};

#endif // DEEPSHAPESTHREAD_H
