#include "deepshapesthread.h"
#include "Function/Trace/CaliberBuilder.h"
#include "Function/IO/imagewriter.h"
deepshapesthread::deepshapesthread(QObject *parent)
	: QThread(parent)
{
	isInit = false;
	//paramPack = std::make_shared<ParamPack>();
}

deepshapesthread::~deepshapesthread()
{

}

void deepshapesthread::SetParam(NGParamPack &arg1){
	paramPack = arg1;
	isInit = true;
}

void deepshapesthread::run(){
	if (isInit)
	{
		if (paramPack->OrigImage){
			int xmin = paramPack->xMin_;
			int ymin = paramPack->yMin_;
			int zmin = paramPack->zMin_;
			int xmax = paramPack->xMax_;
			int ymax = paramPack->yMax_;
			int zmax = paramPack->zMax_;
			NG_CREATE_DYNAMIC_CAST(NeuronPopulation, alltree, paramPack->separateTree);
			auto pop_ = alltree->m_pop;
			Line5d tmpcurve, cursubCurves;
			Vec5d curCoord;
			curves.clear();
			for (auto &tree_ : pop_)
			{
				auto allcurve = tree_->m_curveList;
				for (int i = 0; i < allcurve.size(); ++i){
					tmpcurve = allcurve[i];
					cursubCurves.clear();
					for (int j = 0; j < tmpcurve.size(); ++j){
						curCoord = tmpcurve[j];
						if (curCoord(0) > xmax || curCoord(0) < xmin || curCoord(1) > ymax || curCoord(1) < ymin || curCoord(2) > zmax || curCoord(2) < zmin) continue;
						if (curCoord(0) < xmax && curCoord(0) > xmin && curCoord(1) < ymax && curCoord(1) > ymin && curCoord(2) < zmax && curCoord(2) > zmin){
							cursubCurves.push_back(curCoord);//TODO:
						}
					}
					if (cursubCurves.size() > 0){
						curves.push_back(cursubCurves);
					}
				}
			}
		}
		if (curves.size()){
			if (curves[0].size() > 1)
			{
				NGCaliberBuilder caliberBuilder = CaliberBuilder::New();
				caliberBuilder->SetParam(paramPack);
				caliberBuilder->SetLinePoints(curves);
				if (!caliberBuilder->Update()->success()){
					return;
				}
				shapes.clear();
				shapes = *(caliberBuilder->GetCaliberPointSet());
			}
		}
		if (!Save_())return ;
		printf("Deep Traverse shapes thread.\n");
	}
}

bool deepshapesthread::Save_(){
	QString saveName;
	//save OrigImage
	if (paramPack->OrigImage) {
		saveName = paramPack->defaultDir + QString("/%1_%2_%3").arg(paramPack->xMin_).arg(paramPack->yMin_).arg(paramPack->zMin_) + QString(".tif");
		NGImageWriter writer = ImageWriter::New();
		writer->SetOutputFileName(saveName.toStdString());
		writer->SetInput(paramPack->OrigImage);//OrigImage
		auto res = writer->Update();
		if (!res->success()){
			printf("error in deepshapesthread Save_.\n");
			//QMessageBox::warning(this, QString::fromStdString(res->ErrorClassName()), QString::fromStdString(res->ErrorInfo()));
			return false;
		}
		printf("save image:%s\n", (const char*)saveName.toLocal8Bit());
	}
	//save curves
	if (curves.size()){
		if (curves[0].size() > 1)
		{
			for (int i = 0; i < curves.size(); ++i){
				QString swcPath = saveName.section('.', 0, -2) + QString(tr("_%1").arg(i, 3, 10, QChar('0'))) + QString(".swc");
				FILE* fp = fopen(swcPath.toStdString().c_str(), "w");
				if (!fp) return false;//TODO:
				for (int id = 0; id < curves[i].size(); ++id){
					if (id == 0){
						fprintf(fp, "%d 1 %lf %lf %lf 1.0 -1\n", id + 1, (curves[i][id](0) - paramPack->xMin_) *paramPack->xRes_,
							(curves[i][id](1) - paramPack->yMin_) *paramPack->yRes_, (curves[i][id](2) - paramPack->zMin_) *paramPack->zRes_);
					}
					else{
						fprintf(fp, "%d 1 %lf %lf %lf 1.0 %d\n", id + 1, (curves[i][id](0) - paramPack->xMin_) *paramPack->xRes_,
							(curves[i][id](1) - paramPack->yMin_) *paramPack->yRes_, (curves[i][id](2) - paramPack->zMin_) *paramPack->zRes_, id);
					}
				}
				fclose(fp);
			}
		}
	}
	//save shapes
	if (shapes.size()){
		if (shapes[0].size() > 1){
			QString shapesPath = saveName.section('.', 0, -2) + QString("_shapes.swc");
			FILE* fp = fopen(shapesPath.toStdString().c_str(), "w");
			if (!fp) return false;//TODO:
			int id = 0;
			for (int i = 0; i < shapes.size(); ++i){
				for (int j = 0; j < shapes[i].size(); ++j){
					fprintf(fp, "%d 1 %lf %lf %lf 1.0 -1\n", ++id, (shapes[i][j](0) - paramPack->xMin_) *paramPack->xRes_,
						(shapes[i][j](1) - paramPack->yMin_) *paramPack->yRes_, (shapes[i][j](2) - paramPack->zMin_) *paramPack->zRes_);
				}

			}
			fclose(fp);
		}
	}
	return true;
}