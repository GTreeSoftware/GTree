/**
 * @file contourutil.h
 * @brief Auxiliary function for soma shape reconstruction
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef CONTOURUTIL_H
#define CONTOURUTIL_H
#include <vector>
#include "../ngtypes/basetypes.h"
template<typename T> class Volume;
typedef Volume<NGCHAR> CVolume;
typedef Volume<unsigned short> SVolume;
typedef Volume<double> DVolume;

struct ContourUtil
{
	/**
	* @brief Calculate the surface and volume of the connected point set.
	* @param dataPP Connected point set.
	* @param Theta Spatial angle division.
	* @param Phi Spatial angle division.
	* @param Patch 3D triangular patch
	* @param area Surface value.
	* @param cellVol Volume value.
	* @return Void
	*/
    static void CalAreaVolume(const VectorVec3d &dataPP, const int Theta, const int Phi,
        VectorVec3d &Patch, double &area, double &cellVol);
	/**
	* @brief Auxiliary function of CalAreaVolume.
	* @return Void
	*/
    static void AddAreaVolume(const Vec3d &center, const Vec3d &A, const Vec3d &B, const Vec3d &C,
        Vec3d &AB, Vec3d &AC, Vec3d &OA, Vec3d &OB, Vec3d &OC,
        double &area, double &cellVol);

	/**
	* @brief Calculate the burst ray length limited by threshold from input seed.
	* @param sphereRayWet Resampled volume image.
	* @param constrictionThrev Limitation threshold.
	* @param ray_limit Ray length list.
	* @return Void
	*/
    static void GetRayLimit(const DVolume &sphereRayWet,
        const double constrictionThrev,
        std::vector<std::vector<double> > &ray_limit);
	/**
	* @brief Auxiliary function of CalculateOneRayLimit.
	* @return Void
	*/
    static void CalculateOneRayLimit(const std::vector<double> &ray,
        const double constriction_threv,
        int &one_ray_limit);

	/**
	* @brief Auxiliary function of CalculateOneRayLimit.
	* @return Void
	*/
    static void CalculateSphereOneNode(const CVolume &locOrigImg,
        const double value, 
        const double x, 
        const double y, 
        const double z, 
        double &segmentDense,
        double& segmentWet);

	/**
	* @brief Auxiliary function of soma shape reconstruction.
	* @return Void
	*/
    static void GetGradientVectorFlow(const DVolume &Sphere_XX, DVolume &Uz);
	/**
	* @brief Auxiliary function of GetGradientVectorFlow.
	* @return Void
	*/
    static void SmoothGradientCurves(const std::vector<double> &ttk, std::vector<double> &S_diffttk);
	/**
	* @brief Auxiliary function of Soma shape reconstruction.
	* @return Void
	*/
    static void GetBoundaryBack(const std::vector<double> &outer_shell, 
        const double threv, 
                                std::vector<double> &boundary_back);

	/**
	* @brief Auxiliary function of CalculateOneRayLimit.2015-6-8
	* @return Void
	*/
    static void CalculateSphereOneNode(const SVolume &locOrigImg, const double value,
                                       const double x, const double y, const double z,
                                       double &segmentDense, double &segmentWet);
};



#endif
