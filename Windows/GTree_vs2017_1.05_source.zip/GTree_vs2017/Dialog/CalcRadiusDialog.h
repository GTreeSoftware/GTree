/**
 * @file CalcRadiusDialog.h
 * @brief A dialog for inputing parameters of calculating the radius.
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#pragma once
#include <QDialog>
#include <QString>


namespace Ui {
	class CalcRadiusDialog;
}

/**
 * @brief The dialog class for input the parameter of the radius calculation.
 * The class inherited Qdialog class from QT diaglog base class.
 */
class CalcRadiusDialog : public QDialog
{
	Q_OBJECT

public:
	explicit CalcRadiusDialog(QWidget *parent = 0);
	~CalcRadiusDialog();
	/**
	* @brief Get the save directory.
	*
	* @return Save directory
	*/
	const QString GetSaveDir() const;
	/**
	* @brief Get the prefix name of saved files.
	*
	* @return Prefix name
	*/
	const QString GetSavePre() const;
private slots:

	void on_openSaveDirButton_clicked();
private:
	Ui::CalcRadiusDialog *ui;
	QString oldDirPath_;
};

