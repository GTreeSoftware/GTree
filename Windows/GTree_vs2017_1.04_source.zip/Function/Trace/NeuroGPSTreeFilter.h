/**
 * @file NeuroGPSTreeFilter.h
 * @brief Automatic neuronal population tracing
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef NEUROGPSTREEFILTER_H
#define NEUROGPSTREEFILTER_H
#include "../ineuronprocessobject.h"
#include "../ngtypes/ineurondataobject.h"
#include "../../ngtypes/basetypes.h"
#include "../../ngtypes/volume.h"
#include "../../ngtypes/ParamPack.h"
#include "../../ngtypes/tree.h"
class NeuroGPSTreeFilter;
class BinaryFilter;
class TraceFilter;
class BridgeBreaker;
class NeuroTreeCluster;
NG_SMART_POINTER_TYPEDEF(NeuroGPSTreeFilter, NGNeuroGPSTreeFilter);
NG_SMART_POINTER_TYPEDEF(BinaryFilter, NGBinaryFilter);
NG_SMART_POINTER_TYPEDEF(TraceFilter, NGTraceFilter);
NG_SMART_POINTER_TYPEDEF(BridgeBreaker, NGBridgeBreaker);
NG_SMART_POINTER_TYPEDEF(NeuroTreeCluster, NGNeuronTreeCluster);

/**
* @brief Automatic neuronal population tracing
* Automatic neuronal population tracing. More information in NeuroGPS-Tree article. 
* Cited by "NeuroGPS-Tree: automatic reconstruction of large-scale neuronal populations with dense neurites"
*/
class NeuroGPSTreeFilter : public INeuronProcessObject
{
public:
	static NGNeuroGPSTreeFilter New() { return NGNeuroGPSTreeFilter(new NeuroGPSTreeFilter()); }
	NeuroGPSTreeFilter();
	~NeuroGPSTreeFilter();
	//INEURONPROCESSOBJECT_DEFINE
	/**
	* @brief Start automatic neuronal population tracing.
	* @return Tracing status
	*/
	virtual ProcStatPointer Update();
	virtual ConstIDataPointer GetOutput();
	virtual IDataPointer ReleaseData();
	/**
	* @brief Import the wrapper of common parameters.
	* @param arg The wrapper of common parameters.
	* @return void
	*/
	void SetParam(NGParamPack arg) { param_ = arg; }
	void SetSoma(ConstIDataPointer arg);
	ProcStatPointer UpdateSomaRecon(VectorVec3d &r);

protected:
	/**
	* @brief Calculate the image scale ratio according to the resolution ratio. It will be removed.
	*
	* @deprecated
	*/
	int SetScale(double res);
	/**
	* @brief Reorganise the traced neurites and build tree structure.
	* @param neuronTree The traced results of neurons
	* @param treeIDList the ID list of traced neuron trees.
	* @somaList The position sets of soma.
	* @return Building status.
	*/
	bool GenerateDendritePopulation(std::vector<NeuronTreePointer>& neuronTree, std::vector<size_t> &treeIDList, VectorVec3d& somaList);
private:
	NGParamPack param_;//orig, bin, back
	//Data
	IDataPointer scaleImg_;
	IDataPointer reconImg_;
	NG_SMART_POINTER_DEFINE(VectorVec3i, m_binPtSet);
	ConstIDataPointer soma_;
	IDataPointer tree_;
	IDataPointer treeConInfo_;
	//filter
	NGBinaryFilter binaryFilter;
	NGTraceFilter traceFilter;
	NGBridgeBreaker breaker;
	NGNeuronTreeCluster treeCluster;

};
#endif
