/********************************************************************************
** Form generated from reading UI file 'CalcRadiusDialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALCRADIUSDIALOG_H
#define UI_CALCRADIUSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CalcRadiusDialog
{
public:
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer;
    QLineEdit *savePreEdit;
    QLineEdit *saveDirEdit;
    QPushButton *openSaveDirButton;
    QLabel *label_3;
    QHBoxLayout *hboxLayout;
    QSpacerItem *spacerItem;
    QPushButton *okButton;
    QPushButton *cancelButton;

    void setupUi(QDialog *CalcRadiusDialog)
    {
        if (CalcRadiusDialog->objectName().isEmpty())
            CalcRadiusDialog->setObjectName(QString::fromUtf8("CalcRadiusDialog"));
        CalcRadiusDialog->resize(373, 122);
        gridLayout_2 = new QGridLayout(CalcRadiusDialog);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_4 = new QLabel(CalcRadiusDialog);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 2, 1, 1);

        savePreEdit = new QLineEdit(CalcRadiusDialog);
        savePreEdit->setObjectName(QString::fromUtf8("savePreEdit"));

        gridLayout->addWidget(savePreEdit, 1, 1, 1, 1);

        saveDirEdit = new QLineEdit(CalcRadiusDialog);
        saveDirEdit->setObjectName(QString::fromUtf8("saveDirEdit"));

        gridLayout->addWidget(saveDirEdit, 0, 1, 1, 1);

        openSaveDirButton = new QPushButton(CalcRadiusDialog);
        openSaveDirButton->setObjectName(QString::fromUtf8("openSaveDirButton"));

        gridLayout->addWidget(openSaveDirButton, 0, 2, 1, 1);

        label_3 = new QLabel(CalcRadiusDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 0, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        hboxLayout = new QHBoxLayout();
        hboxLayout->setSpacing(6);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        spacerItem = new QSpacerItem(131, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        okButton = new QPushButton(CalcRadiusDialog);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        hboxLayout->addWidget(okButton);

        cancelButton = new QPushButton(CalcRadiusDialog);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

        hboxLayout->addWidget(cancelButton);


        verticalLayout->addLayout(hboxLayout);


        gridLayout_2->addLayout(verticalLayout, 0, 0, 1, 1);


        retranslateUi(CalcRadiusDialog);
        QObject::connect(okButton, SIGNAL(clicked()), CalcRadiusDialog, SLOT(accept()));
        QObject::connect(cancelButton, SIGNAL(clicked()), CalcRadiusDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(CalcRadiusDialog);
    } // setupUi

    void retranslateUi(QDialog *CalcRadiusDialog)
    {
        CalcRadiusDialog->setWindowTitle(QApplication::translate("CalcRadiusDialog", "Dialog", nullptr));
        label_4->setText(QApplication::translate("CalcRadiusDialog", "savePre", nullptr));
        openSaveDirButton->setText(QApplication::translate("CalcRadiusDialog", "...", nullptr));
        label_3->setText(QApplication::translate("CalcRadiusDialog", "saveDir", nullptr));
        okButton->setText(QApplication::translate("CalcRadiusDialog", "OK", nullptr));
        cancelButton->setText(QApplication::translate("CalcRadiusDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CalcRadiusDialog: public Ui_CalcRadiusDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALCRADIUSDIALOG_H
