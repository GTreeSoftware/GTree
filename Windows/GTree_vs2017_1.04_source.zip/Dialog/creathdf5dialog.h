/**
 * @file creathdf5dialog.h
 * @brief A dialog to creat big data in hdf5 format
 * @details In order to observe local area of large image whose thickness is more than 512 pixels, GTree can creat HDF5 format data for large tif format data.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef CREATHDF5DIALOG_H
#define CREATHDF5DIALOG_H

#include <QDateTime>
#include <QEvent>
#include "ngtypes/ParamPack.h"
#include "Function/IO/imagereader.h"
#include "ui_creathdf5dialog.h"

 /**
  * @brief The dialog class for creating big data in hdf5 format.
  * In order to observe local area of large image whose thickness is more than 512 pixels, GTree can creat HDF5 format data for large tif format data.
  */
class creathdf5dialog : public QDialog
{
	Q_OBJECT

public:
	creathdf5dialog(QWidget *parent = 0);
	~creathdf5dialog();

	QString saveH5;
	std::vector<std::string> tiffList;
	bool closeFlag = true;
	bool tiffFlag = false;
	double xResolution = 0;
	double yResolution = 0;
	double zResolution = 0;
	/**
	* @brief Set the parameters wrapper of HDF5 building.
	*
	* @return Void.
	*/
	void SetParam(NGParamPack arg) { paramPack = arg; }

private slots:
	void on_okButton_clicked();
	void on_SelectButton_clicked();
	void on_pathButton_clicked();
	void on_cancelButton_clicked();
	void on_enterPressed();
	int getMaxLevelNum(int, int, int);

private:
	Ui::creathdf5dialog ui;
	QString fileList;
	QString saveDir;
	QDateTime selectTime;
	bool pathFlag = false;
	NGParamPack paramPack;

};

#endif // CREATHDF5DIALOG_H

