/**
 * @file binaryfilter.h
 * @brief Image binary segmentation
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef BINARYFILTER_H
#define BINARYFILTER_H
#include "../ngtypes/ParamPack.h"
#include "ineuronprocessobject.h"
#include "../ngtypes/basetypes.h"
#include "../ngtypes/volume.h"
class BinaryFilter;
NG_SMART_POINTER_TYPEDEF(BinaryFilter, NGBinaryFilter);
NG_SMART_POINTER_TYPEDEF(ParamPack, NGParamPack);

/**
* @brief The class for image binary segmentation.
* The segmentation method can be seen in NeuroGPS article. This function class is implemented using fast convolution technology. 
*/
class BinaryFilter : public INeuronProcessObject
{
public:
	NG_SMART_POINTER_TYPEDEF(VectorVec3i, BinPtSetPointer);
	static NGBinaryFilter New() { return NGBinaryFilter(new BinaryFilter()); }
	BinaryFilter();
	~BinaryFilter();
	INEURONPROCESSOBJECT_DEFINE
		/*bool Update();
		ConstIDataPointer GetOutput();
		IDataPointer ReleaseData();*/
	ConstIDataPointer GetBackNoiseImage();
	VectorVec3i &GetBinPtSet();
	IDataPointer ReleaseBackNoiseImage();
	void SetParam(NGParamPack arg) { paramPack = arg; }
	/**
	* @brief Set binary threshold.
	* param arg Binary threshold.
	*
	* @return void.
	*/
	void SetThreshold(double arg);

protected:
	/**
	* @brief Implementation of binary segmentation.
	*
	* @return Binary segmentation status.
	*/
	bool Binary();
private:
	//void CalcBackImage(const SVolume&, SVolume&, int);//Unused
	void CalcRandomMean(const SVolume&, double&);
	double binThreshold_;
	NGParamPack paramPack;
	//m_Source binary image
	IDataPointer m_Back;//backnoise
	//ConstIDataPointer m_Recon;
	VectorVec3i m_BinPtSet;
};

#endif // BINARYFILTER_H
