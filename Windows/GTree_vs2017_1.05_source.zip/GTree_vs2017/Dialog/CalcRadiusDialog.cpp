#include <QFileDialog>
#include "CalcRadiusDialog.h"
#include  "ui_CalcRadiusDialog.h"

CalcRadiusDialog::CalcRadiusDialog(QWidget *parent):
	QDialog(parent),
	ui(new Ui::CalcRadiusDialog)
{
	ui->setupUi(this);
	ui->savePreEdit->setText("test_");
}

CalcRadiusDialog::~CalcRadiusDialog()
{
	delete ui;
}


const QString CalcRadiusDialog::GetSaveDir() const
{
	return ui->saveDirEdit->text();
}

const QString CalcRadiusDialog::GetSavePre() const
{
	return ui->savePreEdit->text();
}

void CalcRadiusDialog::on_openSaveDirButton_clicked()
{
	auto saveDir = QFileDialog::getExistingDirectory(this, "Set Save Dir", oldDirPath_);
	ui->saveDirEdit->setText(saveDir);
}
