#include "ImageScaleFiter.h"


ImageScaleFiter::ImageScaleFiter()
{
	className_ = std::string("ImageScaleFiter");
	NG_SMART_POINTER_NEW(SVolume, m_Source, this);
	NG_SMART_POINTER_NEW(SVolume, reconOutput, this);
}


ImageScaleFiter::~ImageScaleFiter()
{

}

ProcStatPointer ImageScaleFiter::Update()
{
	if (!m_Input) {
		NG_ERROR_MESSAGE("no input image data.");
		MAKEPROCESSSTATUS(resSta, false, className_, "There is no image data.");
		return resSta;
	}
	if (paramPack_->xScale_ < 1 && paramPack_->yScale_ < 1) {
		NG_ERROR_MESSAGE("Up sampling function is not developed.");
		MAKEPROCESSSTATUS(resSta, false, className_, "Up sampling function is not developed.");
		return resSta;
	}

	NG_CREATE_DYNAMIC_CAST(SVolume, tmpSource, m_Source);
	NG_CREATE_DYNAMIC_CAST(SVolume, tmpImg, m_Input);
	//NG_CREATE_DYNAMIC_CAST(SVolume, tmpRecon, reconInput);
	//NG_CREATE_DYNAMIC_CAST(SVolume, tmpReconOut, reconOutput);
	if (paramPack_->xScale_ == 1 && paramPack_->yScale_ == 1 && paramPack_->zScale_ == 1) {

		int rx, ry, rz;
		rx = tmpImg->x();
		ry = tmpImg->y();
		rz = tmpImg->z();
		//tmpReconOut->SetSize(rx, ry, rz);
		if (m_Input->DataType() == DATATYPE::IMAGE16) {
			m_Source = m_Input;//do nothing
			/*for (int ij = 0; ij < rz; ++ij) {
				for (int i = 0; i < rx; ++i) {
					for (int j = 0; j < ry; ++j) {
						tmpReconOut->operator()(i, j, ij) = 2 * tmpRecon->operator()(i, j, ij) + tmpImg->operator()(i, j, ij);
					}
				}
			}
			tmpReconOut->SetResolution(tmpImg->XResolution(), tmpImg->YResolution(), tmpImg->ZResolution());*/
		}
		else {//8bit image will multiply 4
			tmpSource->QuickCopy(*tmpImg);
			//tmpReconOut->SetSize(rx, ry, rz);
			for (int ij = 0; ij < rz; ++ij) {
				for (int i = 0; i < rx; ++i) {
					for (int j = 0; j < ry; ++j) {
						tmpSource->operator()(i, j, ij) *= 4;
						//tmpReconOut->operator()(i, j, ij) = 2 * tmpRecon->operator()(i, j, ij) + tmpImg->operator()(i, j, ij);
					}
				}
			}
		}
		tmpSource->SetResolution(tmpImg->XResolution(), tmpImg->YResolution(), tmpImg->ZResolution());
		//tmpReconOut->SetResolution(tmpImg->XResolution(), tmpImg->YResolution(), tmpImg->ZResolution());
	}
	else {
		int rx, ry, rz;
		rx = tmpImg->x() / paramPack_->xScale_;
		ry = tmpImg->y() / paramPack_->yScale_;
		rz = tmpImg->z() / paramPack_->zScale_;
		int temp(0), tempRecon(0); int maxValue(0), maxReconValue(0);
		int xLen = tmpImg->x();
		int xyLen = tmpImg->x()  *  tmpImg->y();
		//tmpReconOut->SetSize(rx, ry, rz);
		tmpSource->SetSize(rx, ry, rz);
		tmpSource->SetResolution(tmpImg->XResolution() * paramPack_->xScale_, tmpImg->YResolution() * paramPack_->yScale_, tmpImg->ZResolution());
		//tmpReconOut->SetResolution(tmpImg->XResolution() * paramPack_->xScale_, tmpImg->YResolution() * paramPack_->yScale_, tmpImg->ZResolution());
		if (tmpImg->DataType() == DATATYPE::IMAGE16) {
			double ratio = 1.0 / double(paramPack_->xScale_ * paramPack_->yScale_ * paramPack_->zScale_);//down sample:Mean value pooling
			for (int ij = 0; ij < rz; ++ij) {
				for (int i = 0; i < rx; ++i) {
					for (int j = 0; j < ry; ++j) {
						temp = 0;
						if (paramPack_->isAverageResample) {
							maxReconValue = 0;
							for (int iijj = 0; iijj < paramPack_->zScale_; ++iijj) {
								for (int ii = 0; ii < paramPack_->xScale_; ++ii) {
									for (int jj = 0; jj < paramPack_->yScale_; ++jj) {
										temp += tmpImg->GetPointer()[i*paramPack_->xScale_ + ii 
											+ (j * paramPack_->yScale_ + jj) * xLen
											+ (ij * paramPack_->zScale_+iijj) * xyLen];
										/*if (reconFlag == 1) {
											tempRecon = tmpRecon->GetPointer()[i*paramPack_->xScale_ + ii + (j * paramPack_->yScale_ + jj) * xLen + ij * xyLen];
											if (maxReconValue < tempRecon) {
												maxReconValue = tempRecon;
											}
										}*/
									}
								}
							}
							tmpSource->operator ()(i, j, ij) = (unsigned short)(temp * ratio);
							/*if (reconFlag == 1)
							{
								tmpReconOut->operator()(i, j, ij) = 2 * maxReconValue + tmpSource->operator ()(i, j, ij);
							}*/
						}
						else {
							maxValue = 0;
							for (int iijj = 0; iijj < paramPack_->zScale_; ++iijj) {
								for (int ii = 0; ii < paramPack_->xScale_; ++ii) {
									for (int jj = 0; jj < paramPack_->yScale_; ++jj) {
										temp = tmpImg->GetPointer()[i*paramPack_->xScale_ + ii
											+ (j * paramPack_->yScale_ + jj) * xLen
											+ (ij * paramPack_->zScale_ + iijj) * xyLen];
										if (maxValue < temp) {
											maxValue = temp;
										}
										/*if (reconFlag == 1) {
											tempRecon = tmpRecon->GetPointer()[i*paramPack_->xScale_ + ii + (j * paramPack_->yScale_ + jj) * xLen + ij * xyLen];
											if (maxReconValue < tempRecon) {
												maxReconValue = tempRecon;
											}

										}*/
									}
								}
							}
							tmpSource->operator()(i, j, ij) = maxValue;
							/*if (reconFlag == 1) {
								tmpReconOut->operator()(i, j, ij) = 2 * maxReconValue + tmpSource->operator ()(i, j, ij);
							}*/
						}
					}
				}
			}
		}
		else {//8 bit image
			double ratio = 4.0 / double(paramPack_->xScale_ * paramPack_->yScale_ * paramPack_->zScale_);
			for (int ij = 0; ij < rz; ++ij) {
				for (int i = 0; i < rx; ++i) {
					for (int j = 0; j < ry; ++j) {
						temp = 0;
						if (paramPack_->isAverageResample) {
							for (int iijj = 0; iijj < paramPack_->zScale_; ++iijj) {
								for (int ii = 0; ii < paramPack_->xScale_; ++ii) {
									for (int jj = 0; jj < paramPack_->yScale_; ++jj) {
										temp += tmpImg->GetPointer()[i*paramPack_->xScale_ + ii
											+ (j * paramPack_->yScale_ + jj) * xLen
											+ (ij * paramPack_->zScale_ + iijj) * xyLen];
										/*if (reconFlag == 1) {
											tempRecon = tmpRecon->GetPointer()[i*paramPack_->xScale_ + ii + (j * paramPack_->yScale_ + jj) * xLen + ij * xyLen];
											if (maxReconValue < tempRecon) {
												maxReconValue = tempRecon;
											}

										}*/
									}
								}
							}
							tmpSource->operator ()(i, j, ij) = (unsigned short)(temp * ratio);
							/*if (reconFlag == 1) {
								tmpReconOut->operator()(i, j, ij) = 2 * maxReconValue + tmpSource->operator ()(i, j, ij);
							}*/
						}
						else {
							maxValue = 0;
							for (int iijj = 0; iijj < paramPack_->zScale_; ++iijj) {
								for (int ii = 0; ii < paramPack_->xScale_; ++ii) {
									for (int jj = 0; jj < paramPack_->yScale_; ++jj) {
										temp = tmpImg->GetPointer()[i*paramPack_->xScale_ + ii
											+ (j * paramPack_->yScale_ + jj) * xLen
											+ (ij * paramPack_->zScale_ + iijj) * xyLen];
										if (maxValue < temp) {
											maxValue = temp;
										}
										/*if (reconFlag == 1) {
											tempRecon = tmpRecon->GetPointer()[i*paramPack_->xScale_ + ii + (j * paramPack_->yScale_ + jj) * xLen + ij * xyLen];
											if (maxReconValue < tempRecon) {
												maxReconValue = tempRecon;
											}

										}*/
									}
								}
							}
							tmpSource->operator()(i, j, ij) = maxValue * 4;
							/*if (reconFlag == 1) {
								tmpReconOut->operator()(i, j, ij) = 2 * maxReconValue + tmpSource->operator ()(i, j, ij);
							}*/
						}
					}
				}
			}
		}
	}

	//adjust illumination
	if (paramPack_->highAdjustOpac_ != 0 && paramPack_->highDestOpac_ != 0) {//adjust
		tmpSource->Adjust(paramPack_->lowAdjustOpac_, paramPack_->highAdjustOpac_, paramPack_->lowDestOpac_, paramPack_->highDestOpac_);
	}

	MAKEPROCESSSTATUS(resSta, true, className_, "");
	return resSta;
}

IDataPointer ImageScaleFiter::ReleaseReconImage()
{
	reconOutput->ReleaseProcessObject();
	IDataPointer tData(reconOutput);
	reconOutput.reset();
	return tData;
}

INEURONPROCESSOBJECT_RELEASEDATA_IMPLE(ImageScaleFiter)
INEURONPROCESSOBJECT_GETOUTPUT_IMPLE(ImageScaleFiter, SVolume)
