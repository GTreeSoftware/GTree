#pragma once
#include <QObject>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/tree.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include "../../Thread/deepimagethread.h"
#include "../../Thread/deepshapesthread.h"
#include "ngtypes/volume.h"
#include <QMutex>
#include <QReadWriteLock>
#include <memory>

#include <tuple>
class ImageWriter;
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
class DeepTraverse;
NG_SMART_POINTER_TYPEDEF(DeepTraverse, NGDeepTraverse);
class DeepTraverse :public QObject,
	public INeuronProcessObject
{
	Q_OBJECT
public:
	static NGDeepTraverse New(){ return NGDeepTraverse(new DeepTraverse()); };
	DeepTraverse();
	~DeepTraverse();
	
	void SetParam(const std::string& pth,NGParamPack &arg2);
	void SetReadParam(double xx,double yy,double zz);
	void SetEmptyData(bool);
	void SetSaveCurves(bool);
	void SetSaveShapes(bool);
	void SetImageRange(int *);
	void SetStartPosition(int *);
	void SetPatchSize(int *);

	bool Initial();
	void Reset();
	bool GetNextImage();
	void GetImagePosition(Vec3d &BegPos, Vec3d &EndPos);
	bool GetCurDataSet( std::vector<Line5d> &curves, CellVec3d &shapes);//output current image and shape reconstruction of curve
	void GetRange(Vec3d &RMin,Vec3d &Rmax);
protected:
	virtual ProcStatPointer Update(){
		MAKEPROCESSSTATUS(resSta, true, className_, "");
		return resSta;
	}
	virtual ConstIDataPointer GetOutput(){ return m_Source; };
	virtual IDataPointer ReleaseData(){ return IDataPointer(new TreeCurve()); };

signals:
	void deepCaliber_Signal();
	void Image_Signal();
	void StartDeepTraverse_Signal();

protected slots:

private:
	DeepImageThread *imageWorker;
	//deepshapesthread *shapesWorker;
	NGParamPack paramPack,paramPackCp,paramPackCpShapes;
	NGNeuronBigReader mostdReader;
	Vec3d RangeMin, RangeMax, StartingPoint, BoxRange, TraverseStep;
	int index = 0,indexCp=0;
	Vec3d relRange;
	std::vector<int> TraverseFlagArray;
	//IDataPointer OrigImage;
	QMutex m_mutex;
	QReadWriteLock readwriteLock;
	bool forceThreadStop_ = false;
	std::deque<std::tuple<std::shared_ptr<SVolume>, Vec6i, int>> deepImageDeque;
	int ImageDequeNum = 4;
	std::vector<Line5d> curThreadCurves;
	size_t ShapesThreadFlag = 0;
	deepshapesthread *shapesWorker;
	std::vector<Line5d> curves;
	CellVec3d shapes;
	bool b_processSWC = 0;
	bool isstarted;
	bool isNeedEmptyData,isSaveCurves,isSaveShapes;
	bool IsImageDequeValid();
	void GetSwcBoundingBox();
	bool Next(Vec3d &curPoint, std::vector<Line5d> &curves);
	bool NextArray(int &idx);
	bool NextSub(Vec3d &curPoint, std::vector<Line5d> &curves);
	void MakeTraverseArray();
	void StartImageThread();
	void StartShapesThread();
	void ShapeRun();
	bool Save_();
	//void EndImageThread_Slot();
	void ProcessCoronalPlane(int StartX, int StartY, int StartZ);
};

