/********************************************************************************
** Form generated from reading UI file 'OpenImageDialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPENIMAGEDIALOG_H
#define UI_OPENIMAGEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OpenImageDialog
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_5;
    QLabel *FilePathDisplayLabel;
    QLineEdit *FilePathEdit;
    QPushButton *OpenButton;
    QGroupBox *FileInfoGroupBox;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *fileNameLabel;
    QLabel *getFileNameLable;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QLabel *imageSizeLabel;
    QLabel *getImageSizeLabel;
    QSpacerItem *horizontalSpacer_2;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *SomaPathDisplayLabel;
    QLineEdit *StackPathEdit;
    QPushButton *OpenStackButton;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *OKButton;
    QPushButton *CancelButton;
    QGroupBox *ResolutionRoupBox;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *ResolutionStyleLabel;
    QLabel *VoxelSizeLabel;
    QDoubleSpinBox *xResSpinBox;
    QDoubleSpinBox *yResSpinBox;
    QDoubleSpinBox *zResSpinBox;

    void setupUi(QDialog *OpenImageDialog)
    {
        if (OpenImageDialog->objectName().isEmpty())
            OpenImageDialog->setObjectName(QString::fromUtf8("OpenImageDialog"));
        OpenImageDialog->resize(424, 363);
        layoutWidget = new QWidget(OpenImageDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 10, 391, 30));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        FilePathDisplayLabel = new QLabel(layoutWidget);
        FilePathDisplayLabel->setObjectName(QString::fromUtf8("FilePathDisplayLabel"));

        horizontalLayout_5->addWidget(FilePathDisplayLabel);

        FilePathEdit = new QLineEdit(layoutWidget);
        FilePathEdit->setObjectName(QString::fromUtf8("FilePathEdit"));

        horizontalLayout_5->addWidget(FilePathEdit);

        OpenButton = new QPushButton(layoutWidget);
        OpenButton->setObjectName(QString::fromUtf8("OpenButton"));

        horizontalLayout_5->addWidget(OpenButton);

        FileInfoGroupBox = new QGroupBox(OpenImageDialog);
        FileInfoGroupBox->setObjectName(QString::fromUtf8("FileInfoGroupBox"));
        FileInfoGroupBox->setGeometry(QRect(20, 200, 391, 101));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial Black"));
        FileInfoGroupBox->setFont(font);
        gridLayout = new QGridLayout(FileInfoGroupBox);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        fileNameLabel = new QLabel(FileInfoGroupBox);
        fileNameLabel->setObjectName(QString::fromUtf8("fileNameLabel"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        fileNameLabel->setFont(font1);

        horizontalLayout_2->addWidget(fileNameLabel);

        getFileNameLable = new QLabel(FileInfoGroupBox);
        getFileNameLable->setObjectName(QString::fromUtf8("getFileNameLable"));
        getFileNameLable->setFont(font1);

        horizontalLayout_2->addWidget(getFileNameLable);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        imageSizeLabel = new QLabel(FileInfoGroupBox);
        imageSizeLabel->setObjectName(QString::fromUtf8("imageSizeLabel"));
        imageSizeLabel->setFont(font1);

        horizontalLayout_3->addWidget(imageSizeLabel);

        getImageSizeLabel = new QLabel(FileInfoGroupBox);
        getImageSizeLabel->setObjectName(QString::fromUtf8("getImageSizeLabel"));
        getImageSizeLabel->setFont(font1);

        horizontalLayout_3->addWidget(getImageSizeLabel);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        layoutWidget_2 = new QWidget(OpenImageDialog);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(20, 40, 391, 30));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        SomaPathDisplayLabel = new QLabel(layoutWidget_2);
        SomaPathDisplayLabel->setObjectName(QString::fromUtf8("SomaPathDisplayLabel"));

        horizontalLayout_6->addWidget(SomaPathDisplayLabel);

        StackPathEdit = new QLineEdit(layoutWidget_2);
        StackPathEdit->setObjectName(QString::fromUtf8("StackPathEdit"));

        horizontalLayout_6->addWidget(StackPathEdit);

        OpenStackButton = new QPushButton(layoutWidget_2);
        OpenStackButton->setObjectName(QString::fromUtf8("OpenStackButton"));

        horizontalLayout_6->addWidget(OpenStackButton);

        horizontalLayoutWidget = new QWidget(OpenImageDialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(210, 310, 195, 30));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        OKButton = new QPushButton(horizontalLayoutWidget);
        OKButton->setObjectName(QString::fromUtf8("OKButton"));

        horizontalLayout->addWidget(OKButton);

        CancelButton = new QPushButton(horizontalLayoutWidget);
        CancelButton->setObjectName(QString::fromUtf8("CancelButton"));

        horizontalLayout->addWidget(CancelButton);

        ResolutionRoupBox = new QGroupBox(OpenImageDialog);
        ResolutionRoupBox->setObjectName(QString::fromUtf8("ResolutionRoupBox"));
        ResolutionRoupBox->setGeometry(QRect(20, 90, 391, 101));
        ResolutionRoupBox->setFont(font);
        layoutWidget1 = new QWidget(ResolutionRoupBox);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(13, 61, 371, 61));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        ResolutionStyleLabel = new QLabel(layoutWidget1);
        ResolutionStyleLabel->setObjectName(QString::fromUtf8("ResolutionStyleLabel"));
        ResolutionStyleLabel->setFont(font1);

        verticalLayout_2->addWidget(ResolutionStyleLabel);

        VoxelSizeLabel = new QLabel(layoutWidget1);
        VoxelSizeLabel->setObjectName(QString::fromUtf8("VoxelSizeLabel"));
        VoxelSizeLabel->setSizeIncrement(QSize(3, 0));
        VoxelSizeLabel->setFont(font1);

        verticalLayout_2->addWidget(VoxelSizeLabel);

        xResSpinBox = new QDoubleSpinBox(ResolutionRoupBox);
        xResSpinBox->setObjectName(QString::fromUtf8("xResSpinBox"));
        xResSpinBox->setGeometry(QRect(30, 30, 70, 22));
        xResSpinBox->setValue(1.000000000000000);
        yResSpinBox = new QDoubleSpinBox(ResolutionRoupBox);
        yResSpinBox->setObjectName(QString::fromUtf8("yResSpinBox"));
        yResSpinBox->setGeometry(QRect(120, 30, 70, 22));
        yResSpinBox->setValue(1.000000000000000);
        zResSpinBox = new QDoubleSpinBox(ResolutionRoupBox);
        zResSpinBox->setObjectName(QString::fromUtf8("zResSpinBox"));
        zResSpinBox->setGeometry(QRect(210, 30, 70, 22));
        zResSpinBox->setValue(1.000000000000000);

        retranslateUi(OpenImageDialog);
        QObject::connect(OKButton, SIGNAL(clicked()), OpenImageDialog, SLOT(accept()));
        QObject::connect(CancelButton, SIGNAL(clicked()), OpenImageDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(OpenImageDialog);
    } // setupUi

    void retranslateUi(QDialog *OpenImageDialog)
    {
        OpenImageDialog->setWindowTitle(QApplication::translate("OpenImageDialog", "OpenImageDialog", nullptr));
        FilePathDisplayLabel->setText(QApplication::translate("OpenImageDialog", "Image Path:", nullptr));
        OpenButton->setText(QApplication::translate("OpenImageDialog", "Open", nullptr));
        FileInfoGroupBox->setTitle(QApplication::translate("OpenImageDialog", "FileInfo", nullptr));
        fileNameLabel->setText(QApplication::translate("OpenImageDialog", "File Name:", nullptr));
        getFileNameLable->setText(QApplication::translate("OpenImageDialog", "unknown File", nullptr));
        imageSizeLabel->setText(QApplication::translate("OpenImageDialog", "Image Size:", nullptr));
        getImageSizeLabel->setText(QApplication::translate("OpenImageDialog", "0 Slices, 0 * 0 , 0 bpp", nullptr));
        SomaPathDisplayLabel->setText(QApplication::translate("OpenImageDialog", "Swc Path:", nullptr));
        OpenStackButton->setText(QApplication::translate("OpenImageDialog", "Open", nullptr));
        OKButton->setText(QApplication::translate("OpenImageDialog", "OK", nullptr));
        CancelButton->setText(QApplication::translate("OpenImageDialog", "Cancel", nullptr));
        ResolutionRoupBox->setTitle(QApplication::translate("OpenImageDialog", "Resolution", nullptr));
        ResolutionStyleLabel->setText(QApplication::translate("OpenImageDialog", "Define : Voxel size (um)", nullptr));
        VoxelSizeLabel->setText(QApplication::translate("OpenImageDialog", "Voxel Size:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OpenImageDialog: public Ui_OpenImageDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPENIMAGEDIALOG_H
