/********************************************************************************
** Form generated from reading UI file 'BinarySettingsDockWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BINARYSETTINGSDOCKWIDGET_H
#define UI_BINARYSETTINGSDOCKWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BinarySettingsDockWidget
{
public:
    QWidget *widget;
    QGridLayout *gridLayout_10;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QGridLayout *gridLayout_14;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_24;
    QWidget *widget_11;
    QGridLayout *gridLayout_13;
    QPushButton *pushButton_6;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_11;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButton_9;
    QSpacerItem *horizontalSpacer_9;
    QSpacerItem *verticalSpacer_3;
    QWidget *widget_8;
    QGridLayout *gridLayout_9;
    QPushButton *pushButton_4;
    QWidget *widget_7;
    QGridLayout *gridLayout_6;
    QLabel *label_34;
    QDoubleSpinBox *resXSpinBox;
    QDoubleSpinBox *resZSpinBox;
    QSpinBox *lowOpacSpinBox;
    QLabel *label_35;
    QDoubleSpinBox *resYSpinBox;
    QLabel *label_33;
    QSpinBox *thicknessspinBox;
    QLabel *lowMapLabel;
    QLabel *highMapLabel;
    QLabel *label_5;
    QSpinBox *highOpacSpinBox;
    QPushButton *applyResButton;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton;
    QWidget *widget_3;
    QGridLayout *gridLayout;
    QLabel *imageRangeLabel;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *xMinLabel;
    QLabel *xMaxLabel;
    QLabel *yMinLabel;
    QLabel *yMaxLabel;
    QLabel *zMinLabel;
    QLabel *zMaxLabel;
    QVBoxLayout *verticalLayout_2;
    QSpinBox *xMinspinBox;
    QSpinBox *xMaxspinBox;
    QSpinBox *yMinspinBox;
    QSpinBox *yMaxspinBox;
    QSpinBox *zMinspinBox;
    QSpinBox *zMaxspinBox;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_3;
    QSpinBox *levelSpinBox;
    QPushButton *applyImageReadButton;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *action_ClearCache_Button;
    QWidget *widget_4;
    QGridLayout *gridLayout_16;
    QLabel *label_8;
    QSpinBox *origLowOpacSpinBox;
    QSpinBox *origHighOpacSpinBox;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_10;
    QSpinBox *destLowOpacSpinBox;
    QSpinBox *destHighOpacSpinBox;
    QPushButton *previewIlluminationMapButton;
    QPushButton *imageOpacInfoButton;
    QPushButton *opacApplyButton;
    QCheckBox *autoOpacSetCheckBox;
    QWidget *widget_12;
    QGridLayout *gridLayout_12;
    QSpinBox *zBlockSizespinBox;
    QLabel *highMapLabel_2;
    QLabel *lowMapLabel_2;
    QSpinBox *xBlockSizespinBox;
    QLabel *highMapLabel_3;
    QSpinBox *yBlockSizespinBox;
    QWidget *widget_5;
    QGridLayout *gridLayout_15;
    QWidget *widget_19;
    QGridLayout *gridLayout_25;
    QLabel *label;
    QSpinBox *xScaleSpinBox;
    QLabel *label_6;
    QSpinBox *yScaleSpinBox;
    QLabel *label_7;
    QSpinBox *zScaleSpinBox;
    QCheckBox *AveragecheckBox;
    QWidget *tab_2;
    QGridLayout *gridLayout_21;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_5;
    QWidget *widget_9;
    QGridLayout *gridLayout_17;
    QPushButton *pushButton_7;
    QWidget *widget_14;
    QGridLayout *gridLayout_18;
    QDoubleSpinBox *thresholdSpinBox;
    QLabel *ThresholdLabel_4;
    QPushButton *previewBinaryButton;
    QWidget *widget_15;
    QGridLayout *gridLayout_19;
    QPushButton *pushButton_8;
    QWidget *widget_16;
    QGridLayout *gridLayout_20;
    QCheckBox *GPSSVMcheckBox;
    QLabel *diffuseValueLabel_4;
    QDoubleSpinBox *traceValueSpinBox;
    QDoubleSpinBox *diffuseValueSpinBox;
    QLabel *label_9;
    QCheckBox *BigSomacheckBox;
    QWidget *tab_3;
    QGridLayout *gridLayout_5;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_6;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_7;
    QWidget *widget_10;
    QGridLayout *gridLayout_7;
    QDoubleSpinBox *axonTraceValueSpinBox;
    QLabel *diffuseValueLabel_2;
    QLabel *label_13;
    QLabel *label_4;
    QDoubleSpinBox *axonSemiautoTraceTresholdSpinBox;
    QSpinBox *maxBoundNumSpinBox;
    QDoubleSpinBox *axonDiffuseValueSpinBox;
    QCheckBox *strongSignalCheckBox;
    QCheckBox *enableSVMBox;
    QDoubleSpinBox *axonSemiautoConnectResampleSpinBox;
    QLabel *label_14;
    QLabel *label_2;
    QPushButton *pushButton_3;
    QWidget *widget_13;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_5;
    QSpacerItem *horizontalSpacer_8;
    QWidget *widget_17;
    QGridLayout *gridLayout_8;
    QLabel *lowMapLabel_3;
    QSlider *SmoothSlider;
    QWidget *widget_18;
    QGridLayout *gridLayout_22;
    QPushButton *pushButton_10;
    QWidget *widget_20;
    QGridLayout *gridLayout_23;
    QDoubleSpinBox *axonThresholdSpinBox;
    QLabel *ThresholdLabel_5;
    QPushButton *previewAxonBinaryButton;
    QWidget *widget_21;
    QGridLayout *gridLayout_26;
    QPushButton *pushButton_12;
    QSpacerItem *horizontalSpacer_11;
    QCheckBox *CrudeShapecheckBox;
    QWidget *tab_4;
    QGridLayout *gridLayout_11;

    void setupUi(QDockWidget *BinarySettingsDockWidget)
    {
        if (BinarySettingsDockWidget->objectName().isEmpty())
            BinarySettingsDockWidget->setObjectName(QString::fromUtf8("BinarySettingsDockWidget"));
        BinarySettingsDockWidget->resize(362, 893);
        BinarySettingsDockWidget->setMinimumSize(QSize(300, 600));
        BinarySettingsDockWidget->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        widget = new QWidget();
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_10 = new QGridLayout(widget);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        gridLayout_10->setContentsMargins(1, 1, 3, 3);
        scrollArea = new QScrollArea(widget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy);
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 346, 1176));
        gridLayout_14 = new QGridLayout(scrollAreaWidgetContents_2);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        gridLayout_14->setContentsMargins(3, 3, 3, 3);
        tabWidget = new QTabWidget(scrollAreaWidgetContents_2);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setFocusPolicy(Qt::TabFocus);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_24 = new QGridLayout(tab);
        gridLayout_24->setSpacing(6);
        gridLayout_24->setContentsMargins(11, 11, 11, 11);
        gridLayout_24->setObjectName(QString::fromUtf8("gridLayout_24"));
        widget_11 = new QWidget(tab);
        widget_11->setObjectName(QString::fromUtf8("widget_11"));
        gridLayout_13 = new QGridLayout(widget_11);
        gridLayout_13->setSpacing(1);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        gridLayout_13->setContentsMargins(1, -1, 1, 1);
        pushButton_6 = new QPushButton(widget_11);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/tracer/Resource/plus.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/new/tracer/Resource/minus.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_6->setIcon(icon);
        pushButton_6->setCheckable(true);
        pushButton_6->setChecked(true);
        pushButton_6->setFlat(true);

        gridLayout_13->addWidget(pushButton_6, 0, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_13->addItem(horizontalSpacer_3, 0, 1, 1, 1);


        gridLayout_24->addWidget(widget_11, 2, 0, 1, 2);

        horizontalSpacer_6 = new QSpacerItem(130, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_6, 0, 2, 1, 1);

        pushButton_11 = new QPushButton(tab);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setIcon(icon);
        pushButton_11->setCheckable(true);
        pushButton_11->setChecked(true);
        pushButton_11->setFlat(true);

        gridLayout_24->addWidget(pushButton_11, 9, 0, 1, 1);

        horizontalSpacer_10 = new QSpacerItem(75, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_10, 9, 1, 1, 1);

        pushButton_9 = new QPushButton(tab);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setIcon(icon);
        pushButton_9->setCheckable(true);
        pushButton_9->setChecked(true);
        pushButton_9->setFlat(true);

        gridLayout_24->addWidget(pushButton_9, 4, 0, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(89, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_9, 4, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 233, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_24->addItem(verticalSpacer_3, 11, 0, 1, 2);

        widget_8 = new QWidget(tab);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        gridLayout_9 = new QGridLayout(widget_8);
        gridLayout_9->setSpacing(1);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(1, 1, 1, 1);
        pushButton_4 = new QPushButton(widget_8);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setIcon(icon);
        pushButton_4->setCheckable(true);
        pushButton_4->setChecked(true);
        pushButton_4->setFlat(true);

        gridLayout_9->addWidget(pushButton_4, 0, 0, 1, 1, Qt::AlignLeft);

        widget_7 = new QWidget(widget_8);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        gridLayout_6 = new QGridLayout(widget_7);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        label_34 = new QLabel(widget_7);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_34, 5, 0, 1, 1);

        resXSpinBox = new QDoubleSpinBox(widget_7);
        resXSpinBox->setObjectName(QString::fromUtf8("resXSpinBox"));

        gridLayout_6->addWidget(resXSpinBox, 4, 1, 1, 1);

        resZSpinBox = new QDoubleSpinBox(widget_7);
        resZSpinBox->setObjectName(QString::fromUtf8("resZSpinBox"));

        gridLayout_6->addWidget(resZSpinBox, 6, 1, 1, 1);

        lowOpacSpinBox = new QSpinBox(widget_7);
        lowOpacSpinBox->setObjectName(QString::fromUtf8("lowOpacSpinBox"));
        sizePolicy.setHeightForWidth(lowOpacSpinBox->sizePolicy().hasHeightForWidth());
        lowOpacSpinBox->setSizePolicy(sizePolicy);
        lowOpacSpinBox->setMinimumSize(QSize(0, 0));
        lowOpacSpinBox->setMaximum(9999);

        gridLayout_6->addWidget(lowOpacSpinBox, 0, 1, 2, 1);

        label_35 = new QLabel(widget_7);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_35, 6, 0, 1, 1);

        resYSpinBox = new QDoubleSpinBox(widget_7);
        resYSpinBox->setObjectName(QString::fromUtf8("resYSpinBox"));

        gridLayout_6->addWidget(resYSpinBox, 5, 1, 1, 1);

        label_33 = new QLabel(widget_7);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_33, 4, 0, 1, 1);

        thicknessspinBox = new QSpinBox(widget_7);
        thicknessspinBox->setObjectName(QString::fromUtf8("thicknessspinBox"));
        sizePolicy.setHeightForWidth(thicknessspinBox->sizePolicy().hasHeightForWidth());
        thicknessspinBox->setSizePolicy(sizePolicy);
        thicknessspinBox->setMinimum(1);
        thicknessspinBox->setMaximum(1000);
        thicknessspinBox->setValue(10);

        gridLayout_6->addWidget(thicknessspinBox, 3, 1, 1, 1);

        lowMapLabel = new QLabel(widget_7);
        lowMapLabel->setObjectName(QString::fromUtf8("lowMapLabel"));

        gridLayout_6->addWidget(lowMapLabel, 0, 0, 1, 1, Qt::AlignRight);

        highMapLabel = new QLabel(widget_7);
        highMapLabel->setObjectName(QString::fromUtf8("highMapLabel"));

        gridLayout_6->addWidget(highMapLabel, 1, 0, 2, 1, Qt::AlignRight);

        label_5 = new QLabel(widget_7);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        QFont font;
        font.setPointSize(10);
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_5, 3, 0, 1, 1);

        highOpacSpinBox = new QSpinBox(widget_7);
        highOpacSpinBox->setObjectName(QString::fromUtf8("highOpacSpinBox"));
        sizePolicy.setHeightForWidth(highOpacSpinBox->sizePolicy().hasHeightForWidth());
        highOpacSpinBox->setSizePolicy(sizePolicy);
        highOpacSpinBox->setMinimumSize(QSize(0, 0));
        highOpacSpinBox->setMaximum(65535);
        highOpacSpinBox->setValue(255);

        gridLayout_6->addWidget(highOpacSpinBox, 2, 1, 1, 1);

        applyResButton = new QPushButton(widget_7);
        applyResButton->setObjectName(QString::fromUtf8("applyResButton"));

        gridLayout_6->addWidget(applyResButton, 7, 1, 1, 1);


        gridLayout_9->addWidget(widget_7, 1, 0, 1, 1);


        gridLayout_24->addWidget(widget_8, 1, 0, 1, 2);

        widget_2 = new QWidget(tab);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setSpacing(1);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(1, 1, 1, 1);
        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setIcon(icon);
        pushButton->setCheckable(true);
        pushButton->setChecked(true);
        pushButton->setFlat(true);

        gridLayout_2->addWidget(pushButton, 0, 0, 1, 1, Qt::AlignLeft);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        gridLayout = new QGridLayout(widget_3);
        gridLayout->setSpacing(1);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(1, 1, 1, 1);
        imageRangeLabel = new QLabel(widget_3);
        imageRangeLabel->setObjectName(QString::fromUtf8("imageRangeLabel"));
        imageRangeLabel->setMinimumSize(QSize(0, 10));

        gridLayout->addWidget(imageRangeLabel, 0, 0, 1, 1, Qt::AlignLeft);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        xMinLabel = new QLabel(widget_3);
        xMinLabel->setObjectName(QString::fromUtf8("xMinLabel"));
        sizePolicy.setHeightForWidth(xMinLabel->sizePolicy().hasHeightForWidth());
        xMinLabel->setSizePolicy(sizePolicy);
        xMinLabel->setMinimumSize(QSize(0, 0));
        xMinLabel->setMaximumSize(QSize(16777215, 16777215));
        xMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(xMinLabel, 0, Qt::AlignLeft);

        xMaxLabel = new QLabel(widget_3);
        xMaxLabel->setObjectName(QString::fromUtf8("xMaxLabel"));
        sizePolicy.setHeightForWidth(xMaxLabel->sizePolicy().hasHeightForWidth());
        xMaxLabel->setSizePolicy(sizePolicy);
        xMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(xMaxLabel, 0, Qt::AlignLeft);

        yMinLabel = new QLabel(widget_3);
        yMinLabel->setObjectName(QString::fromUtf8("yMinLabel"));
        sizePolicy.setHeightForWidth(yMinLabel->sizePolicy().hasHeightForWidth());
        yMinLabel->setSizePolicy(sizePolicy);
        yMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(yMinLabel, 0, Qt::AlignLeft);

        yMaxLabel = new QLabel(widget_3);
        yMaxLabel->setObjectName(QString::fromUtf8("yMaxLabel"));
        sizePolicy.setHeightForWidth(yMaxLabel->sizePolicy().hasHeightForWidth());
        yMaxLabel->setSizePolicy(sizePolicy);
        yMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(yMaxLabel, 0, Qt::AlignLeft);

        zMinLabel = new QLabel(widget_3);
        zMinLabel->setObjectName(QString::fromUtf8("zMinLabel"));
        sizePolicy.setHeightForWidth(zMinLabel->sizePolicy().hasHeightForWidth());
        zMinLabel->setSizePolicy(sizePolicy);
        zMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(zMinLabel, 0, Qt::AlignLeft);

        zMaxLabel = new QLabel(widget_3);
        zMaxLabel->setObjectName(QString::fromUtf8("zMaxLabel"));
        sizePolicy.setHeightForWidth(zMaxLabel->sizePolicy().hasHeightForWidth());
        zMaxLabel->setSizePolicy(sizePolicy);
        zMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(zMaxLabel, 0, Qt::AlignLeft);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        xMinspinBox = new QSpinBox(widget_3);
        xMinspinBox->setObjectName(QString::fromUtf8("xMinspinBox"));
        sizePolicy.setHeightForWidth(xMinspinBox->sizePolicy().hasHeightForWidth());
        xMinspinBox->setSizePolicy(sizePolicy);
        xMinspinBox->setMinimumSize(QSize(0, 0));
        xMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(xMinspinBox);

        xMaxspinBox = new QSpinBox(widget_3);
        xMaxspinBox->setObjectName(QString::fromUtf8("xMaxspinBox"));
        sizePolicy.setHeightForWidth(xMaxspinBox->sizePolicy().hasHeightForWidth());
        xMaxspinBox->setSizePolicy(sizePolicy);
        xMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(xMaxspinBox);

        yMinspinBox = new QSpinBox(widget_3);
        yMinspinBox->setObjectName(QString::fromUtf8("yMinspinBox"));
        sizePolicy.setHeightForWidth(yMinspinBox->sizePolicy().hasHeightForWidth());
        yMinspinBox->setSizePolicy(sizePolicy);
        yMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(yMinspinBox);

        yMaxspinBox = new QSpinBox(widget_3);
        yMaxspinBox->setObjectName(QString::fromUtf8("yMaxspinBox"));
        sizePolicy.setHeightForWidth(yMaxspinBox->sizePolicy().hasHeightForWidth());
        yMaxspinBox->setSizePolicy(sizePolicy);
        yMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(yMaxspinBox);

        zMinspinBox = new QSpinBox(widget_3);
        zMinspinBox->setObjectName(QString::fromUtf8("zMinspinBox"));
        sizePolicy.setHeightForWidth(zMinspinBox->sizePolicy().hasHeightForWidth());
        zMinspinBox->setSizePolicy(sizePolicy);
        zMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(zMinspinBox);

        zMaxspinBox = new QSpinBox(widget_3);
        zMaxspinBox->setObjectName(QString::fromUtf8("zMaxspinBox"));
        sizePolicy.setHeightForWidth(zMaxspinBox->sizePolicy().hasHeightForWidth());
        zMaxspinBox->setSizePolicy(sizePolicy);
        zMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(zMaxspinBox);


        horizontalLayout->addLayout(verticalLayout_2);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        levelSpinBox = new QSpinBox(widget_3);
        levelSpinBox->setObjectName(QString::fromUtf8("levelSpinBox"));
        levelSpinBox->setMinimum(1);
        levelSpinBox->setMaximum(8);

        horizontalLayout_2->addWidget(levelSpinBox);

        applyImageReadButton = new QPushButton(widget_3);
        applyImageReadButton->setObjectName(QString::fromUtf8("applyImageReadButton"));

        horizontalLayout_2->addWidget(applyImageReadButton);


        gridLayout->addLayout(horizontalLayout_2, 2, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        action_ClearCache_Button = new QPushButton(widget_3);
        action_ClearCache_Button->setObjectName(QString::fromUtf8("action_ClearCache_Button"));

        horizontalLayout_3->addWidget(action_ClearCache_Button);


        gridLayout->addLayout(horizontalLayout_3, 3, 0, 1, 1);


        gridLayout_2->addWidget(widget_3, 1, 0, 1, 1);


        gridLayout_24->addWidget(widget_2, 0, 0, 1, 2);

        widget_4 = new QWidget(tab);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        gridLayout_16 = new QGridLayout(widget_4);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        label_8 = new QLabel(widget_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_16->addWidget(label_8, 0, 0, 1, 1);

        origLowOpacSpinBox = new QSpinBox(widget_4);
        origLowOpacSpinBox->setObjectName(QString::fromUtf8("origLowOpacSpinBox"));
        origLowOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(origLowOpacSpinBox, 0, 1, 1, 1);

        origHighOpacSpinBox = new QSpinBox(widget_4);
        origHighOpacSpinBox->setObjectName(QString::fromUtf8("origHighOpacSpinBox"));
        origHighOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(origHighOpacSpinBox, 0, 2, 1, 1);

        label_11 = new QLabel(widget_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_16->addWidget(label_11, 1, 1, 1, 1);

        label_12 = new QLabel(widget_4);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_16->addWidget(label_12, 1, 2, 1, 1);

        label_10 = new QLabel(widget_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_16->addWidget(label_10, 2, 0, 1, 1);

        destLowOpacSpinBox = new QSpinBox(widget_4);
        destLowOpacSpinBox->setObjectName(QString::fromUtf8("destLowOpacSpinBox"));
        destLowOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(destLowOpacSpinBox, 2, 1, 1, 1);

        destHighOpacSpinBox = new QSpinBox(widget_4);
        destHighOpacSpinBox->setObjectName(QString::fromUtf8("destHighOpacSpinBox"));
        destHighOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(destHighOpacSpinBox, 2, 2, 1, 1);

        previewIlluminationMapButton = new QPushButton(widget_4);
        previewIlluminationMapButton->setObjectName(QString::fromUtf8("previewIlluminationMapButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(previewIlluminationMapButton->sizePolicy().hasHeightForWidth());
        previewIlluminationMapButton->setSizePolicy(sizePolicy2);
        previewIlluminationMapButton->setMinimumSize(QSize(65, 0));
        previewIlluminationMapButton->setMaximumSize(QSize(49, 16777215));
        previewIlluminationMapButton->setCheckable(true);

        gridLayout_16->addWidget(previewIlluminationMapButton, 3, 0, 1, 1);

        imageOpacInfoButton = new QPushButton(widget_4);
        imageOpacInfoButton->setObjectName(QString::fromUtf8("imageOpacInfoButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(imageOpacInfoButton->sizePolicy().hasHeightForWidth());
        imageOpacInfoButton->setSizePolicy(sizePolicy3);
        imageOpacInfoButton->setMaximumSize(QSize(47, 16777215));

        gridLayout_16->addWidget(imageOpacInfoButton, 3, 1, 1, 1);

        opacApplyButton = new QPushButton(widget_4);
        opacApplyButton->setObjectName(QString::fromUtf8("opacApplyButton"));
        opacApplyButton->setMaximumSize(QSize(47, 16777215));

        gridLayout_16->addWidget(opacApplyButton, 3, 2, 1, 1);

        autoOpacSetCheckBox = new QCheckBox(widget_4);
        autoOpacSetCheckBox->setObjectName(QString::fromUtf8("autoOpacSetCheckBox"));

        gridLayout_16->addWidget(autoOpacSetCheckBox, 4, 2, 1, 1);


        gridLayout_24->addWidget(widget_4, 10, 0, 1, 2);

        widget_12 = new QWidget(tab);
        widget_12->setObjectName(QString::fromUtf8("widget_12"));
        gridLayout_12 = new QGridLayout(widget_12);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        zBlockSizespinBox = new QSpinBox(widget_12);
        zBlockSizespinBox->setObjectName(QString::fromUtf8("zBlockSizespinBox"));
        sizePolicy.setHeightForWidth(zBlockSizespinBox->sizePolicy().hasHeightForWidth());
        zBlockSizespinBox->setSizePolicy(sizePolicy);
        zBlockSizespinBox->setMinimumSize(QSize(0, 0));
        zBlockSizespinBox->setMinimum(10);
        zBlockSizespinBox->setMaximum(9999);
        zBlockSizespinBox->setValue(54);

        gridLayout_12->addWidget(zBlockSizespinBox, 2, 1, 1, 1);

        highMapLabel_2 = new QLabel(widget_12);
        highMapLabel_2->setObjectName(QString::fromUtf8("highMapLabel_2"));

        gridLayout_12->addWidget(highMapLabel_2, 1, 0, 1, 1, Qt::AlignRight);

        lowMapLabel_2 = new QLabel(widget_12);
        lowMapLabel_2->setObjectName(QString::fromUtf8("lowMapLabel_2"));

        gridLayout_12->addWidget(lowMapLabel_2, 0, 0, 1, 1, Qt::AlignRight);

        xBlockSizespinBox = new QSpinBox(widget_12);
        xBlockSizespinBox->setObjectName(QString::fromUtf8("xBlockSizespinBox"));
        sizePolicy.setHeightForWidth(xBlockSizespinBox->sizePolicy().hasHeightForWidth());
        xBlockSizespinBox->setSizePolicy(sizePolicy);
        xBlockSizespinBox->setMinimumSize(QSize(0, 0));
        xBlockSizespinBox->setMinimum(10);
        xBlockSizespinBox->setMaximum(9999);
        xBlockSizespinBox->setValue(60);

        gridLayout_12->addWidget(xBlockSizespinBox, 0, 1, 1, 1);

        highMapLabel_3 = new QLabel(widget_12);
        highMapLabel_3->setObjectName(QString::fromUtf8("highMapLabel_3"));

        gridLayout_12->addWidget(highMapLabel_3, 2, 0, 1, 1, Qt::AlignRight);

        yBlockSizespinBox = new QSpinBox(widget_12);
        yBlockSizespinBox->setObjectName(QString::fromUtf8("yBlockSizespinBox"));
        sizePolicy.setHeightForWidth(yBlockSizespinBox->sizePolicy().hasHeightForWidth());
        yBlockSizespinBox->setSizePolicy(sizePolicy);
        yBlockSizespinBox->setMinimumSize(QSize(0, 0));
        yBlockSizespinBox->setMinimum(10);
        yBlockSizespinBox->setMaximum(9999);
        yBlockSizespinBox->setValue(60);

        gridLayout_12->addWidget(yBlockSizespinBox, 1, 1, 1, 1);


        gridLayout_24->addWidget(widget_12, 3, 0, 1, 2);

        widget_5 = new QWidget(tab);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        gridLayout_15 = new QGridLayout(widget_5);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        widget_19 = new QWidget(widget_5);
        widget_19->setObjectName(QString::fromUtf8("widget_19"));
        gridLayout_25 = new QGridLayout(widget_19);
        gridLayout_25->setSpacing(6);
        gridLayout_25->setContentsMargins(11, 11, 11, 11);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        label = new QLabel(widget_19);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label, 0, 0, 1, 1);

        xScaleSpinBox = new QSpinBox(widget_19);
        xScaleSpinBox->setObjectName(QString::fromUtf8("xScaleSpinBox"));
        xScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(xScaleSpinBox, 0, 1, 1, 1);

        label_6 = new QLabel(widget_19);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label_6, 1, 0, 1, 1);

        yScaleSpinBox = new QSpinBox(widget_19);
        yScaleSpinBox->setObjectName(QString::fromUtf8("yScaleSpinBox"));
        yScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(yScaleSpinBox, 1, 1, 1, 1);

        label_7 = new QLabel(widget_19);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label_7, 2, 0, 1, 1);

        zScaleSpinBox = new QSpinBox(widget_19);
        zScaleSpinBox->setObjectName(QString::fromUtf8("zScaleSpinBox"));
        zScaleSpinBox->setEnabled(false);
        zScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(zScaleSpinBox, 2, 1, 1, 1);

        label->raise();
        xScaleSpinBox->raise();
        label_6->raise();
        label_7->raise();
        yScaleSpinBox->raise();
        zScaleSpinBox->raise();

        gridLayout_15->addWidget(widget_19, 2, 1, 1, 1);

        AveragecheckBox = new QCheckBox(widget_5);
        AveragecheckBox->setObjectName(QString::fromUtf8("AveragecheckBox"));
        AveragecheckBox->setChecked(true);

        gridLayout_15->addWidget(AveragecheckBox, 1, 1, 1, 1);


        gridLayout_24->addWidget(widget_5, 7, 0, 2, 2);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        gridLayout_21 = new QGridLayout(tab_2);
        gridLayout_21->setSpacing(6);
        gridLayout_21->setContentsMargins(11, 11, 11, 11);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        verticalSpacer = new QSpacerItem(20, 593, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_21->addItem(verticalSpacer, 2, 0, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(186, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_5, 1, 1, 1, 1);

        widget_9 = new QWidget(tab_2);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        gridLayout_17 = new QGridLayout(widget_9);
        gridLayout_17->setSpacing(1);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        gridLayout_17->setContentsMargins(1, 1, 1, 1);
        pushButton_7 = new QPushButton(widget_9);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setIcon(icon);
        pushButton_7->setCheckable(true);
        pushButton_7->setChecked(true);
        pushButton_7->setFlat(true);

        gridLayout_17->addWidget(pushButton_7, 0, 0, 1, 1, Qt::AlignLeft);

        widget_14 = new QWidget(widget_9);
        widget_14->setObjectName(QString::fromUtf8("widget_14"));
        gridLayout_18 = new QGridLayout(widget_14);
        gridLayout_18->setSpacing(1);
        gridLayout_18->setContentsMargins(11, 11, 11, 11);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        gridLayout_18->setContentsMargins(1, 1, 1, 1);
        thresholdSpinBox = new QDoubleSpinBox(widget_14);
        thresholdSpinBox->setObjectName(QString::fromUtf8("thresholdSpinBox"));
        sizePolicy.setHeightForWidth(thresholdSpinBox->sizePolicy().hasHeightForWidth());
        thresholdSpinBox->setSizePolicy(sizePolicy);
        thresholdSpinBox->setMaximum(9999.000000000000000);
        thresholdSpinBox->setValue(20.000000000000000);

        gridLayout_18->addWidget(thresholdSpinBox, 0, 1, 1, 1);

        ThresholdLabel_4 = new QLabel(widget_14);
        ThresholdLabel_4->setObjectName(QString::fromUtf8("ThresholdLabel_4"));
        sizePolicy.setHeightForWidth(ThresholdLabel_4->sizePolicy().hasHeightForWidth());
        ThresholdLabel_4->setSizePolicy(sizePolicy);
        ThresholdLabel_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_18->addWidget(ThresholdLabel_4, 0, 0, 1, 1, Qt::AlignLeft);

        previewBinaryButton = new QPushButton(widget_14);
        previewBinaryButton->setObjectName(QString::fromUtf8("previewBinaryButton"));
        previewBinaryButton->setCheckable(true);

        gridLayout_18->addWidget(previewBinaryButton, 1, 0, 1, 1);


        gridLayout_17->addWidget(widget_14, 1, 0, 1, 1);


        gridLayout_21->addWidget(widget_9, 0, 0, 1, 1);

        widget_15 = new QWidget(tab_2);
        widget_15->setObjectName(QString::fromUtf8("widget_15"));
        gridLayout_19 = new QGridLayout(widget_15);
        gridLayout_19->setSpacing(6);
        gridLayout_19->setContentsMargins(11, 11, 11, 11);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        pushButton_8 = new QPushButton(widget_15);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setIcon(icon);
        pushButton_8->setCheckable(true);
        pushButton_8->setChecked(true);
        pushButton_8->setFlat(true);

        gridLayout_19->addWidget(pushButton_8, 0, 0, 1, 1);

        widget_16 = new QWidget(widget_15);
        widget_16->setObjectName(QString::fromUtf8("widget_16"));
        gridLayout_20 = new QGridLayout(widget_16);
        gridLayout_20->setSpacing(1);
        gridLayout_20->setContentsMargins(11, 11, 11, 11);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        gridLayout_20->setContentsMargins(1, 1, 1, 1);
        GPSSVMcheckBox = new QCheckBox(widget_16);
        GPSSVMcheckBox->setObjectName(QString::fromUtf8("GPSSVMcheckBox"));

        gridLayout_20->addWidget(GPSSVMcheckBox, 4, 1, 1, 1);

        diffuseValueLabel_4 = new QLabel(widget_16);
        diffuseValueLabel_4->setObjectName(QString::fromUtf8("diffuseValueLabel_4"));
        QFont font1;
        font1.setPointSize(9);
        diffuseValueLabel_4->setFont(font1);
        diffuseValueLabel_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_20->addWidget(diffuseValueLabel_4, 1, 0, 1, 1);

        traceValueSpinBox = new QDoubleSpinBox(widget_16);
        traceValueSpinBox->setObjectName(QString::fromUtf8("traceValueSpinBox"));
        sizePolicy.setHeightForWidth(traceValueSpinBox->sizePolicy().hasHeightForWidth());
        traceValueSpinBox->setSizePolicy(sizePolicy);
        QFont font2;
        font2.setFamily(QString::fromUtf8("Arial"));
        font2.setPointSize(9);
        traceValueSpinBox->setFont(font2);
        traceValueSpinBox->setMaximum(9999999.000000000000000);
        traceValueSpinBox->setValue(1.000000000000000);

        gridLayout_20->addWidget(traceValueSpinBox, 3, 1, 1, 1);

        diffuseValueSpinBox = new QDoubleSpinBox(widget_16);
        diffuseValueSpinBox->setObjectName(QString::fromUtf8("diffuseValueSpinBox"));
        sizePolicy.setHeightForWidth(diffuseValueSpinBox->sizePolicy().hasHeightForWidth());
        diffuseValueSpinBox->setSizePolicy(sizePolicy);
        diffuseValueSpinBox->setMaximum(99999.000000000000000);
        diffuseValueSpinBox->setValue(4096.000000000000000);

        gridLayout_20->addWidget(diffuseValueSpinBox, 1, 1, 1, 1);

        label_9 = new QLabel(widget_16);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_20->addWidget(label_9, 3, 0, 1, 1);

        BigSomacheckBox = new QCheckBox(widget_16);
        BigSomacheckBox->setObjectName(QString::fromUtf8("BigSomacheckBox"));

        gridLayout_20->addWidget(BigSomacheckBox, 5, 1, 1, 1);


        gridLayout_19->addWidget(widget_16, 1, 0, 1, 2);


        gridLayout_21->addWidget(widget_15, 1, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        gridLayout_5 = new QGridLayout(tab_3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer, 0, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_2, 4, 0, 1, 1);

        widget_6 = new QWidget(tab_3);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        gridLayout_3 = new QGridLayout(widget_6);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(1, 1, 1, 1);
        horizontalSpacer_7 = new QSpacerItem(93, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_7, 0, 1, 1, 1);

        widget_10 = new QWidget(widget_6);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        gridLayout_7 = new QGridLayout(widget_10);
        gridLayout_7->setSpacing(1);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        gridLayout_7->setContentsMargins(1, 1, 1, 1);
        axonTraceValueSpinBox = new QDoubleSpinBox(widget_10);
        axonTraceValueSpinBox->setObjectName(QString::fromUtf8("axonTraceValueSpinBox"));
        sizePolicy.setHeightForWidth(axonTraceValueSpinBox->sizePolicy().hasHeightForWidth());
        axonTraceValueSpinBox->setSizePolicy(sizePolicy);
        axonTraceValueSpinBox->setFont(font2);
        axonTraceValueSpinBox->setMaximum(99999999.000000000000000);
        axonTraceValueSpinBox->setValue(1.000000000000000);

        gridLayout_7->addWidget(axonTraceValueSpinBox, 5, 1, 1, 1);

        diffuseValueLabel_2 = new QLabel(widget_10);
        diffuseValueLabel_2->setObjectName(QString::fromUtf8("diffuseValueLabel_2"));
        diffuseValueLabel_2->setFont(font1);
        diffuseValueLabel_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(diffuseValueLabel_2, 3, 0, 1, 1);

        label_13 = new QLabel(widget_10);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_13, 8, 0, 1, 1);

        label_4 = new QLabel(widget_10);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font1);
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_4, 7, 0, 1, 1);

        axonSemiautoTraceTresholdSpinBox = new QDoubleSpinBox(widget_10);
        axonSemiautoTraceTresholdSpinBox->setObjectName(QString::fromUtf8("axonSemiautoTraceTresholdSpinBox"));
        axonSemiautoTraceTresholdSpinBox->setMaximum(100.000000000000000);
        axonSemiautoTraceTresholdSpinBox->setValue(8.000000000000000);

        gridLayout_7->addWidget(axonSemiautoTraceTresholdSpinBox, 8, 1, 1, 1);

        maxBoundNumSpinBox = new QSpinBox(widget_10);
        maxBoundNumSpinBox->setObjectName(QString::fromUtf8("maxBoundNumSpinBox"));
        sizePolicy.setHeightForWidth(maxBoundNumSpinBox->sizePolicy().hasHeightForWidth());
        maxBoundNumSpinBox->setSizePolicy(sizePolicy);
        maxBoundNumSpinBox->setValue(10);

        gridLayout_7->addWidget(maxBoundNumSpinBox, 7, 1, 1, 1);

        axonDiffuseValueSpinBox = new QDoubleSpinBox(widget_10);
        axonDiffuseValueSpinBox->setObjectName(QString::fromUtf8("axonDiffuseValueSpinBox"));
        sizePolicy.setHeightForWidth(axonDiffuseValueSpinBox->sizePolicy().hasHeightForWidth());
        axonDiffuseValueSpinBox->setSizePolicy(sizePolicy);
        axonDiffuseValueSpinBox->setMaximum(99999.000000000000000);
        axonDiffuseValueSpinBox->setValue(50.000000000000000);

        gridLayout_7->addWidget(axonDiffuseValueSpinBox, 3, 1, 1, 1);

        strongSignalCheckBox = new QCheckBox(widget_10);
        strongSignalCheckBox->setObjectName(QString::fromUtf8("strongSignalCheckBox"));
        QFont font3;
        font3.setKerning(true);
        strongSignalCheckBox->setFont(font3);
        strongSignalCheckBox->setLayoutDirection(Qt::RightToLeft);
        strongSignalCheckBox->setChecked(true);
        strongSignalCheckBox->setTristate(false);

        gridLayout_7->addWidget(strongSignalCheckBox, 10, 0, 1, 1);

        enableSVMBox = new QCheckBox(widget_10);
        enableSVMBox->setObjectName(QString::fromUtf8("enableSVMBox"));
        enableSVMBox->setLayoutDirection(Qt::RightToLeft);
        enableSVMBox->setChecked(false);

        gridLayout_7->addWidget(enableSVMBox, 10, 1, 1, 1);

        axonSemiautoConnectResampleSpinBox = new QDoubleSpinBox(widget_10);
        axonSemiautoConnectResampleSpinBox->setObjectName(QString::fromUtf8("axonSemiautoConnectResampleSpinBox"));
        axonSemiautoConnectResampleSpinBox->setMinimum(1.000000000000000);
        axonSemiautoConnectResampleSpinBox->setValue(4.000000000000000);

        gridLayout_7->addWidget(axonSemiautoConnectResampleSpinBox, 9, 1, 1, 1);

        label_14 = new QLabel(widget_10);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_14, 9, 0, 1, 1);

        label_2 = new QLabel(widget_10);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setLayoutDirection(Qt::LeftToRight);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_2, 5, 0, 1, 1);


        gridLayout_3->addWidget(widget_10, 1, 0, 1, 2);

        pushButton_3 = new QPushButton(widget_6);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setIcon(icon);
        pushButton_3->setCheckable(true);
        pushButton_3->setChecked(true);
        pushButton_3->setFlat(true);

        gridLayout_3->addWidget(pushButton_3, 0, 0, 1, 1);


        gridLayout_5->addWidget(widget_6, 1, 0, 1, 1);

        widget_13 = new QWidget(tab_3);
        widget_13->setObjectName(QString::fromUtf8("widget_13"));
        gridLayout_4 = new QGridLayout(widget_13);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(1, 1, 1, 1);
        pushButton_5 = new QPushButton(widget_13);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy4);
        pushButton_5->setIcon(icon);
        pushButton_5->setCheckable(true);
        pushButton_5->setChecked(true);
        pushButton_5->setFlat(true);

        gridLayout_4->addWidget(pushButton_5, 0, 0, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(87, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_8, 0, 1, 1, 1);

        widget_17 = new QWidget(widget_13);
        widget_17->setObjectName(QString::fromUtf8("widget_17"));
        gridLayout_8 = new QGridLayout(widget_17);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        lowMapLabel_3 = new QLabel(widget_17);
        lowMapLabel_3->setObjectName(QString::fromUtf8("lowMapLabel_3"));

        gridLayout_8->addWidget(lowMapLabel_3, 0, 0, 1, 1);

        SmoothSlider = new QSlider(widget_17);
        SmoothSlider->setObjectName(QString::fromUtf8("SmoothSlider"));
        SmoothSlider->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(SmoothSlider, 0, 1, 1, 1);


        gridLayout_4->addWidget(widget_17, 1, 0, 1, 2);


        gridLayout_5->addWidget(widget_13, 2, 0, 1, 1);

        widget_18 = new QWidget(tab_3);
        widget_18->setObjectName(QString::fromUtf8("widget_18"));
        gridLayout_22 = new QGridLayout(widget_18);
        gridLayout_22->setSpacing(1);
        gridLayout_22->setContentsMargins(11, 11, 11, 11);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        gridLayout_22->setContentsMargins(1, 1, 1, 1);
        pushButton_10 = new QPushButton(widget_18);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setIcon(icon);
        pushButton_10->setCheckable(true);
        pushButton_10->setChecked(true);
        pushButton_10->setFlat(true);

        gridLayout_22->addWidget(pushButton_10, 0, 0, 1, 1, Qt::AlignLeft);

        widget_20 = new QWidget(widget_18);
        widget_20->setObjectName(QString::fromUtf8("widget_20"));
        gridLayout_23 = new QGridLayout(widget_20);
        gridLayout_23->setSpacing(1);
        gridLayout_23->setContentsMargins(11, 11, 11, 11);
        gridLayout_23->setObjectName(QString::fromUtf8("gridLayout_23"));
        gridLayout_23->setContentsMargins(1, 1, 1, 1);
        axonThresholdSpinBox = new QDoubleSpinBox(widget_20);
        axonThresholdSpinBox->setObjectName(QString::fromUtf8("axonThresholdSpinBox"));
        sizePolicy.setHeightForWidth(axonThresholdSpinBox->sizePolicy().hasHeightForWidth());
        axonThresholdSpinBox->setSizePolicy(sizePolicy);
        axonThresholdSpinBox->setMaximum(9999.000000000000000);
        axonThresholdSpinBox->setValue(20.000000000000000);

        gridLayout_23->addWidget(axonThresholdSpinBox, 0, 1, 1, 1);

        ThresholdLabel_5 = new QLabel(widget_20);
        ThresholdLabel_5->setObjectName(QString::fromUtf8("ThresholdLabel_5"));
        sizePolicy.setHeightForWidth(ThresholdLabel_5->sizePolicy().hasHeightForWidth());
        ThresholdLabel_5->setSizePolicy(sizePolicy);
        ThresholdLabel_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_23->addWidget(ThresholdLabel_5, 0, 0, 1, 1, Qt::AlignLeft);

        previewAxonBinaryButton = new QPushButton(widget_20);
        previewAxonBinaryButton->setObjectName(QString::fromUtf8("previewAxonBinaryButton"));
        previewAxonBinaryButton->setCheckable(true);

        gridLayout_23->addWidget(previewAxonBinaryButton, 1, 0, 1, 1);


        gridLayout_22->addWidget(widget_20, 1, 0, 1, 1);


        gridLayout_5->addWidget(widget_18, 0, 0, 1, 1);

        widget_21 = new QWidget(tab_3);
        widget_21->setObjectName(QString::fromUtf8("widget_21"));
        gridLayout_26 = new QGridLayout(widget_21);
        gridLayout_26->setSpacing(6);
        gridLayout_26->setContentsMargins(11, 11, 11, 11);
        gridLayout_26->setObjectName(QString::fromUtf8("gridLayout_26"));
        pushButton_12 = new QPushButton(widget_21);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        sizePolicy4.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy4);
        pushButton_12->setIcon(icon);
        pushButton_12->setCheckable(true);
        pushButton_12->setChecked(true);
        pushButton_12->setFlat(true);

        gridLayout_26->addWidget(pushButton_12, 0, 0, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(94, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_26->addItem(horizontalSpacer_11, 0, 1, 1, 1);

        CrudeShapecheckBox = new QCheckBox(widget_21);
        CrudeShapecheckBox->setObjectName(QString::fromUtf8("CrudeShapecheckBox"));

        gridLayout_26->addWidget(CrudeShapecheckBox, 1, 0, 1, 2);


        gridLayout_5->addWidget(widget_21, 3, 0, 1, 1);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        gridLayout_11 = new QGridLayout(tab_4);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        tabWidget->addTab(tab_4, QString());

        gridLayout_14->addWidget(tabWidget, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents_2);

        gridLayout_10->addWidget(scrollArea, 0, 0, 1, 1);

        BinarySettingsDockWidget->setWidget(widget);
        QWidget::setTabOrder(tabWidget, pushButton);
        QWidget::setTabOrder(pushButton, xMinspinBox);
        QWidget::setTabOrder(xMinspinBox, xMaxspinBox);
        QWidget::setTabOrder(xMaxspinBox, yMinspinBox);
        QWidget::setTabOrder(yMinspinBox, yMaxspinBox);
        QWidget::setTabOrder(yMaxspinBox, zMinspinBox);
        QWidget::setTabOrder(zMinspinBox, zMaxspinBox);
        QWidget::setTabOrder(zMaxspinBox, levelSpinBox);
        QWidget::setTabOrder(levelSpinBox, applyImageReadButton);
        QWidget::setTabOrder(applyImageReadButton, action_ClearCache_Button);
        QWidget::setTabOrder(action_ClearCache_Button, pushButton_4);
        QWidget::setTabOrder(pushButton_4, lowOpacSpinBox);
        QWidget::setTabOrder(lowOpacSpinBox, highOpacSpinBox);
        QWidget::setTabOrder(highOpacSpinBox, thicknessspinBox);
        QWidget::setTabOrder(thicknessspinBox, resXSpinBox);
        QWidget::setTabOrder(resXSpinBox, resYSpinBox);
        QWidget::setTabOrder(resYSpinBox, resZSpinBox);
        QWidget::setTabOrder(resZSpinBox, applyResButton);
        QWidget::setTabOrder(applyResButton, pushButton_6);
        QWidget::setTabOrder(pushButton_6, xBlockSizespinBox);
        QWidget::setTabOrder(xBlockSizespinBox, yBlockSizespinBox);
        QWidget::setTabOrder(yBlockSizespinBox, zBlockSizespinBox);
        QWidget::setTabOrder(zBlockSizespinBox, pushButton_9);
        QWidget::setTabOrder(pushButton_9, AveragecheckBox);
        QWidget::setTabOrder(AveragecheckBox, xScaleSpinBox);
        QWidget::setTabOrder(xScaleSpinBox, yScaleSpinBox);
        QWidget::setTabOrder(yScaleSpinBox, zScaleSpinBox);
        QWidget::setTabOrder(zScaleSpinBox, pushButton_11);
        QWidget::setTabOrder(pushButton_11, origLowOpacSpinBox);
        QWidget::setTabOrder(origLowOpacSpinBox, origHighOpacSpinBox);
        QWidget::setTabOrder(origHighOpacSpinBox, destLowOpacSpinBox);
        QWidget::setTabOrder(destLowOpacSpinBox, destHighOpacSpinBox);
        QWidget::setTabOrder(destHighOpacSpinBox, previewIlluminationMapButton);
        QWidget::setTabOrder(previewIlluminationMapButton, imageOpacInfoButton);
        QWidget::setTabOrder(imageOpacInfoButton, opacApplyButton);
        QWidget::setTabOrder(opacApplyButton, autoOpacSetCheckBox);
        QWidget::setTabOrder(autoOpacSetCheckBox, CrudeShapecheckBox);
        QWidget::setTabOrder(CrudeShapecheckBox, pushButton_7);
        QWidget::setTabOrder(pushButton_7, thresholdSpinBox);
        QWidget::setTabOrder(thresholdSpinBox, previewBinaryButton);
        QWidget::setTabOrder(previewBinaryButton, pushButton_8);
        QWidget::setTabOrder(pushButton_8, diffuseValueSpinBox);
        QWidget::setTabOrder(diffuseValueSpinBox, traceValueSpinBox);
        QWidget::setTabOrder(traceValueSpinBox, GPSSVMcheckBox);
        QWidget::setTabOrder(GPSSVMcheckBox, BigSomacheckBox);
        QWidget::setTabOrder(BigSomacheckBox, scrollArea);
        QWidget::setTabOrder(scrollArea, pushButton_10);
        QWidget::setTabOrder(pushButton_10, axonThresholdSpinBox);
        QWidget::setTabOrder(axonThresholdSpinBox, previewAxonBinaryButton);
        QWidget::setTabOrder(previewAxonBinaryButton, pushButton_3);
        QWidget::setTabOrder(pushButton_3, axonDiffuseValueSpinBox);
        QWidget::setTabOrder(axonDiffuseValueSpinBox, axonTraceValueSpinBox);
        QWidget::setTabOrder(axonTraceValueSpinBox, maxBoundNumSpinBox);
        QWidget::setTabOrder(maxBoundNumSpinBox, axonSemiautoTraceTresholdSpinBox);
        QWidget::setTabOrder(axonSemiautoTraceTresholdSpinBox, axonSemiautoConnectResampleSpinBox);
        QWidget::setTabOrder(axonSemiautoConnectResampleSpinBox, enableSVMBox);
        QWidget::setTabOrder(enableSVMBox, strongSignalCheckBox);
        QWidget::setTabOrder(strongSignalCheckBox, pushButton_5);
        QWidget::setTabOrder(pushButton_5, SmoothSlider);
        QWidget::setTabOrder(SmoothSlider, pushButton_12);

        retranslateUi(BinarySettingsDockWidget);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(BinarySettingsDockWidget);
    } // setupUi

    void retranslateUi(QDockWidget *BinarySettingsDockWidget)
    {
        BinarySettingsDockWidget->setWindowTitle(QApplication::translate("BinarySettingsDockWidget", "BinarySettingsDockWidget", nullptr));
        pushButton_6->setText(QApplication::translate("BinarySettingsDockWidget", "Block Radius", nullptr));
        pushButton_11->setText(QApplication::translate("BinarySettingsDockWidget", "Illuminant", nullptr));
        pushButton_9->setText(QApplication::translate("BinarySettingsDockWidget", "Resample", nullptr));
        pushButton_4->setText(QApplication::translate("BinarySettingsDockWidget", "Display", nullptr));
        label_34->setText(QApplication::translate("BinarySettingsDockWidget", "ResolutionY", nullptr));
        label_35->setText(QApplication::translate("BinarySettingsDockWidget", "ResolutionZ", nullptr));
        label_33->setText(QApplication::translate("BinarySettingsDockWidget", "ResolutionX", nullptr));
        lowMapLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Min Opac", nullptr));
        highMapLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Max Opac", nullptr));
        label_5->setText(QApplication::translate("BinarySettingsDockWidget", "Thickness", nullptr));
        applyResButton->setText(QApplication::translate("BinarySettingsDockWidget", "Apply Res", nullptr));
        pushButton->setText(QApplication::translate("BinarySettingsDockWidget", "Image Range", nullptr));
        imageRangeLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Image Size:", nullptr));
        xMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "xMin", nullptr));
        xMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "xMax", nullptr));
        yMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "yMin", nullptr));
        yMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "yMax", nullptr));
        zMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "zMin", nullptr));
        zMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "zMax", nullptr));
        label_3->setText(QApplication::translate("BinarySettingsDockWidget", "Level", nullptr));
        applyImageReadButton->setText(QApplication::translate("BinarySettingsDockWidget", "Apply Read", nullptr));
        action_ClearCache_Button->setText(QApplication::translate("BinarySettingsDockWidget", "Clear Cache", nullptr));
        label_8->setText(QApplication::translate("BinarySettingsDockWidget", "Original", nullptr));
        label_11->setText(QApplication::translate("BinarySettingsDockWidget", "|", nullptr));
        label_12->setText(QApplication::translate("BinarySettingsDockWidget", "|", nullptr));
        label_10->setText(QApplication::translate("BinarySettingsDockWidget", "Dest", nullptr));
        previewIlluminationMapButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        imageOpacInfoButton->setText(QApplication::translate("BinarySettingsDockWidget", "Info", nullptr));
        opacApplyButton->setText(QApplication::translate("BinarySettingsDockWidget", "Apply", nullptr));
        autoOpacSetCheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Auto", nullptr));
        highMapLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "yBlock", nullptr));
        lowMapLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "xBlock", nullptr));
        highMapLabel_3->setText(QApplication::translate("BinarySettingsDockWidget", "zBlock", nullptr));
        label->setText(QApplication::translate("BinarySettingsDockWidget", "xScale", nullptr));
        label_6->setText(QApplication::translate("BinarySettingsDockWidget", "yScale", nullptr));
        label_7->setText(QApplication::translate("BinarySettingsDockWidget", "zScale", nullptr));
        AveragecheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Average when downsizing", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("BinarySettingsDockWidget", "Image", nullptr));
        pushButton_7->setText(QApplication::translate("BinarySettingsDockWidget", "Binary Option", nullptr));
        ThresholdLabel_4->setText(QApplication::translate("BinarySettingsDockWidget", "Threshold", nullptr));
        previewBinaryButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        pushButton_8->setText(QApplication::translate("BinarySettingsDockWidget", "Trace Option", nullptr));
        GPSSVMcheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "GPS-SVM", nullptr));
        diffuseValueLabel_4->setText(QApplication::translate("BinarySettingsDockWidget", "Bifur", nullptr));
        label_9->setText(QApplication::translate("BinarySettingsDockWidget", "Trace", nullptr));
        BigSomacheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Big Soma", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("BinarySettingsDockWidget", "NeuroGPS", nullptr));
        diffuseValueLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "Axon Bifur", nullptr));
        label_13->setText(QApplication::translate("BinarySettingsDockWidget", "Semi Rate(%)", nullptr));
        label_4->setText(QApplication::translate("BinarySettingsDockWidget", "Bound MaxNum", nullptr));
        strongSignalCheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Strong Noise", nullptr));
        enableSVMBox->setText(QApplication::translate("BinarySettingsDockWidget", "Enable SVM", nullptr));
        label_14->setText(QApplication::translate("BinarySettingsDockWidget", "Resample Distance", nullptr));
        label_2->setText(QApplication::translate("BinarySettingsDockWidget", "Axon Trace", nullptr));
        pushButton_3->setText(QApplication::translate("BinarySettingsDockWidget", "Trace Option", nullptr));
        pushButton_5->setText(QApplication::translate("BinarySettingsDockWidget", "Smooth Option", nullptr));
        lowMapLabel_3->setText(QApplication::translate("BinarySettingsDockWidget", "Smooth Level", nullptr));
        pushButton_10->setText(QApplication::translate("BinarySettingsDockWidget", "Binary Option", nullptr));
        ThresholdLabel_5->setText(QApplication::translate("BinarySettingsDockWidget", "Threshold", nullptr));
        previewAxonBinaryButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        pushButton_12->setText(QApplication::translate("BinarySettingsDockWidget", "Reconstruction", nullptr));
        CrudeShapecheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Crude fiber shape reconstruction", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("BinarySettingsDockWidget", "Axon", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("BinarySettingsDockWidget", "Editor", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BinarySettingsDockWidget: public Ui_BinarySettingsDockWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BINARYSETTINGSDOCKWIDGET_H
