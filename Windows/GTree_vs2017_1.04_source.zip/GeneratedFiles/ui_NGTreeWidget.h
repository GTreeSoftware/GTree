/********************************************************************************
** Form generated from reading UI file 'NGTreeWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NGTREEWIDGET_H
#define UI_NGTREEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTreeWidget>

QT_BEGIN_NAMESPACE

class Ui_NGTreeWidget
{
public:

    void setupUi(QTreeWidget *NGTreeWidget)
    {
        if (NGTreeWidget->objectName().isEmpty())
            NGTreeWidget->setObjectName(QString::fromUtf8("NGTreeWidget"));
        NGTreeWidget->resize(400, 300);
        if (NGTreeWidget->header()->objectName().isEmpty())

        retranslateUi(NGTreeWidget);

        QMetaObject::connectSlotsByName(NGTreeWidget);
    } // setupUi

    void retranslateUi(QTreeWidget *NGTreeWidget)
    {
        NGTreeWidget->setWindowTitle(QApplication::translate("NGTreeWidget", "NGTreeWidget", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NGTreeWidget: public Ui_NGTreeWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NGTREEWIDGET_H
