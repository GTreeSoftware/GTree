#include "DeepTraverse.h"
#include "Function/IO/MOSTDReader.h"
#include "Function/Trace/CaliberBuilder.h"
#include "../../ngtypes/volume.h"
#include "imagewriter.h"
#include <QMutexLocker>
#include <QMessageBox>

DeepTraverse::DeepTraverse()
{
	className_ = std::string("DeepTraverse");
	paramPackCp = std::make_shared<ParamPack>();
	paramPackCpShapes = std::make_shared<ParamPack>();
	isstarted = false;
}


DeepTraverse::~DeepTraverse()
{
}

void DeepTraverse::SetEmptyData(bool arg){
	isNeedEmptyData = arg;
	//printf("DeepTraverse:%d\n", isNeedEmptyData);
}
void DeepTraverse::SetSaveCurves(bool arg){
	isSaveCurves = arg;
}

void DeepTraverse::SetSaveShapes(bool arg){
	isSaveShapes = arg;
}

void DeepTraverse::SetImageRange(int *arg){
	RangeMin(0) = arg[0];
	RangeMax(0) = arg[1];
	RangeMin(1) = arg[2];
	RangeMax(1) = arg[3];
	RangeMin(2) = arg[4];
	RangeMax(2) = arg[5];
}

void DeepTraverse::SetStartPosition(int *arg){
	StartingPoint << arg[0] / 10 * 10, arg[1] / 10 * 10, arg[2] / 10 * 10;
}

void DeepTraverse::SetPatchSize(int *arg){
	BoxRange << arg[0], arg[1], arg[2];
	TraverseStep << arg[0] - arg[3], arg[1] - arg[4], arg[2] - arg[5];
}

bool DeepTraverse::Initial(){
	if (!paramPack->separateTree) return false;
	relRange = (RangeMax.array() - RangeMin.array()).array() / TraverseStep.array();
	relRange(0) = std::ceil(relRange(0));
	relRange(1) = std::ceil(relRange(1));
	relRange(2) = std::ceil(relRange(2));
	MakeTraverseArray();
	indexCp = index;
	SetReadParam(StartingPoint(0), StartingPoint(1), StartingPoint(2));
	printf("Initial finish.\n");
	forceThreadStop_ = false;
	isstarted = false;
	return true;
}

void DeepTraverse::SetParam(const std::string& pth, NGParamPack& arg2){
	paramPack = std::make_shared<ParamPack>();
	*paramPack = *arg2;
	paramPack->mostdLevel_ = 1;
	*paramPackCp = *paramPack;
	*paramPackCpShapes = *paramPack;
	mostdReader = MOSTDReader::New();
	mostdReader->SetParam(paramPack);
	mostdReader->SetInputFileName(pth);
}


void DeepTraverse::SetReadParam(double xx, double yy, double zz){
	int idxx = ceil((xx - RangeMin(0) + 1) / TraverseStep(0));// +1 :beacuse of boundary
	int idxy = ceil((yy - RangeMin(1) + 1) / TraverseStep(1));
	int idxz = ceil((zz - RangeMin(2) + 1) / TraverseStep(2));
	index = idxx - 1 + (idxy - 1)*relRange(0) + (idxz - 1)*relRange(0)*relRange(1);
	indexCp = index;
}

bool DeepTraverse::GetNextImage(){
	isstarted = true;
	StartImageThread();

	return true;
}

void DeepTraverse::StartImageThread(){
	while (indexCp < TraverseFlagArray.size() && isstarted == true){
		//printf("StartImageThread:%d\n", isNeedEmptyData);
		if (!isNeedEmptyData && TraverseFlagArray[indexCp] == 0){
			indexCp++;
			continue;
		}

		if (indexCp >= TraverseFlagArray.size()){
			printf("Deep Traverse finish.\n");
			return;
		}

		int zn = 1 + ((indexCp) / ((int)relRange(0)*(int)relRange(1)));
		int xyn = (indexCp) % ((int)relRange(0)*(int)relRange(1));
		int yn = 1 + (xyn / (int)relRange(0));
		int xn = 1 + (xyn % (int)relRange(0));
		paramPackCp->xMin_ = StartingPoint(0) + ((xn - 1) * TraverseStep(0));
		paramPackCp->yMin_ = StartingPoint(1) + ((yn - 1) * TraverseStep(1));
		paramPackCp->zMin_ = StartingPoint(2) + ((zn - 1) * TraverseStep(2));
		paramPackCp->xMax_ = paramPackCp->xMin_ + BoxRange(0) - 1;
		paramPackCp->yMax_ = paramPackCp->yMin_ + BoxRange(1) - 1;
		paramPackCp->zMax_ = paramPackCp->zMin_ + BoxRange(2) - 1;
		printf("... %d %d %d\n", indexCp, paramPackCp->zMin_, paramPackCp->zMax_);
		mostdReader->SetParam(paramPackCp);
		printf("%d %d %d %d %d %d\n", paramPackCp->xMin_, paramPackCp->xMax_, paramPackCp->yMin_, paramPackCp->yMax_, paramPackCp->zMin_, paramPackCp->zMax_);
		if (!mostdReader->Update()->success()){
			printf("!!!\n");
			return;
		}

		if (forceThreadStop_){
			deepImageDeque.clear();
			mostdReader->ReleaseData();
			forceThreadStop_ = false;
			return;
		}
		IDataPointer OrigImage;
		OrigImage = NULL;
		OrigImage.reset();
		OrigImage = mostdReader->ReleaseData();

		paramPackCpShapes->OrigImage = std::dynamic_pointer_cast<SVolume>(OrigImage);
		paramPackCpShapes->xMin_ = paramPackCp->xMin_;
		paramPackCpShapes->xMax_ = paramPackCp->xMax_;
		paramPackCpShapes->yMin_ = paramPackCp->yMin_;
		paramPackCpShapes->yMax_ = paramPackCp->yMax_;
		paramPackCpShapes->zMin_ = paramPackCp->zMin_;
		paramPackCpShapes->zMax_ = paramPackCp->zMax_;
		if (isSaveCurves == true || isSaveShapes == true){
			ShapeRun();
		}
		indexCp++;
	}
	printf("stop stop stop stop stop\n");
}

void DeepTraverse::ShapeRun(){
	if (paramPackCpShapes->OrigImage){
		int xmin = paramPackCpShapes->xMin_;
		int ymin = paramPackCpShapes->yMin_;
		int zmin = paramPackCpShapes->zMin_;
		int xmax = paramPackCpShapes->xMax_;
		int ymax = paramPackCpShapes->yMax_;
		int zmax = paramPackCpShapes->zMax_;
		NG_CREATE_DYNAMIC_CAST(NeuronPopulation, alltree, paramPackCpShapes->separateTree);
		auto pop_ = alltree->m_pop;
		Line5d tmpcurve, cursubCurves;
		Vec5d curCoord;
		curves.clear();
		for (auto &tree_ : pop_)
		{
			auto allcurve = tree_->m_curveList;
			for (int i = 0; i < allcurve.size(); ++i){
				tmpcurve = allcurve[i];
				cursubCurves.clear();
				for (int j = 0; j < tmpcurve.size(); ++j){
					curCoord = tmpcurve[j];
					if (curCoord(0) > xmax || curCoord(0) < xmin || curCoord(1) > ymax || curCoord(1) < ymin || curCoord(2) > zmax || curCoord(2) < zmin) continue;
					if (curCoord(0) < xmax && curCoord(0) > xmin && curCoord(1) < ymax && curCoord(1) > ymin && curCoord(2) < zmax && curCoord(2) > zmin){
						cursubCurves.push_back(curCoord);//TODO:
					}
				}
				if (cursubCurves.size() > 0){
					curves.push_back(cursubCurves);
				}
			}
		}
	}
	shapes.clear();
	if (curves.size()){
		if (curves[0].size() > 1)
		{
			NGCaliberBuilder caliberBuilder = CaliberBuilder::New();
			caliberBuilder->SetParam(paramPackCpShapes);
			caliberBuilder->SetLinePoints(curves);
			if (!caliberBuilder->Update()->success()){
				return;
			}
			shapes.clear();
			shapes = *(caliberBuilder->GetCaliberPointSet());
		}
	}
	if (!Save_())return;
	printf("Deep Traverse shapes thread.\n");
}

bool DeepTraverse::Save_(){
	QString saveName;

	//save OrigImage
	if (paramPackCpShapes->OrigImage) {
		saveName = paramPackCpShapes->defaultDir + QString("/%1_%2_%3").arg(paramPackCpShapes->xMin_).arg(paramPackCpShapes->yMin_).arg(paramPackCpShapes->zMin_) + QString(".tif");
		NGImageWriter writer = ImageWriter::New();
		writer->SetOutputFileName(saveName.toStdString());
		writer->SetInput(paramPackCpShapes->OrigImage);//OrigImage
		auto res = writer->Update();
		if (!res->success()){
			printf("error in deepshapesthread Save_.\n");
			//QMessageBox::warning(this, QString::fromStdString(res->ErrorClassName()), QString::fromStdString(res->ErrorInfo()));
			return false;
		}
		printf("save image:%s\n", (const char*)saveName.toLocal8Bit());
	}
	//save curves
	if (curves.size()){
		if (curves[0].size() > 1)
		{
			for (int i = 0; i < curves.size(); ++i){
				QString swcPath = saveName.section('.', 0, -2) + QString(tr("_%1").arg(i, 3, 10, QChar('0'))) + QString(".swc");
				FILE* fp = fopen(swcPath.toStdString().c_str(), "w");
				if (!fp) return false;//TODO:
				for (int id = 0; id < curves[i].size(); ++id){
					if (id == 0){
						fprintf(fp, "%d 1 %lf %lf %lf 1.0 -1\n", id + 1, (curves[i][id](0) - paramPackCpShapes->xMin_) *paramPackCpShapes->xRes_,
							(curves[i][id](1) - paramPackCpShapes->yMin_) *paramPackCpShapes->yRes_, (curves[i][id](2) - paramPackCpShapes->zMin_) *paramPackCpShapes->zRes_);
					}
					else{
						fprintf(fp, "%d 1 %lf %lf %lf 1.0 %d\n", id + 1, (curves[i][id](0) - paramPackCpShapes->xMin_) *paramPackCpShapes->xRes_,
							(curves[i][id](1) - paramPackCpShapes->yMin_) *paramPackCpShapes->yRes_, (curves[i][id](2) - paramPackCpShapes->zMin_) *paramPackCpShapes->zRes_, id);
					}
				}
				fclose(fp);
			}
		}
	}
	//save shapes
	if (shapes.size()){
		if (shapes[0].size() > 1){
			QString shapesPath = saveName.section('.', 0, -2) + QString("_shapes.swc");
			FILE* fp = fopen(shapesPath.toStdString().c_str(), "w");
			if (!fp) return false;//TODO:
			int id = 0;
			for (int i = 0; i < shapes.size(); ++i){
				for (int j = 0; j < shapes[i].size(); ++j){
					fprintf(fp, "%d 1 %lf %lf %lf 1.0 -1\n", ++id, (shapes[i][j](0) - paramPackCpShapes->xMin_) *paramPackCpShapes->xRes_,
						(shapes[i][j](1) - paramPackCpShapes->yMin_) *paramPackCpShapes->yRes_, (shapes[i][j](2) - paramPackCpShapes->zMin_) *paramPackCpShapes->zRes_);
				}

			}
			fclose(fp);
		}
	}
	return true;
}



void DeepTraverse::MakeTraverseArray(){
	NG_CREATE_DYNAMIC_CAST(NeuronPopulation, alltree, paramPack->separateTree);
	auto pop_ = alltree->m_pop;
	Line5d tmpcurve;
	Vec5d curCoord, relCoord;
	int idx;
	std::vector<int> TraverseFlagArray_((relRange(0)*relRange(1)*relRange(2) + relRange(0)*relRange(1) + relRange(0)), 0);
	for (auto &tree_ : pop_)
	{
		auto allcurve = tree_->m_curveList;
		for (int i = 0; i < allcurve.size(); ++i){
			tmpcurve = allcurve[i];
			for (int j = 0; j < tmpcurve.size(); ++j){
				if (tmpcurve[j](0) < RangeMax(0) && tmpcurve[j](1) < RangeMax(1) && tmpcurve[j](2) < RangeMax(2)
					&& tmpcurve[j](0) > RangeMin(0) && tmpcurve[j](1) > RangeMin(1) && tmpcurve[j](2) > RangeMin(2)){
					relCoord.middleRows(0, 3) = ((tmpcurve[j].middleRows(0, 3) - RangeMin).array() / TraverseStep.array());//TODO:
					relCoord(0) = std::ceil(relCoord(0));
					relCoord(1) = std::ceil(relCoord(1));
					relCoord(2) = std::ceil(relCoord(2));
					idx = (relCoord(0) + (relCoord(1) - 1)*relRange(0) + (relCoord(2) - 1)*relRange(0)*relRange(1)) - 1;
					TraverseFlagArray_[(relCoord(0) + (relCoord(1) - 1)*relRange(0) + (relCoord(2) - 1)*relRange(0)*relRange(1)) - 1]++;
				}
			}
		}
	}
	TraverseFlagArray = TraverseFlagArray_;
	TraverseFlagArray_.clear();
}