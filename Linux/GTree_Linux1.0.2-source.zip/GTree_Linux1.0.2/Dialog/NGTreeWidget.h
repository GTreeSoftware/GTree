#ifndef NGTREEWIDGET_H
#define NGTREEWIDGET_H
#include <QTreeWidget>
#include <QAction>
#include "../ngtypes/ParamPack.h"
#include "../ngtypes/tree.h"
class QTreeWidgetItem;

class NGTreeWidget :
	public QTreeWidget
{
	Q_OBJECT
public:
	enum WIDGETMODE { TREEWIDGETMODE, CHECKWIDGETMODE, TRACEWIDGETMODE } widgetMode_;

	NGTreeWidget(QWidget *par = nullptr, WIDGETMODE = TREEWIDGETMODE);
	~NGTreeWidget();

	//enum ITEMTYPE{TREETYPE, CHECKTYPE};
	void addRoot(const QStringList&);
	void SetParam(NGParamPack arg) { paramPack_ = arg; }


public slots:
	void ActivateTree_Slot();
	void CompareTree_Slot();
	void ToggleTreeVisible_Slot();
	void GotoDiff_Slot();
	void TriggeredCheckState_Slot();
	void DeleteAnnotate_Slot();
	void ToggleShowDiffArrow_Slot(bool);
	void ResetTraverse_Slot();
	void ToggleShowTraverseFlag_Slot();
	//DataReduction
	void ParallelTrace_DisplayARegion_Slot();
	void ParallelTrace_ReviseTree_Slot();

protected:
	void CreateAction();
	virtual void contextMenuEvent(QContextMenuEvent *ev);

signals:
	void ActiveTree_Signal(int);
	void CompareTree_Signal(int);
	void ToggleTreeVisible_Signal(int);
	void GotoDiff_Signal(int);
	void ToggleShowDiffArrow_Signal(bool);
	void ResetTraverse_Signal();
	void ToggleShowTraverseFlag_Signal();
	//dataReduction
	void ParallelTrace_DisplayARegion_Signal(int, int, int);
	void ParallelTrace_ReviseTree_Signal();
	void ParallelTrace_ResetMODE_Signal();
private:
	QTreeWidgetItem *choosedTreeWidgetItem;
	QAction *pActivate_, *pCompare_, *pToggleTreeShow_, *pGotoDiff_, *pToggleCheckState_, *pDeleteAnnotate_, *pToggleShowDiffArrow_,
		*pClearTraverseRecord_, *pToggleShowTraverseFlag_;
	//action for datareduction
	QAction *pDisplay_, *pReviseTree;
	NGParamPack paramPack_;
	Vec4i Pos_4parallelTrace;
};

#endif