/**
 * @file HDF5Writer.h
 * @brief Implementation class for building HDF5 file.
 * @details Implementation class for building HDF5 file.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef HDF5WRITER_H
#define HDF5WRITER_H
#include "../ineuronio.h"
#include "ngtypes/ParamPack.h"
#include "ngtypes/volume.h"

#include <QProgressDialog>
#include <QApplication>
#include <QObject>

class HDF5Writer;
typedef std::shared_ptr<HDF5Writer> NGHDF5Writer;
/**
* @brief Implementation class for building HDF5 file.
*  It can build 8bit and 16bit HDF5 file. The size of targe big tiff image should be larger than 512. The dependency library is libhdf5.
*/
class HDF5Writer : public QObject, public INeuronIO
{
	Q_OBJECT
public:
	static NGHDF5Writer New();
	HDF5Writer();
	virtual ~HDF5Writer();
	/**
	* @brief Perform the building process of the HDF5 file.
	*/
	virtual ProcStatPointer Update();
	bool SetOutputFileName(const std::string& arg) { filename = arg; return true; }
	/**
	* @brief Perform the building process of the HDF5 file.
	* @param arg The path list of target 2D tiff images. These 2D tiff images are slices of big 3D tiff image.
	*/
	void SetTIFFFileList(const std::vector<std::string>& arg) { tiffList = arg; }
	void SetParam(NGParamPack arg) { paramPack_ = arg; }
	volatile bool stopFlag_ = false;

protected:
	//private function
	IDataPointer ReleaseData();
	ConstIDataPointer GetOutput();
	bool SetInputFileName(const std::string&) { return false; }
	//void Transfer1DPointerTo2DPointer_UCHAR(unsigned char *data, int x, int y, unsigned char** dst);
	void Transfer1DPointerTo2DPointer_USHORT(unsigned short *data, int x, int y, unsigned short*** dst);
	bool MakePyramid(const SVolume& orig, int level, SVolume &dst);

	int subblockSz_ = 256;
	NGParamPack paramPack_;
	std::string filename;
	std::vector<std::string> tiffList;

signals:
	void Progress_Signal(int);

};

#endif // !NGHDF5WRITER_H
