/**
 * @file StoreThread.h
 * @brief Fast image importing thread
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */

#ifndef STORETHREAD_H
#define STORETHREAD_H
#include <QApplication> 
#include <QThread>
//#include <QMutex>
//#include <QMutexLocker>
#include <memory>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"

NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
/**
* @brief Fast image importing thread
* Used in traverse mode. It will automatically load the subsequent image blocks in cache list.
*/
class StoreThread : public QThread
{
	Q_OBJECT
public:
	StoreThread(QObject *parent = nullptr);
	~StoreThread();
	/**
	* @brief Set wrapper of common parameters and brain-wide image importing class
	* @param paramPack The wrapper of common parameters.
	* @param reader The base pointer of brain-wide image importing class
	* @return Tracing status
	*/
	void setParam(NGParamPack &paramPack, NGNeuronBigReader reader);
	void stop();
	bool RetVal()const{ return retVal; }
	IDataPointer Imagedata;

protected:
	void run();

signals:

private:
    //
    //QMutex *mutex;
    //
	NGNeuronBigReader mostdReader;
	NGParamPack paramPack;
	volatile bool stopped;//no use
	///--------------data------------------------------
	bool			isInit;//
	INeuronProcessPointer filter;
	//run status----//
	bool retVal;
};

#endif