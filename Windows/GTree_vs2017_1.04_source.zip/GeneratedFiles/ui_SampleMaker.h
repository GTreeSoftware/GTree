/********************************************************************************
** Form generated from reading UI file 'SampleMaker.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAMPLEMAKER_H
#define UI_SAMPLEMAKER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SampleMakerWidget
{
public:
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *label_7;
    QLineEdit *mostdPathEdit;
    QPushButton *mostdPathButton;
    QLabel *label_8;
    QLineEdit *dstPathEdit;
    QPushButton *dstPathButton;
    QGridLayout *gridLayout_2;
    QLineEdit *xRangeEdit;
    QSpinBox *zBlockBox;
    QLabel *label_4;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_6;
    QLineEdit *zRangeEdit;
    QLabel *label_5;
    QLineEdit *yRangeEdit;
    QSpinBox *xBlockBox;
    QLabel *label;
    QSpinBox *yBlockBox;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_9;
    QLineEdit *prefixEdit;
    QLabel *label_10;
    QLineEdit *postEdit;
    QHBoxLayout *horizontalLayout;
    QPushButton *startButton;
    QPushButton *stopButton;
    QPushButton *initTxtButton;
    QTextBrowser *textBrowser;
    QProgressBar *progressBar;

    void setupUi(QWidget *SampleMakerWidget)
    {
        if (SampleMakerWidget->objectName().isEmpty())
            SampleMakerWidget->setObjectName(QString::fromUtf8("SampleMakerWidget"));
        SampleMakerWidget->resize(458, 575);
        gridLayout_3 = new QGridLayout(SampleMakerWidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_7 = new QLabel(SampleMakerWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 0, 0, 1, 1);

        mostdPathEdit = new QLineEdit(SampleMakerWidget);
        mostdPathEdit->setObjectName(QString::fromUtf8("mostdPathEdit"));

        gridLayout->addWidget(mostdPathEdit, 0, 1, 1, 1);

        mostdPathButton = new QPushButton(SampleMakerWidget);
        mostdPathButton->setObjectName(QString::fromUtf8("mostdPathButton"));

        gridLayout->addWidget(mostdPathButton, 0, 2, 1, 1);

        label_8 = new QLabel(SampleMakerWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 1, 0, 1, 1);

        dstPathEdit = new QLineEdit(SampleMakerWidget);
        dstPathEdit->setObjectName(QString::fromUtf8("dstPathEdit"));

        gridLayout->addWidget(dstPathEdit, 1, 1, 1, 1);

        dstPathButton = new QPushButton(SampleMakerWidget);
        dstPathButton->setObjectName(QString::fromUtf8("dstPathButton"));

        gridLayout->addWidget(dstPathButton, 1, 2, 1, 1);


        verticalLayout->addLayout(gridLayout);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        xRangeEdit = new QLineEdit(SampleMakerWidget);
        xRangeEdit->setObjectName(QString::fromUtf8("xRangeEdit"));

        gridLayout_2->addWidget(xRangeEdit, 0, 2, 1, 1);

        zBlockBox = new QSpinBox(SampleMakerWidget);
        zBlockBox->setObjectName(QString::fromUtf8("zBlockBox"));
        zBlockBox->setMaximum(1000);
        zBlockBox->setValue(60);

        gridLayout_2->addWidget(zBlockBox, 5, 1, 1, 2);

        label_4 = new QLabel(SampleMakerWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_2->addWidget(label_4, 3, 0, 1, 2);

        label_3 = new QLabel(SampleMakerWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 2);

        label_2 = new QLabel(SampleMakerWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 1, 0, 1, 2);

        label_6 = new QLabel(SampleMakerWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_2->addWidget(label_6, 5, 0, 1, 1);

        zRangeEdit = new QLineEdit(SampleMakerWidget);
        zRangeEdit->setObjectName(QString::fromUtf8("zRangeEdit"));

        gridLayout_2->addWidget(zRangeEdit, 2, 2, 1, 1);

        label_5 = new QLabel(SampleMakerWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_2->addWidget(label_5, 4, 0, 1, 2);

        yRangeEdit = new QLineEdit(SampleMakerWidget);
        yRangeEdit->setObjectName(QString::fromUtf8("yRangeEdit"));

        gridLayout_2->addWidget(yRangeEdit, 1, 2, 1, 1);

        xBlockBox = new QSpinBox(SampleMakerWidget);
        xBlockBox->setObjectName(QString::fromUtf8("xBlockBox"));
        xBlockBox->setMaximum(1000);
        xBlockBox->setValue(100);

        gridLayout_2->addWidget(xBlockBox, 3, 2, 1, 1);

        label = new QLabel(SampleMakerWidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_2->addWidget(label, 0, 0, 1, 2);

        yBlockBox = new QSpinBox(SampleMakerWidget);
        yBlockBox->setObjectName(QString::fromUtf8("yBlockBox"));
        yBlockBox->setMaximum(1000);
        yBlockBox->setValue(100);

        gridLayout_2->addWidget(yBlockBox, 4, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 3, 1, 1);


        verticalLayout->addLayout(gridLayout_2);


        gridLayout_3->addLayout(verticalLayout, 0, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_9 = new QLabel(SampleMakerWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_2->addWidget(label_9);

        prefixEdit = new QLineEdit(SampleMakerWidget);
        prefixEdit->setObjectName(QString::fromUtf8("prefixEdit"));

        horizontalLayout_2->addWidget(prefixEdit);

        label_10 = new QLabel(SampleMakerWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_2->addWidget(label_10);

        postEdit = new QLineEdit(SampleMakerWidget);
        postEdit->setObjectName(QString::fromUtf8("postEdit"));

        horizontalLayout_2->addWidget(postEdit);


        gridLayout_3->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        startButton = new QPushButton(SampleMakerWidget);
        startButton->setObjectName(QString::fromUtf8("startButton"));

        horizontalLayout->addWidget(startButton);

        stopButton = new QPushButton(SampleMakerWidget);
        stopButton->setObjectName(QString::fromUtf8("stopButton"));

        horizontalLayout->addWidget(stopButton);

        initTxtButton = new QPushButton(SampleMakerWidget);
        initTxtButton->setObjectName(QString::fromUtf8("initTxtButton"));

        horizontalLayout->addWidget(initTxtButton);


        gridLayout_3->addLayout(horizontalLayout, 2, 0, 1, 1);

        textBrowser = new QTextBrowser(SampleMakerWidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        gridLayout_3->addWidget(textBrowser, 3, 0, 1, 1);

        progressBar = new QProgressBar(SampleMakerWidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(0);

        gridLayout_3->addWidget(progressBar, 4, 0, 1, 1);

        stopButton->raise();
        label->raise();
        xRangeEdit->raise();
        label_2->raise();
        label_3->raise();
        yRangeEdit->raise();
        zRangeEdit->raise();
        label_4->raise();
        progressBar->raise();
        textBrowser->raise();
        xBlockBox->raise();
        label_5->raise();
        label_6->raise();
        yBlockBox->raise();
        zBlockBox->raise();
        mostdPathEdit->raise();
        label_7->raise();
        mostdPathButton->raise();
        label_8->raise();
        dstPathEdit->raise();
        dstPathButton->raise();
        startButton->raise();
        label_9->raise();
        prefixEdit->raise();
        label_10->raise();
        postEdit->raise();
        QWidget::setTabOrder(mostdPathEdit, dstPathEdit);
        QWidget::setTabOrder(dstPathEdit, xRangeEdit);
        QWidget::setTabOrder(xRangeEdit, yRangeEdit);
        QWidget::setTabOrder(yRangeEdit, zRangeEdit);
        QWidget::setTabOrder(zRangeEdit, xBlockBox);
        QWidget::setTabOrder(xBlockBox, yBlockBox);
        QWidget::setTabOrder(yBlockBox, zBlockBox);
        QWidget::setTabOrder(zBlockBox, prefixEdit);
        QWidget::setTabOrder(prefixEdit, postEdit);
        QWidget::setTabOrder(postEdit, mostdPathButton);
        QWidget::setTabOrder(mostdPathButton, dstPathButton);
        QWidget::setTabOrder(dstPathButton, startButton);
        QWidget::setTabOrder(startButton, stopButton);
        QWidget::setTabOrder(stopButton, initTxtButton);
        QWidget::setTabOrder(initTxtButton, textBrowser);

        retranslateUi(SampleMakerWidget);

        QMetaObject::connectSlotsByName(SampleMakerWidget);
    } // setupUi

    void retranslateUi(QWidget *SampleMakerWidget)
    {
        SampleMakerWidget->setWindowTitle(QApplication::translate("SampleMakerWidget", "Form", nullptr));
        label_7->setText(QApplication::translate("SampleMakerWidget", "mostd", nullptr));
        mostdPathButton->setText(QApplication::translate("SampleMakerWidget", "...", nullptr));
        label_8->setText(QApplication::translate("SampleMakerWidget", "dstPath", nullptr));
        dstPathButton->setText(QApplication::translate("SampleMakerWidget", "...", nullptr));
        xRangeEdit->setText(QApplication::translate("SampleMakerWidget", "0-100", nullptr));
        label_4->setText(QApplication::translate("SampleMakerWidget", "xBlock", nullptr));
        label_3->setText(QApplication::translate("SampleMakerWidget", "zRange", nullptr));
        label_2->setText(QApplication::translate("SampleMakerWidget", "yRange", nullptr));
        label_6->setText(QApplication::translate("SampleMakerWidget", "zBlock", nullptr));
        zRangeEdit->setText(QApplication::translate("SampleMakerWidget", "0-100", nullptr));
        label_5->setText(QApplication::translate("SampleMakerWidget", "yBlock", nullptr));
        yRangeEdit->setText(QApplication::translate("SampleMakerWidget", "0-100", nullptr));
        label->setText(QApplication::translate("SampleMakerWidget", "xRange", nullptr));
        label_9->setText(QApplication::translate("SampleMakerWidget", "prefix", nullptr));
        prefixEdit->setText(QApplication::translate("SampleMakerWidget", "sample_", nullptr));
        label_10->setText(QApplication::translate("SampleMakerWidget", "post", nullptr));
        postEdit->setText(QApplication::translate("SampleMakerWidget", "_crop", nullptr));
        startButton->setText(QApplication::translate("SampleMakerWidget", "Start", nullptr));
        stopButton->setText(QApplication::translate("SampleMakerWidget", "Stop", nullptr));
        initTxtButton->setText(QApplication::translate("SampleMakerWidget", "InitTxt", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SampleMakerWidget: public Ui_SampleMakerWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAMPLEMAKER_H
