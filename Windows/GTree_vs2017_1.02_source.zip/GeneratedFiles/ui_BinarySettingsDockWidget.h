/********************************************************************************
** Form generated from reading UI file 'BinarySettingsDockWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BINARYSETTINGSDOCKWIDGET_H
#define UI_BINARYSETTINGSDOCKWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BinarySettingsDockWidget
{
public:
    QWidget *widget;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QGridLayout *gridLayout_14;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_24;
    QWidget *widget_11;
    QGridLayout *gridLayout_13;
    QPushButton *pushButton_6;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_11;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButton_9;
    QSpacerItem *horizontalSpacer_9;
    QSpacerItem *verticalSpacer_3;
    QWidget *widget_8;
    QGridLayout *gridLayout_9;
    QPushButton *pushButton_4;
    QWidget *widget_7;
    QGridLayout *gridLayout_6;
    QLabel *lowMapLabel;
    QSpinBox *lowOpacSpinBox;
    QLabel *highMapLabel;
    QSpinBox *highOpacSpinBox;
    QLabel *label_5;
    QSpinBox *thicknessspinBox;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton;
    QWidget *widget_3;
    QGridLayout *gridLayout;
    QLabel *imageRangeLabel;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *xMinLabel;
    QLabel *xMaxLabel;
    QLabel *yMinLabel;
    QLabel *yMaxLabel;
    QLabel *zMinLabel;
    QLabel *zMaxLabel;
    QVBoxLayout *verticalLayout_2;
    QSpinBox *xMinspinBox;
    QSpinBox *xMaxspinBox;
    QSpinBox *yMinspinBox;
    QSpinBox *yMaxspinBox;
    QSpinBox *zMinspinBox;
    QSpinBox *zMaxspinBox;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_3;
    QSpinBox *levelSpinBox;
    QPushButton *applyImageReadButton;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *action_ClearCache_Button;
    QWidget *widget_4;
    QGridLayout *gridLayout_16;
    QLabel *label_8;
    QSpinBox *origLowOpacSpinBox;
    QSpinBox *origHighOpacSpinBox;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_10;
    QSpinBox *destLowOpacSpinBox;
    QSpinBox *destHighOpacSpinBox;
    QPushButton *previewIlluminationMapButton;
    QPushButton *imageOpacInfoButton;
    QPushButton *opacApplyButton;
    QCheckBox *autoOpacSetCheckBox;
    QWidget *widget_12;
    QGridLayout *gridLayout_12;
    QSpinBox *zBlockSizespinBox;
    QLabel *highMapLabel_2;
    QLabel *lowMapLabel_2;
    QSpinBox *xBlockSizespinBox;
    QLabel *highMapLabel_3;
    QSpinBox *yBlockSizespinBox;
    QWidget *widget_5;
    QGridLayout *gridLayout_15;
    QWidget *widget_19;
    QGridLayout *gridLayout_25;
    QLabel *label;
    QSpinBox *xScaleSpinBox;
    QLabel *label_6;
    QSpinBox *yScaleSpinBox;
    QLabel *label_7;
    QSpinBox *zScaleSpinBox;
    QCheckBox *AveragecheckBox;
    QWidget *tab_2;
    QGridLayout *gridLayout_21;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_5;
    QWidget *widget_9;
    QGridLayout *gridLayout_17;
    QPushButton *pushButton_7;
    QWidget *widget_14;
    QGridLayout *gridLayout_18;
    QDoubleSpinBox *thresholdSpinBox;
    QLabel *ThresholdLabel_4;
    QPushButton *previewBinaryButton;
    QWidget *widget_15;
    QGridLayout *gridLayout_19;
    QPushButton *pushButton_8;
    QWidget *widget_16;
    QGridLayout *gridLayout_20;
    QCheckBox *GPSSVMcheckBox;
    QLabel *diffuseValueLabel_4;
    QDoubleSpinBox *traceValueSpinBox;
    QDoubleSpinBox *diffuseValueSpinBox;
    QLabel *label_9;
    QCheckBox *BigSomacheckBox;
    QWidget *tab_3;
    QGridLayout *gridLayout_5;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_6;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_7;
    QWidget *widget_10;
    QGridLayout *gridLayout_7;
    QDoubleSpinBox *axonTraceValueSpinBox;
    QLabel *diffuseValueLabel_2;
    QLabel *label_13;
    QLabel *label_4;
    QDoubleSpinBox *axonSemiautoTraceTresholdSpinBox;
    QSpinBox *maxBoundNumSpinBox;
    QDoubleSpinBox *axonDiffuseValueSpinBox;
    QCheckBox *strongSignalCheckBox;
    QCheckBox *enableSVMBox;
    QDoubleSpinBox *axonSemiautoConnectResampleSpinBox;
    QLabel *label_14;
    QLabel *label_2;
    QPushButton *pushButton_3;
    QWidget *widget_13;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_5;
    QSpacerItem *horizontalSpacer_8;
    QWidget *widget_17;
    QGridLayout *gridLayout_8;
    QLabel *lowMapLabel_3;
    QSlider *SmoothSlider;
    QWidget *widget_18;
    QGridLayout *gridLayout_22;
    QPushButton *pushButton_10;
    QWidget *widget_20;
    QGridLayout *gridLayout_23;
    QDoubleSpinBox *axonThresholdSpinBox;
    QLabel *ThresholdLabel_5;
    QPushButton *previewAxonBinaryButton;
    QWidget *widget_21;
    QGridLayout *gridLayout_26;
    QPushButton *pushButton_12;
    QSpacerItem *horizontalSpacer_11;
    QCheckBox *CrudeShapecheckBox;
    QWidget *tab_4;
    QGridLayout *gridLayout_11;

    void setupUi(QDockWidget *BinarySettingsDockWidget)
    {
        if (BinarySettingsDockWidget->objectName().isEmpty())
            BinarySettingsDockWidget->setObjectName(QStringLiteral("BinarySettingsDockWidget"));
        BinarySettingsDockWidget->resize(362, 893);
        BinarySettingsDockWidget->setMinimumSize(QSize(300, 600));
        widget = new QWidget();
        widget->setObjectName(QStringLiteral("widget"));
        scrollArea = new QScrollArea(widget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(0, 0, 360, 869));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy);
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QStringLiteral("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 343, 892));
        gridLayout_14 = new QGridLayout(scrollAreaWidgetContents_2);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QStringLiteral("gridLayout_14"));
        tabWidget = new QTabWidget(scrollAreaWidgetContents_2);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setTabShape(QTabWidget::Triangular);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout_24 = new QGridLayout(tab);
        gridLayout_24->setSpacing(6);
        gridLayout_24->setContentsMargins(11, 11, 11, 11);
        gridLayout_24->setObjectName(QStringLiteral("gridLayout_24"));
        widget_11 = new QWidget(tab);
        widget_11->setObjectName(QStringLiteral("widget_11"));
        gridLayout_13 = new QGridLayout(widget_11);
        gridLayout_13->setSpacing(1);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        gridLayout_13->setContentsMargins(1, -1, 1, 1);
        pushButton_6 = new QPushButton(widget_11);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/trace/Resources/plus.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_6->setIcon(icon);
        pushButton_6->setCheckable(true);
        pushButton_6->setChecked(true);
        pushButton_6->setFlat(true);

        gridLayout_13->addWidget(pushButton_6, 0, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_13->addItem(horizontalSpacer_3, 0, 1, 1, 1);


        gridLayout_24->addWidget(widget_11, 2, 0, 1, 2);

        horizontalSpacer_6 = new QSpacerItem(130, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_6, 0, 2, 1, 1);

        pushButton_11 = new QPushButton(tab);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setIcon(icon);
        pushButton_11->setCheckable(true);
        pushButton_11->setChecked(true);
        pushButton_11->setFlat(true);

        gridLayout_24->addWidget(pushButton_11, 9, 0, 1, 1);

        horizontalSpacer_10 = new QSpacerItem(75, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_10, 9, 1, 1, 1);

        pushButton_9 = new QPushButton(tab);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setIcon(icon);
        pushButton_9->setCheckable(true);
        pushButton_9->setChecked(true);
        pushButton_9->setFlat(true);

        gridLayout_24->addWidget(pushButton_9, 4, 0, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(89, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_24->addItem(horizontalSpacer_9, 4, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 233, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_24->addItem(verticalSpacer_3, 11, 0, 1, 2);

        widget_8 = new QWidget(tab);
        widget_8->setObjectName(QStringLiteral("widget_8"));
        gridLayout_9 = new QGridLayout(widget_8);
        gridLayout_9->setSpacing(1);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        gridLayout_9->setContentsMargins(1, 1, 1, 1);
        pushButton_4 = new QPushButton(widget_8);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setIcon(icon);
        pushButton_4->setCheckable(true);
        pushButton_4->setChecked(true);
        pushButton_4->setFlat(true);

        gridLayout_9->addWidget(pushButton_4, 0, 0, 1, 1, Qt::AlignLeft);

        widget_7 = new QWidget(widget_8);
        widget_7->setObjectName(QStringLiteral("widget_7"));
        gridLayout_6 = new QGridLayout(widget_7);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        lowMapLabel = new QLabel(widget_7);
        lowMapLabel->setObjectName(QStringLiteral("lowMapLabel"));

        gridLayout_6->addWidget(lowMapLabel, 0, 0, 1, 1, Qt::AlignRight);

        lowOpacSpinBox = new QSpinBox(widget_7);
        lowOpacSpinBox->setObjectName(QStringLiteral("lowOpacSpinBox"));
        sizePolicy.setHeightForWidth(lowOpacSpinBox->sizePolicy().hasHeightForWidth());
        lowOpacSpinBox->setSizePolicy(sizePolicy);
        lowOpacSpinBox->setMinimumSize(QSize(0, 0));
        lowOpacSpinBox->setMaximum(9999);

        gridLayout_6->addWidget(lowOpacSpinBox, 0, 1, 2, 1);

        highMapLabel = new QLabel(widget_7);
        highMapLabel->setObjectName(QStringLiteral("highMapLabel"));

        gridLayout_6->addWidget(highMapLabel, 1, 0, 2, 1, Qt::AlignRight);

        highOpacSpinBox = new QSpinBox(widget_7);
        highOpacSpinBox->setObjectName(QStringLiteral("highOpacSpinBox"));
        sizePolicy.setHeightForWidth(highOpacSpinBox->sizePolicy().hasHeightForWidth());
        highOpacSpinBox->setSizePolicy(sizePolicy);
        highOpacSpinBox->setMinimumSize(QSize(0, 0));
        highOpacSpinBox->setMaximum(65535);
        highOpacSpinBox->setValue(255);

        gridLayout_6->addWidget(highOpacSpinBox, 2, 1, 1, 1);

        label_5 = new QLabel(widget_7);
        label_5->setObjectName(QStringLiteral("label_5"));
        QFont font;
        font.setPointSize(10);
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_6->addWidget(label_5, 3, 0, 1, 1);

        thicknessspinBox = new QSpinBox(widget_7);
        thicknessspinBox->setObjectName(QStringLiteral("thicknessspinBox"));
        sizePolicy.setHeightForWidth(thicknessspinBox->sizePolicy().hasHeightForWidth());
        thicknessspinBox->setSizePolicy(sizePolicy);
        thicknessspinBox->setMinimum(1);
        thicknessspinBox->setMaximum(65535);
        thicknessspinBox->setValue(10);

        gridLayout_6->addWidget(thicknessspinBox, 3, 1, 1, 1);


        gridLayout_9->addWidget(widget_7, 1, 0, 1, 1);


        gridLayout_24->addWidget(widget_8, 1, 0, 1, 2);

        widget_2 = new QWidget(tab);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setSpacing(1);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(1, 1, 1, 1);
        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setIcon(icon);
        pushButton->setCheckable(true);
        pushButton->setChecked(true);
        pushButton->setFlat(true);

        gridLayout_2->addWidget(pushButton, 0, 0, 1, 1, Qt::AlignLeft);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        gridLayout = new QGridLayout(widget_3);
        gridLayout->setSpacing(1);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(1, 1, 1, 1);
        imageRangeLabel = new QLabel(widget_3);
        imageRangeLabel->setObjectName(QStringLiteral("imageRangeLabel"));
        imageRangeLabel->setMinimumSize(QSize(0, 10));

        gridLayout->addWidget(imageRangeLabel, 0, 0, 1, 1, Qt::AlignLeft);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        xMinLabel = new QLabel(widget_3);
        xMinLabel->setObjectName(QStringLiteral("xMinLabel"));
        sizePolicy.setHeightForWidth(xMinLabel->sizePolicy().hasHeightForWidth());
        xMinLabel->setSizePolicy(sizePolicy);
        xMinLabel->setMinimumSize(QSize(0, 0));
        xMinLabel->setMaximumSize(QSize(16777215, 16777215));
        xMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(xMinLabel, 0, Qt::AlignLeft);

        xMaxLabel = new QLabel(widget_3);
        xMaxLabel->setObjectName(QStringLiteral("xMaxLabel"));
        sizePolicy.setHeightForWidth(xMaxLabel->sizePolicy().hasHeightForWidth());
        xMaxLabel->setSizePolicy(sizePolicy);
        xMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(xMaxLabel, 0, Qt::AlignLeft);

        yMinLabel = new QLabel(widget_3);
        yMinLabel->setObjectName(QStringLiteral("yMinLabel"));
        sizePolicy.setHeightForWidth(yMinLabel->sizePolicy().hasHeightForWidth());
        yMinLabel->setSizePolicy(sizePolicy);
        yMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(yMinLabel, 0, Qt::AlignLeft);

        yMaxLabel = new QLabel(widget_3);
        yMaxLabel->setObjectName(QStringLiteral("yMaxLabel"));
        sizePolicy.setHeightForWidth(yMaxLabel->sizePolicy().hasHeightForWidth());
        yMaxLabel->setSizePolicy(sizePolicy);
        yMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(yMaxLabel, 0, Qt::AlignLeft);

        zMinLabel = new QLabel(widget_3);
        zMinLabel->setObjectName(QStringLiteral("zMinLabel"));
        sizePolicy.setHeightForWidth(zMinLabel->sizePolicy().hasHeightForWidth());
        zMinLabel->setSizePolicy(sizePolicy);
        zMinLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(zMinLabel, 0, Qt::AlignLeft);

        zMaxLabel = new QLabel(widget_3);
        zMaxLabel->setObjectName(QStringLiteral("zMaxLabel"));
        sizePolicy.setHeightForWidth(zMaxLabel->sizePolicy().hasHeightForWidth());
        zMaxLabel->setSizePolicy(sizePolicy);
        zMaxLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(zMaxLabel, 0, Qt::AlignLeft);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        xMinspinBox = new QSpinBox(widget_3);
        xMinspinBox->setObjectName(QStringLiteral("xMinspinBox"));
        sizePolicy.setHeightForWidth(xMinspinBox->sizePolicy().hasHeightForWidth());
        xMinspinBox->setSizePolicy(sizePolicy);
        xMinspinBox->setMinimumSize(QSize(0, 0));
        xMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(xMinspinBox);

        xMaxspinBox = new QSpinBox(widget_3);
        xMaxspinBox->setObjectName(QStringLiteral("xMaxspinBox"));
        sizePolicy.setHeightForWidth(xMaxspinBox->sizePolicy().hasHeightForWidth());
        xMaxspinBox->setSizePolicy(sizePolicy);
        xMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(xMaxspinBox);

        yMinspinBox = new QSpinBox(widget_3);
        yMinspinBox->setObjectName(QStringLiteral("yMinspinBox"));
        sizePolicy.setHeightForWidth(yMinspinBox->sizePolicy().hasHeightForWidth());
        yMinspinBox->setSizePolicy(sizePolicy);
        yMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(yMinspinBox);

        yMaxspinBox = new QSpinBox(widget_3);
        yMaxspinBox->setObjectName(QStringLiteral("yMaxspinBox"));
        sizePolicy.setHeightForWidth(yMaxspinBox->sizePolicy().hasHeightForWidth());
        yMaxspinBox->setSizePolicy(sizePolicy);
        yMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(yMaxspinBox);

        zMinspinBox = new QSpinBox(widget_3);
        zMinspinBox->setObjectName(QStringLiteral("zMinspinBox"));
        sizePolicy.setHeightForWidth(zMinspinBox->sizePolicy().hasHeightForWidth());
        zMinspinBox->setSizePolicy(sizePolicy);
        zMinspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(zMinspinBox);

        zMaxspinBox = new QSpinBox(widget_3);
        zMaxspinBox->setObjectName(QStringLiteral("zMaxspinBox"));
        sizePolicy.setHeightForWidth(zMaxspinBox->sizePolicy().hasHeightForWidth());
        zMaxspinBox->setSizePolicy(sizePolicy);
        zMaxspinBox->setMaximum(100000);

        verticalLayout_2->addWidget(zMaxspinBox);


        horizontalLayout->addLayout(verticalLayout_2);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_2->addWidget(label_3);

        levelSpinBox = new QSpinBox(widget_3);
        levelSpinBox->setObjectName(QStringLiteral("levelSpinBox"));
        levelSpinBox->setMinimum(1);
        levelSpinBox->setMaximum(8);

        horizontalLayout_2->addWidget(levelSpinBox);

        applyImageReadButton = new QPushButton(widget_3);
        applyImageReadButton->setObjectName(QStringLiteral("applyImageReadButton"));

        horizontalLayout_2->addWidget(applyImageReadButton);


        gridLayout->addLayout(horizontalLayout_2, 2, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);

        action_ClearCache_Button = new QPushButton(widget_3);
        action_ClearCache_Button->setObjectName(QStringLiteral("action_ClearCache_Button"));

        horizontalLayout_3->addWidget(action_ClearCache_Button);


        gridLayout->addLayout(horizontalLayout_3, 3, 0, 1, 1);


        gridLayout_2->addWidget(widget_3, 1, 0, 1, 1);


        gridLayout_24->addWidget(widget_2, 0, 0, 1, 2);

        widget_4 = new QWidget(tab);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        gridLayout_16 = new QGridLayout(widget_4);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QStringLiteral("gridLayout_16"));
        label_8 = new QLabel(widget_4);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_16->addWidget(label_8, 0, 0, 1, 1);

        origLowOpacSpinBox = new QSpinBox(widget_4);
        origLowOpacSpinBox->setObjectName(QStringLiteral("origLowOpacSpinBox"));
        origLowOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(origLowOpacSpinBox, 0, 1, 1, 1);

        origHighOpacSpinBox = new QSpinBox(widget_4);
        origHighOpacSpinBox->setObjectName(QStringLiteral("origHighOpacSpinBox"));
        origHighOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(origHighOpacSpinBox, 0, 2, 1, 1);

        label_11 = new QLabel(widget_4);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_16->addWidget(label_11, 1, 1, 1, 1);

        label_12 = new QLabel(widget_4);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout_16->addWidget(label_12, 1, 2, 1, 1);

        label_10 = new QLabel(widget_4);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_16->addWidget(label_10, 2, 0, 1, 1);

        destLowOpacSpinBox = new QSpinBox(widget_4);
        destLowOpacSpinBox->setObjectName(QStringLiteral("destLowOpacSpinBox"));
        destLowOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(destLowOpacSpinBox, 2, 1, 1, 1);

        destHighOpacSpinBox = new QSpinBox(widget_4);
        destHighOpacSpinBox->setObjectName(QStringLiteral("destHighOpacSpinBox"));
        destHighOpacSpinBox->setMaximum(65535);

        gridLayout_16->addWidget(destHighOpacSpinBox, 2, 2, 1, 1);

        previewIlluminationMapButton = new QPushButton(widget_4);
        previewIlluminationMapButton->setObjectName(QStringLiteral("previewIlluminationMapButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(previewIlluminationMapButton->sizePolicy().hasHeightForWidth());
        previewIlluminationMapButton->setSizePolicy(sizePolicy2);
        previewIlluminationMapButton->setMinimumSize(QSize(47, 0));
        previewIlluminationMapButton->setMaximumSize(QSize(49, 16777215));
        previewIlluminationMapButton->setCheckable(true);

        gridLayout_16->addWidget(previewIlluminationMapButton, 3, 0, 1, 1);

        imageOpacInfoButton = new QPushButton(widget_4);
        imageOpacInfoButton->setObjectName(QStringLiteral("imageOpacInfoButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(imageOpacInfoButton->sizePolicy().hasHeightForWidth());
        imageOpacInfoButton->setSizePolicy(sizePolicy3);
        imageOpacInfoButton->setMaximumSize(QSize(47, 16777215));

        gridLayout_16->addWidget(imageOpacInfoButton, 3, 1, 1, 1);

        opacApplyButton = new QPushButton(widget_4);
        opacApplyButton->setObjectName(QStringLiteral("opacApplyButton"));
        opacApplyButton->setMaximumSize(QSize(47, 16777215));

        gridLayout_16->addWidget(opacApplyButton, 3, 2, 1, 1);

        autoOpacSetCheckBox = new QCheckBox(widget_4);
        autoOpacSetCheckBox->setObjectName(QStringLiteral("autoOpacSetCheckBox"));

        gridLayout_16->addWidget(autoOpacSetCheckBox, 4, 2, 1, 1);


        gridLayout_24->addWidget(widget_4, 10, 0, 1, 2);

        widget_12 = new QWidget(tab);
        widget_12->setObjectName(QStringLiteral("widget_12"));
        gridLayout_12 = new QGridLayout(widget_12);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        zBlockSizespinBox = new QSpinBox(widget_12);
        zBlockSizespinBox->setObjectName(QStringLiteral("zBlockSizespinBox"));
        sizePolicy.setHeightForWidth(zBlockSizespinBox->sizePolicy().hasHeightForWidth());
        zBlockSizespinBox->setSizePolicy(sizePolicy);
        zBlockSizespinBox->setMinimumSize(QSize(0, 0));
        zBlockSizespinBox->setMinimum(10);
        zBlockSizespinBox->setMaximum(9999);
        zBlockSizespinBox->setValue(54);

        gridLayout_12->addWidget(zBlockSizespinBox, 2, 1, 1, 1);

        highMapLabel_2 = new QLabel(widget_12);
        highMapLabel_2->setObjectName(QStringLiteral("highMapLabel_2"));

        gridLayout_12->addWidget(highMapLabel_2, 1, 0, 1, 1, Qt::AlignRight);

        lowMapLabel_2 = new QLabel(widget_12);
        lowMapLabel_2->setObjectName(QStringLiteral("lowMapLabel_2"));

        gridLayout_12->addWidget(lowMapLabel_2, 0, 0, 1, 1, Qt::AlignRight);

        xBlockSizespinBox = new QSpinBox(widget_12);
        xBlockSizespinBox->setObjectName(QStringLiteral("xBlockSizespinBox"));
        sizePolicy.setHeightForWidth(xBlockSizespinBox->sizePolicy().hasHeightForWidth());
        xBlockSizespinBox->setSizePolicy(sizePolicy);
        xBlockSizespinBox->setMinimumSize(QSize(0, 0));
        xBlockSizespinBox->setMinimum(10);
        xBlockSizespinBox->setMaximum(9999);
        xBlockSizespinBox->setValue(60);

        gridLayout_12->addWidget(xBlockSizespinBox, 0, 1, 1, 1);

        highMapLabel_3 = new QLabel(widget_12);
        highMapLabel_3->setObjectName(QStringLiteral("highMapLabel_3"));

        gridLayout_12->addWidget(highMapLabel_3, 2, 0, 1, 1, Qt::AlignRight);

        yBlockSizespinBox = new QSpinBox(widget_12);
        yBlockSizespinBox->setObjectName(QStringLiteral("yBlockSizespinBox"));
        sizePolicy.setHeightForWidth(yBlockSizespinBox->sizePolicy().hasHeightForWidth());
        yBlockSizespinBox->setSizePolicy(sizePolicy);
        yBlockSizespinBox->setMinimumSize(QSize(0, 0));
        yBlockSizespinBox->setMinimum(10);
        yBlockSizespinBox->setMaximum(9999);
        yBlockSizespinBox->setValue(60);

        gridLayout_12->addWidget(yBlockSizespinBox, 1, 1, 1, 1);


        gridLayout_24->addWidget(widget_12, 3, 0, 1, 2);

        widget_5 = new QWidget(tab);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        gridLayout_15 = new QGridLayout(widget_5);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QStringLiteral("gridLayout_15"));
        widget_19 = new QWidget(widget_5);
        widget_19->setObjectName(QStringLiteral("widget_19"));
        gridLayout_25 = new QGridLayout(widget_19);
        gridLayout_25->setSpacing(6);
        gridLayout_25->setContentsMargins(11, 11, 11, 11);
        gridLayout_25->setObjectName(QStringLiteral("gridLayout_25"));
        label = new QLabel(widget_19);
        label->setObjectName(QStringLiteral("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label, 0, 0, 1, 1);

        xScaleSpinBox = new QSpinBox(widget_19);
        xScaleSpinBox->setObjectName(QStringLiteral("xScaleSpinBox"));
        xScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(xScaleSpinBox, 0, 1, 1, 1);

        label_6 = new QLabel(widget_19);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label_6, 1, 0, 1, 1);

        yScaleSpinBox = new QSpinBox(widget_19);
        yScaleSpinBox->setObjectName(QStringLiteral("yScaleSpinBox"));
        yScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(yScaleSpinBox, 1, 1, 1, 1);

        label_7 = new QLabel(widget_19);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_25->addWidget(label_7, 2, 0, 1, 1);

        zScaleSpinBox = new QSpinBox(widget_19);
        zScaleSpinBox->setObjectName(QStringLiteral("zScaleSpinBox"));
        zScaleSpinBox->setEnabled(false);
        zScaleSpinBox->setMinimum(1);

        gridLayout_25->addWidget(zScaleSpinBox, 2, 1, 1, 1);

        label->raise();
        xScaleSpinBox->raise();
        label_6->raise();
        label_7->raise();
        yScaleSpinBox->raise();
        zScaleSpinBox->raise();

        gridLayout_15->addWidget(widget_19, 2, 1, 1, 1);

        AveragecheckBox = new QCheckBox(widget_5);
        AveragecheckBox->setObjectName(QStringLiteral("AveragecheckBox"));
        AveragecheckBox->setChecked(true);

        gridLayout_15->addWidget(AveragecheckBox, 1, 1, 1, 1);


        gridLayout_24->addWidget(widget_5, 7, 0, 2, 2);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayout_21 = new QGridLayout(tab_2);
        gridLayout_21->setSpacing(6);
        gridLayout_21->setContentsMargins(11, 11, 11, 11);
        gridLayout_21->setObjectName(QStringLiteral("gridLayout_21"));
        verticalSpacer = new QSpacerItem(20, 593, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_21->addItem(verticalSpacer, 2, 0, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(186, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_21->addItem(horizontalSpacer_5, 1, 1, 1, 1);

        widget_9 = new QWidget(tab_2);
        widget_9->setObjectName(QStringLiteral("widget_9"));
        gridLayout_17 = new QGridLayout(widget_9);
        gridLayout_17->setSpacing(1);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QStringLiteral("gridLayout_17"));
        gridLayout_17->setContentsMargins(1, 1, 1, 1);
        pushButton_7 = new QPushButton(widget_9);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setIcon(icon);
        pushButton_7->setCheckable(true);
        pushButton_7->setChecked(true);
        pushButton_7->setFlat(true);

        gridLayout_17->addWidget(pushButton_7, 0, 0, 1, 1, Qt::AlignLeft);

        widget_14 = new QWidget(widget_9);
        widget_14->setObjectName(QStringLiteral("widget_14"));
        gridLayout_18 = new QGridLayout(widget_14);
        gridLayout_18->setSpacing(1);
        gridLayout_18->setContentsMargins(11, 11, 11, 11);
        gridLayout_18->setObjectName(QStringLiteral("gridLayout_18"));
        gridLayout_18->setContentsMargins(1, 1, 1, 1);
        thresholdSpinBox = new QDoubleSpinBox(widget_14);
        thresholdSpinBox->setObjectName(QStringLiteral("thresholdSpinBox"));
        sizePolicy.setHeightForWidth(thresholdSpinBox->sizePolicy().hasHeightForWidth());
        thresholdSpinBox->setSizePolicy(sizePolicy);
        thresholdSpinBox->setMaximum(9999);
        thresholdSpinBox->setValue(20);

        gridLayout_18->addWidget(thresholdSpinBox, 0, 1, 1, 1);

        ThresholdLabel_4 = new QLabel(widget_14);
        ThresholdLabel_4->setObjectName(QStringLiteral("ThresholdLabel_4"));
        sizePolicy.setHeightForWidth(ThresholdLabel_4->sizePolicy().hasHeightForWidth());
        ThresholdLabel_4->setSizePolicy(sizePolicy);
        ThresholdLabel_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_18->addWidget(ThresholdLabel_4, 0, 0, 1, 1, Qt::AlignLeft);

        previewBinaryButton = new QPushButton(widget_14);
        previewBinaryButton->setObjectName(QStringLiteral("previewBinaryButton"));
        previewBinaryButton->setCheckable(true);

        gridLayout_18->addWidget(previewBinaryButton, 1, 0, 1, 1);


        gridLayout_17->addWidget(widget_14, 1, 0, 1, 1);


        gridLayout_21->addWidget(widget_9, 0, 0, 1, 1);

        widget_15 = new QWidget(tab_2);
        widget_15->setObjectName(QStringLiteral("widget_15"));
        gridLayout_19 = new QGridLayout(widget_15);
        gridLayout_19->setSpacing(6);
        gridLayout_19->setContentsMargins(11, 11, 11, 11);
        gridLayout_19->setObjectName(QStringLiteral("gridLayout_19"));
        pushButton_8 = new QPushButton(widget_15);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setIcon(icon);
        pushButton_8->setCheckable(true);
        pushButton_8->setChecked(true);
        pushButton_8->setFlat(true);

        gridLayout_19->addWidget(pushButton_8, 0, 0, 1, 1);

        widget_16 = new QWidget(widget_15);
        widget_16->setObjectName(QStringLiteral("widget_16"));
        gridLayout_20 = new QGridLayout(widget_16);
        gridLayout_20->setSpacing(1);
        gridLayout_20->setContentsMargins(11, 11, 11, 11);
        gridLayout_20->setObjectName(QStringLiteral("gridLayout_20"));
        gridLayout_20->setContentsMargins(1, 1, 1, 1);
        GPSSVMcheckBox = new QCheckBox(widget_16);
        GPSSVMcheckBox->setObjectName(QStringLiteral("GPSSVMcheckBox"));

        gridLayout_20->addWidget(GPSSVMcheckBox, 4, 1, 1, 1);

        diffuseValueLabel_4 = new QLabel(widget_16);
        diffuseValueLabel_4->setObjectName(QStringLiteral("diffuseValueLabel_4"));
        QFont font1;
        font1.setPointSize(9);
        diffuseValueLabel_4->setFont(font1);
        diffuseValueLabel_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_20->addWidget(diffuseValueLabel_4, 1, 0, 1, 1);

        traceValueSpinBox = new QDoubleSpinBox(widget_16);
        traceValueSpinBox->setObjectName(QStringLiteral("traceValueSpinBox"));
        sizePolicy.setHeightForWidth(traceValueSpinBox->sizePolicy().hasHeightForWidth());
        traceValueSpinBox->setSizePolicy(sizePolicy);
        QFont font2;
        font2.setFamily(QStringLiteral("Arial"));
        font2.setPointSize(9);
        traceValueSpinBox->setFont(font2);
        traceValueSpinBox->setMaximum(1e+07);
        traceValueSpinBox->setValue(1);

        gridLayout_20->addWidget(traceValueSpinBox, 3, 1, 1, 1);

        diffuseValueSpinBox = new QDoubleSpinBox(widget_16);
        diffuseValueSpinBox->setObjectName(QStringLiteral("diffuseValueSpinBox"));
        sizePolicy.setHeightForWidth(diffuseValueSpinBox->sizePolicy().hasHeightForWidth());
        diffuseValueSpinBox->setSizePolicy(sizePolicy);
        diffuseValueSpinBox->setMaximum(99999);
        diffuseValueSpinBox->setValue(4096);

        gridLayout_20->addWidget(diffuseValueSpinBox, 1, 1, 1, 1);

        label_9 = new QLabel(widget_16);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_20->addWidget(label_9, 3, 0, 1, 1);

        BigSomacheckBox = new QCheckBox(widget_16);
        BigSomacheckBox->setObjectName(QStringLiteral("BigSomacheckBox"));

        gridLayout_20->addWidget(BigSomacheckBox, 5, 1, 1, 1);


        gridLayout_19->addWidget(widget_16, 1, 0, 1, 2);


        gridLayout_21->addWidget(widget_15, 1, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        gridLayout_5 = new QGridLayout(tab_3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer, 0, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_5->addItem(verticalSpacer_2, 4, 0, 1, 1);

        widget_6 = new QWidget(tab_3);
        widget_6->setObjectName(QStringLiteral("widget_6"));
        gridLayout_3 = new QGridLayout(widget_6);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(1, 1, 1, 1);
        horizontalSpacer_7 = new QSpacerItem(93, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_7, 0, 1, 1, 1);

        widget_10 = new QWidget(widget_6);
        widget_10->setObjectName(QStringLiteral("widget_10"));
        gridLayout_7 = new QGridLayout(widget_10);
        gridLayout_7->setSpacing(1);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        gridLayout_7->setContentsMargins(1, 1, 1, 1);
        axonTraceValueSpinBox = new QDoubleSpinBox(widget_10);
        axonTraceValueSpinBox->setObjectName(QStringLiteral("axonTraceValueSpinBox"));
        sizePolicy.setHeightForWidth(axonTraceValueSpinBox->sizePolicy().hasHeightForWidth());
        axonTraceValueSpinBox->setSizePolicy(sizePolicy);
        axonTraceValueSpinBox->setFont(font2);
        axonTraceValueSpinBox->setMaximum(1e+08);
        axonTraceValueSpinBox->setValue(1);

        gridLayout_7->addWidget(axonTraceValueSpinBox, 5, 1, 1, 1);

        diffuseValueLabel_2 = new QLabel(widget_10);
        diffuseValueLabel_2->setObjectName(QStringLiteral("diffuseValueLabel_2"));
        diffuseValueLabel_2->setFont(font1);
        diffuseValueLabel_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(diffuseValueLabel_2, 3, 0, 1, 1);

        label_13 = new QLabel(widget_10);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_13, 8, 0, 1, 1);

        label_4 = new QLabel(widget_10);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font1);
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_4, 7, 0, 1, 1);

        axonSemiautoTraceTresholdSpinBox = new QDoubleSpinBox(widget_10);
        axonSemiautoTraceTresholdSpinBox->setObjectName(QStringLiteral("axonSemiautoTraceTresholdSpinBox"));
        axonSemiautoTraceTresholdSpinBox->setMaximum(100);
        axonSemiautoTraceTresholdSpinBox->setValue(8);

        gridLayout_7->addWidget(axonSemiautoTraceTresholdSpinBox, 8, 1, 1, 1);

        maxBoundNumSpinBox = new QSpinBox(widget_10);
        maxBoundNumSpinBox->setObjectName(QStringLiteral("maxBoundNumSpinBox"));
        sizePolicy.setHeightForWidth(maxBoundNumSpinBox->sizePolicy().hasHeightForWidth());
        maxBoundNumSpinBox->setSizePolicy(sizePolicy);
        maxBoundNumSpinBox->setValue(10);

        gridLayout_7->addWidget(maxBoundNumSpinBox, 7, 1, 1, 1);

        axonDiffuseValueSpinBox = new QDoubleSpinBox(widget_10);
        axonDiffuseValueSpinBox->setObjectName(QStringLiteral("axonDiffuseValueSpinBox"));
        sizePolicy.setHeightForWidth(axonDiffuseValueSpinBox->sizePolicy().hasHeightForWidth());
        axonDiffuseValueSpinBox->setSizePolicy(sizePolicy);
        axonDiffuseValueSpinBox->setMaximum(99999);
        axonDiffuseValueSpinBox->setValue(50);

        gridLayout_7->addWidget(axonDiffuseValueSpinBox, 3, 1, 1, 1);

        strongSignalCheckBox = new QCheckBox(widget_10);
        strongSignalCheckBox->setObjectName(QStringLiteral("strongSignalCheckBox"));
        QFont font3;
        font3.setKerning(true);
        strongSignalCheckBox->setFont(font3);
        strongSignalCheckBox->setLayoutDirection(Qt::RightToLeft);
        strongSignalCheckBox->setChecked(true);
        strongSignalCheckBox->setTristate(false);

        gridLayout_7->addWidget(strongSignalCheckBox, 10, 0, 1, 1);

        enableSVMBox = new QCheckBox(widget_10);
        enableSVMBox->setObjectName(QStringLiteral("enableSVMBox"));
        enableSVMBox->setLayoutDirection(Qt::RightToLeft);
        enableSVMBox->setChecked(false);

        gridLayout_7->addWidget(enableSVMBox, 10, 1, 1, 1);

        axonSemiautoConnectResampleSpinBox = new QDoubleSpinBox(widget_10);
        axonSemiautoConnectResampleSpinBox->setObjectName(QStringLiteral("axonSemiautoConnectResampleSpinBox"));
        axonSemiautoConnectResampleSpinBox->setMinimum(1);
        axonSemiautoConnectResampleSpinBox->setValue(4);

        gridLayout_7->addWidget(axonSemiautoConnectResampleSpinBox, 9, 1, 1, 1);

        label_14 = new QLabel(widget_10);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_14, 9, 0, 1, 1);

        label_2 = new QLabel(widget_10);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setLayoutDirection(Qt::LeftToRight);
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_7->addWidget(label_2, 5, 0, 1, 1);


        gridLayout_3->addWidget(widget_10, 1, 0, 1, 2);

        pushButton_3 = new QPushButton(widget_6);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setIcon(icon);
        pushButton_3->setCheckable(true);
        pushButton_3->setChecked(true);
        pushButton_3->setFlat(true);

        gridLayout_3->addWidget(pushButton_3, 0, 0, 1, 1);


        gridLayout_5->addWidget(widget_6, 1, 0, 1, 1);

        widget_13 = new QWidget(tab_3);
        widget_13->setObjectName(QStringLiteral("widget_13"));
        gridLayout_4 = new QGridLayout(widget_13);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(1, 1, 1, 1);
        pushButton_5 = new QPushButton(widget_13);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy4);
        pushButton_5->setIcon(icon);
        pushButton_5->setCheckable(true);
        pushButton_5->setChecked(true);
        pushButton_5->setFlat(true);

        gridLayout_4->addWidget(pushButton_5, 0, 0, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(87, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_8, 0, 1, 1, 1);

        widget_17 = new QWidget(widget_13);
        widget_17->setObjectName(QStringLiteral("widget_17"));
        gridLayout_8 = new QGridLayout(widget_17);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        lowMapLabel_3 = new QLabel(widget_17);
        lowMapLabel_3->setObjectName(QStringLiteral("lowMapLabel_3"));

        gridLayout_8->addWidget(lowMapLabel_3, 0, 0, 1, 1);

        SmoothSlider = new QSlider(widget_17);
        SmoothSlider->setObjectName(QStringLiteral("SmoothSlider"));
        SmoothSlider->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(SmoothSlider, 0, 1, 1, 1);


        gridLayout_4->addWidget(widget_17, 1, 0, 1, 2);


        gridLayout_5->addWidget(widget_13, 2, 0, 1, 1);

        widget_18 = new QWidget(tab_3);
        widget_18->setObjectName(QStringLiteral("widget_18"));
        gridLayout_22 = new QGridLayout(widget_18);
        gridLayout_22->setSpacing(1);
        gridLayout_22->setContentsMargins(11, 11, 11, 11);
        gridLayout_22->setObjectName(QStringLiteral("gridLayout_22"));
        gridLayout_22->setContentsMargins(1, 1, 1, 1);
        pushButton_10 = new QPushButton(widget_18);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setIcon(icon);
        pushButton_10->setCheckable(true);
        pushButton_10->setChecked(true);
        pushButton_10->setFlat(true);

        gridLayout_22->addWidget(pushButton_10, 0, 0, 1, 1, Qt::AlignLeft);

        widget_20 = new QWidget(widget_18);
        widget_20->setObjectName(QStringLiteral("widget_20"));
        gridLayout_23 = new QGridLayout(widget_20);
        gridLayout_23->setSpacing(1);
        gridLayout_23->setContentsMargins(11, 11, 11, 11);
        gridLayout_23->setObjectName(QStringLiteral("gridLayout_23"));
        gridLayout_23->setContentsMargins(1, 1, 1, 1);
        axonThresholdSpinBox = new QDoubleSpinBox(widget_20);
        axonThresholdSpinBox->setObjectName(QStringLiteral("axonThresholdSpinBox"));
        sizePolicy.setHeightForWidth(axonThresholdSpinBox->sizePolicy().hasHeightForWidth());
        axonThresholdSpinBox->setSizePolicy(sizePolicy);
        axonThresholdSpinBox->setMaximum(9999);
        axonThresholdSpinBox->setValue(20);

        gridLayout_23->addWidget(axonThresholdSpinBox, 0, 1, 1, 1);

        ThresholdLabel_5 = new QLabel(widget_20);
        ThresholdLabel_5->setObjectName(QStringLiteral("ThresholdLabel_5"));
        sizePolicy.setHeightForWidth(ThresholdLabel_5->sizePolicy().hasHeightForWidth());
        ThresholdLabel_5->setSizePolicy(sizePolicy);
        ThresholdLabel_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_23->addWidget(ThresholdLabel_5, 0, 0, 1, 1, Qt::AlignLeft);

        previewAxonBinaryButton = new QPushButton(widget_20);
        previewAxonBinaryButton->setObjectName(QStringLiteral("previewAxonBinaryButton"));
        previewAxonBinaryButton->setCheckable(true);

        gridLayout_23->addWidget(previewAxonBinaryButton, 1, 0, 1, 1);


        gridLayout_22->addWidget(widget_20, 1, 0, 1, 1);


        gridLayout_5->addWidget(widget_18, 0, 0, 1, 1);

        widget_21 = new QWidget(tab_3);
        widget_21->setObjectName(QStringLiteral("widget_21"));
        gridLayout_26 = new QGridLayout(widget_21);
        gridLayout_26->setSpacing(6);
        gridLayout_26->setContentsMargins(11, 11, 11, 11);
        gridLayout_26->setObjectName(QStringLiteral("gridLayout_26"));
        pushButton_12 = new QPushButton(widget_21);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        sizePolicy4.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy4);
        pushButton_12->setIcon(icon);
        pushButton_12->setCheckable(true);
        pushButton_12->setChecked(true);
        pushButton_12->setFlat(true);

        gridLayout_26->addWidget(pushButton_12, 0, 0, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(94, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_26->addItem(horizontalSpacer_11, 0, 1, 1, 1);

        CrudeShapecheckBox = new QCheckBox(widget_21);
        CrudeShapecheckBox->setObjectName(QStringLiteral("CrudeShapecheckBox"));

        gridLayout_26->addWidget(CrudeShapecheckBox, 1, 0, 1, 2);


        gridLayout_5->addWidget(widget_21, 3, 0, 1, 1);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        gridLayout_11 = new QGridLayout(tab_4);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        tabWidget->addTab(tab_4, QString());

        gridLayout_14->addWidget(tabWidget, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents_2);
        BinarySettingsDockWidget->setWidget(widget);

        retranslateUi(BinarySettingsDockWidget);
        QObject::connect(pushButton_4, SIGNAL(clicked(bool)), widget_7, SLOT(setVisible(bool)));
        QObject::connect(pushButton, SIGNAL(clicked(bool)), widget_3, SLOT(setVisible(bool)));
        QObject::connect(pushButton_6, SIGNAL(clicked(bool)), widget_12, SLOT(setVisible(bool)));
        QObject::connect(pushButton_9, SIGNAL(clicked(bool)), widget_5, SLOT(setVisible(bool)));
        QObject::connect(pushButton_11, SIGNAL(clicked(bool)), widget_4, SLOT(setVisible(bool)));
        QObject::connect(pushButton_7, SIGNAL(clicked(bool)), widget_14, SLOT(setVisible(bool)));
        QObject::connect(pushButton_8, SIGNAL(clicked(bool)), widget_16, SLOT(setVisible(bool)));
        QObject::connect(pushButton_5, SIGNAL(clicked(bool)), widget_17, SLOT(setVisible(bool)));
        QObject::connect(pushButton_3, SIGNAL(clicked(bool)), widget_10, SLOT(setVisible(bool)));
        QObject::connect(pushButton_10, SIGNAL(clicked(bool)), widget_20, SLOT(setVisible(bool)));
        QObject::connect(pushButton_12, SIGNAL(clicked(bool)), CrudeShapecheckBox, SLOT(setVisible(bool)));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(BinarySettingsDockWidget);
    } // setupUi

    void retranslateUi(QDockWidget *BinarySettingsDockWidget)
    {
        BinarySettingsDockWidget->setWindowTitle(QApplication::translate("BinarySettingsDockWidget", "BinarySettingsDockWidget", nullptr));
        pushButton_6->setText(QApplication::translate("BinarySettingsDockWidget", "Block Radius", nullptr));
        pushButton_11->setText(QApplication::translate("BinarySettingsDockWidget", "Illuminant", nullptr));
        pushButton_9->setText(QApplication::translate("BinarySettingsDockWidget", "Resample", nullptr));
        pushButton_4->setText(QApplication::translate("BinarySettingsDockWidget", "Display", nullptr));
        lowMapLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Min Opac", nullptr));
        highMapLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Max Opac", nullptr));
        label_5->setText(QApplication::translate("BinarySettingsDockWidget", "Thickness", nullptr));
        pushButton->setText(QApplication::translate("BinarySettingsDockWidget", "Image Range", nullptr));
        imageRangeLabel->setText(QApplication::translate("BinarySettingsDockWidget", "Image Size:", nullptr));
        xMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "xMin", nullptr));
        xMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "xMax", nullptr));
        yMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "yMin", nullptr));
        yMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "yMax", nullptr));
        zMinLabel->setText(QApplication::translate("BinarySettingsDockWidget", "zMin", nullptr));
        zMaxLabel->setText(QApplication::translate("BinarySettingsDockWidget", "zMax", nullptr));
        label_3->setText(QApplication::translate("BinarySettingsDockWidget", "Level", nullptr));
        applyImageReadButton->setText(QApplication::translate("BinarySettingsDockWidget", "Apply Read", nullptr));
        action_ClearCache_Button->setText(QApplication::translate("BinarySettingsDockWidget", "Clear Cache", nullptr));
        label_8->setText(QApplication::translate("BinarySettingsDockWidget", "Original", nullptr));
        label_11->setText(QApplication::translate("BinarySettingsDockWidget", "|", nullptr));
        label_12->setText(QApplication::translate("BinarySettingsDockWidget", "|", nullptr));
        label_10->setText(QApplication::translate("BinarySettingsDockWidget", "Dest", nullptr));
        previewIlluminationMapButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        imageOpacInfoButton->setText(QApplication::translate("BinarySettingsDockWidget", "Info", nullptr));
        opacApplyButton->setText(QApplication::translate("BinarySettingsDockWidget", "Apply", nullptr));
        autoOpacSetCheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Auto", nullptr));
        highMapLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "yBlock", nullptr));
        lowMapLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "xBlock", nullptr));
        highMapLabel_3->setText(QApplication::translate("BinarySettingsDockWidget", "zBlock", nullptr));
        label->setText(QApplication::translate("BinarySettingsDockWidget", "xScale", nullptr));
        label_6->setText(QApplication::translate("BinarySettingsDockWidget", "yScale", nullptr));
        label_7->setText(QApplication::translate("BinarySettingsDockWidget", "zScale", nullptr));
        AveragecheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Average when downsizing", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("BinarySettingsDockWidget", "Image", nullptr));
        pushButton_7->setText(QApplication::translate("BinarySettingsDockWidget", "Binary Option", nullptr));
        ThresholdLabel_4->setText(QApplication::translate("BinarySettingsDockWidget", "Threshold", nullptr));
        previewBinaryButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        pushButton_8->setText(QApplication::translate("BinarySettingsDockWidget", "Trace Option", nullptr));
        GPSSVMcheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "GPS-SVM", nullptr));
        diffuseValueLabel_4->setText(QApplication::translate("BinarySettingsDockWidget", "Bifur", nullptr));
        label_9->setText(QApplication::translate("BinarySettingsDockWidget", "Trace", nullptr));
        BigSomacheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Big Soma", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("BinarySettingsDockWidget", "NeuroGPS", nullptr));
        diffuseValueLabel_2->setText(QApplication::translate("BinarySettingsDockWidget", "Axon Bifur", nullptr));
        label_13->setText(QApplication::translate("BinarySettingsDockWidget", "Semi Rate(%)", nullptr));
        label_4->setText(QApplication::translate("BinarySettingsDockWidget", "Bound MaxNum", nullptr));
        strongSignalCheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Strong Noise", nullptr));
        enableSVMBox->setText(QApplication::translate("BinarySettingsDockWidget", "Enable SVM", nullptr));
        label_14->setText(QApplication::translate("BinarySettingsDockWidget", "Resample Distance", nullptr));
        label_2->setText(QApplication::translate("BinarySettingsDockWidget", "Axon Trace", nullptr));
        pushButton_3->setText(QApplication::translate("BinarySettingsDockWidget", "Trace Option", nullptr));
        pushButton_5->setText(QApplication::translate("BinarySettingsDockWidget", "Smooth Option", nullptr));
        lowMapLabel_3->setText(QApplication::translate("BinarySettingsDockWidget", "Smooth Level", nullptr));
        pushButton_10->setText(QApplication::translate("BinarySettingsDockWidget", "Binary Option", nullptr));
        ThresholdLabel_5->setText(QApplication::translate("BinarySettingsDockWidget", "Threshold", nullptr));
        previewAxonBinaryButton->setText(QApplication::translate("BinarySettingsDockWidget", "Preview", nullptr));
        pushButton_12->setText(QApplication::translate("BinarySettingsDockWidget", "Reconstruction", nullptr));
        CrudeShapecheckBox->setText(QApplication::translate("BinarySettingsDockWidget", "Crude fiber shape reconstruction", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("BinarySettingsDockWidget", "Axon", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("BinarySettingsDockWidget", "Editor", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BinarySettingsDockWidget: public Ui_BinarySettingsDockWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BINARYSETTINGSDOCKWIDGET_H
