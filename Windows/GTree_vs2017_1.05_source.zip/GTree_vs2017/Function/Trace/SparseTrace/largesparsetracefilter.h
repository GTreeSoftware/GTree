/**
 * @file largesparsetracefilter.h
 * @brief Brain-wide tracing main function.
 * @details
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef LARGESPARSETRACEFILTER_H
#define LARGESPARSETRACEFILTER_H
#include <stack>
#include <utility>
#include <exception>
#ifdef _WIN32
#include <ctime>
#endif
#include "../../ineuronprocessobject.h"
#include "../../../ngtypes/basetypes.h"
#include "../../../ngtypes/volume.h"
#include "../../../ngtypes/ParamPack.h"
#include "../../../ngtypes/tree.h"
class LargeSparseTraceFilter;
class INeuronBigReader;
class BinaryFilter;
class SparseTraceFilter;
class SparseTraceAxonFilter;
NG_SMART_POINTER_TYPEDEF(INeuronBigReader, NGNeuronBigReader);
NG_SMART_POINTER_TYPEDEF(BinaryFilter, NGBinaryFilter);
NG_SMART_POINTER_TYPEDEF(SparseTraceFilter, NGSparseTraceFilter);
NG_SMART_POINTER_TYPEDEF(SparseTraceAxonFilter, NGSparseTraceAxonFilter);
NG_SMART_POINTER_TYPEDEF(LargeSparseTraceFilter, NGLargeSparseTraceFilter);
NG_SMART_POINTER_TYPEDEF(std::vector<VectorVec5d>, SMARTTREE);

/**
* @brief Deprecated.
*/
class MyException :public std::exception
{
public:
    const char* what()const throw()  
    {
        return "ERROR! Please call zhouhang.\n";
    }
};

/**
* @brief Brain-wide tracing.
* The main function entry of brain-wide tracing.
*/
class LargeSparseTraceFilter : public INeuronProcessObject
{
public:
    static NGLargeSparseTraceFilter New(){return NGLargeSparseTraceFilter(new LargeSparseTraceFilter());}
    LargeSparseTraceFilter();
    ~LargeSparseTraceFilter();

    virtual ProcStatPointer Update();
    ConstIDataPointer GetOutput();//modification is allowed
    IDataPointer GetOutputTree();//modification is allowed


    //the prefix of axon means the parameter of axon trace
    void SetInputOldTree(IDataPointer);
	/**
	* @brief Set the pointer of brain-wide image importing module.
	*/
    void SetInputMOSTD(NGNeuronBigReader);//mostd reader
    void SetSoma(IDataPointer);
	/**
	* @brief Set the wrapper of common parameters.
	*/
    void SetParam(NGParamPack arg){if(arg == paramPack) return; paramPack = arg;}
    IDataPointer ReleaseCurrentImage();
    
	/**
	* @brief Start the automatic tracing of current blocks.
	*/
    ProcStatPointer Run();
    void Step();
    void Stop();
    void Train();

protected:
    IDataPointer ReleaseData();
    void SetInput();
    void CalcPtCurveDirection(const VectorVec3d &ptCurve, Vec3d &fir);
    bool IsInCurrentBlock(const Vec3d&);
    bool IsInCurrentBlock(const Vec5d&);
	/**
	* @brief Check the errors after tracing.
	*/
    void errorcheck();
	/**
	* @brief Acquire the end point of each traced neurites which touch the boundary of current images.
	*/
    void CollectAllowableBoundCheckPt(const std::vector<VectorVec5d>& arg);
	/**
	* @brief Pop up the tracing initial information and prepare for tracing in the next blocks.
	*/
    void PopTraceInitInfoCurrentBlock();
    bool IsInOrNearCurrentBlock(const Vec3d& arg);
	/**
	* @brief Invoke the binary segmentation function.
	*/
    bool Binary();
    bool CalcImageRange();
private:
    //
    bool isStartTrace_;
    enum TRACESTATUS{SOMA, AXONSTART, AXONCONTINUE};
    TRACESTATUS status_;
    int curStepNum_;
    //int xScale_, yScale_, zScale_;
    //init axon pos and direction
    Vec3d initAxonPosition_;
    Vec3d initAxonDirection_;
    Vec3i largeVolumeBoundary;
    Vec3d tmpBoundaryPtDirection;
    //data for function class
    NGParamPack paramPack;
    NGParamPack paramPackBakup_;
    NG_SMART_POINTER_DEFINE(Soma, tmpSoma);
    //function class
    NGSparseTraceFilter sparseFilter;
    NGSparseTraceAxonFilter sparseAxonFilter;
    NGBinaryFilter binaryFilter;
    //for most-d
    NGNeuronBigReader mostdReader;
    int sumIndex;
    //
    std::pair<Vec3d, Vec3d> nextInit_;
};

#endif // LARGESPARSETRACEFILTER_H
