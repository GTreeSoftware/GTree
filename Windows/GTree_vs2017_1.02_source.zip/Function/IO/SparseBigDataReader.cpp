#include "SparseBigDataReader.h"
#include "Function/IO/imagereader.h"
#include <io.h>

SparseBigDataReader::SparseBigDataReader()
{

}


SparseBigDataReader::~SparseBigDataReader()
{
	//delete[] checkTable;
}

bool SparseBigDataReader::SetInputFileName(std::string &arg)
{
	if (!paramPack) {
		printf("please input paramPack in SparseBigDataReader first.\n");
		return false;
	}
	FILE *rp = fopen(arg.c_str(), "rb");
	if (!rp) {
		printf("cannot open sbd file.\n");
		system("pause");
		return false;
	}
	char line[256];
	fread(line, sizeof(char), 256, rp);
	fileDir = std::string(line);
	fread(&maxLevel, sizeof(int), 1, rp);
	fread(&globalX, sizeof(int), 1, rp);
	fread(&globalY, sizeof(int), 1, rp);
	fread(&globalZ, sizeof(int), 1, rp);
	fread(&blockX, sizeof(int), 1, rp);
	fread(&blockY, sizeof(int), 1, rp);
	fread(&blockZ, sizeof(int), 1, rp);
	fread(&dataType, sizeof(int), 1, rp);
	fread(&resX, sizeof(double), 1, rp);
	fread(&resY, sizeof(double), 1, rp);
	fread(&resZ, sizeof(double), 1, rp);
	levelTable.resize(maxLevel + 1);//1-maxLevel
	for (int k = 1; k <= maxLevel; ++k) {
		fread(&levelTable[k].xNum, sizeof(int), 1, rp);
		fread(&levelTable[k].yNum, sizeof(int), 1, rp);
		fread(&levelTable[k].zNum, sizeof(int), 1, rp);
		levelTable[k].table_ = new unsigned char[levelTable[k].xNum * levelTable[k].yNum * levelTable[k].zNum];
		fread(levelTable[k].table_, sizeof(unsigned char), levelTable[k].xNum
			* levelTable[k].yNum * levelTable[k].zNum, rp);
	}
	levelTable[1].blockX = levelTable[1].blockY = blockX;
	levelTable[1].blockZ = blockZ;
	for (int k = 2; k <= maxLevel; ++k) {
		levelTable[k].blockX = levelTable[k - 1].blockX * 2;
		levelTable[k].blockY = levelTable[k - 1].blockY * 2;
		levelTable[k].blockZ = levelTable[k - 1].blockZ * 2;
	}
	/*xNum = int(round(float(globalX) / float(blockX)));
	yNum = int(round(float(globalY) / float(blockY)));
	zNum = int(round(float(globalZ) / float(blockZ)));
	xyNum = xNum * yNum;
	if (checkTable != NULL) {
		delete[] checkTable;
	}
	checkTable = new unsigned char[xyNum * zNum];
	fread(checkTable, sizeof(unsigned char), xyNum * zNum, rp);*/
	fclose(rp);
	//
	paramPack->xRangeMax_ = globalX;
	paramPack->yRangeMax_ = globalY;
	paramPack->zRangeMax_ = globalZ;
	paramPack->xRes_ = resX;
	paramPack->yRes_ = resY;
	paramPack->zRes_ = resZ;
	//the true max level
	/*superMaxLevel = int(round(std::log2(globalX / 512)));
	superMaxLevel = std::max(superMaxLevel, int(round(std::log2(globalY / 512))));
	superMaxLevel = std::max(superMaxLevel, int(round(std::log2(globalZ / 512))));
	++superMaxLevel;
	superMaxLevel = std::max(superMaxLevel, maxLevel);*/
	printf("Sparse Big Data Reader ready.\n");
	return true;
}

bool SparseBigDataReader::Update()
{
	if (!m_Source) NG_SMART_POINTER_NEW(SVolume, m_Source, NULL);
	// check if out of boundary
	if (paramPack->xMax_ <= paramPack->xMin_ || paramPack->yMax_ <= paramPack->yMin_
		|| paramPack->zMax_ <= paramPack->zMin_ || paramPack->xMax_ < 0 || paramPack->xMin_ < 0 || paramPack->yMax_ < 0 ||
		paramPack->yMin_ < 0 || paramPack->zMax_ < 0 || paramPack->zMin_ < 0) {
		printf("error range.\n");
		return false;
	}
	if (paramPack->mostdLevel_ > maxLevel) {
		printf("Cannot produce smaller pyramid data.\n");
		return false;
	}
	//
	NG_CREATE_DYNAMIC_CAST(SVolume, image, m_Source);
	int xSz = paramPack->xMax_ - paramPack->xMin_;
	int ySz = paramPack->yMax_ - paramPack->yMin_;
	int zSz = paramPack->zMax_ - paramPack->zMin_;
	int scale = int(std::pow(2, paramPack->mostdLevel_ - 1));
	xSz /= scale;
	ySz /= scale;
	zSz /= scale;
	if (xSz < 10 || ySz < 10 || zSz < 10) {
		printf("Sparse Big Data is too small.\n");
		return false;
	}
	if (xSz > 1024 || ySz > 1024 || zSz > 1024) {
		printf("Sparse Big Data texture size is large than 1024.\n");
		return false;
	}
	image->SetSize(xSz, ySz, zSz);
	//
	int xBeg = paramPack->xMin_ / levelTable[paramPack->mostdLevel_].blockX;
	int xEnd = paramPack->xMax_ / levelTable[paramPack->mostdLevel_].blockX;
	int yBeg = paramPack->yMin_ / levelTable[paramPack->mostdLevel_].blockY;
	int yEnd = paramPack->yMax_ / levelTable[paramPack->mostdLevel_].blockY;
	int zBeg = paramPack->zMin_ / levelTable[paramPack->mostdLevel_].blockZ;
	int zEnd = paramPack->zMax_ / levelTable[paramPack->mostdLevel_].blockZ;
	std::string tmpReadName;
	char line[256];
	NGImageReader reader = ImageReader::New();
	reader->SetParam(paramPack);
	Vec3i globalLeftBottom(paramPack->xMin_, paramPack->yMin_, paramPack->zMin_);
	Vec3i globalRightTop(paramPack->xMax_, paramPack->yMax_, paramPack->zMax_);
	Vec3i localScaleLeftBottom, globalScaleLeftBottom = globalLeftBottom / scale;
	Vec3i localLeftBottom, localRightTop;
	int xNum = levelTable[paramPack->mostdLevel_].xNum;
	int yNum = levelTable[paramPack->mostdLevel_].yNum;
	int zNum = levelTable[paramPack->mostdLevel_].zNum;
	int xyNum = xNum * yNum;
	for (int i = xBeg; i <= xEnd; ++i) {
		for (int j = yBeg; j <= yEnd; ++j) {
			for (int k = zBeg; k <= zEnd; ++k) {
				if (0 == levelTable[paramPack->mostdLevel_].table_[i + j * xNum + k * xyNum]) {//no data
					continue;
				}
				sprintf(line, "/level%d/%05d_%05d_%05d.tif", paramPack->mostdLevel_, i * levelTable[paramPack->mostdLevel_].blockX, 
					j * levelTable[paramPack->mostdLevel_].blockY, k * levelTable[paramPack->mostdLevel_].blockZ);
				tmpReadName = fileDir + std::string(line);
				if (_access(tmpReadName.c_str(),0) != 0) {
					sprintf(line, "/level%d/%d_%d_%d.tif", paramPack->mostdLevel_, i * levelTable[paramPack->mostdLevel_].blockX,
						j * levelTable[paramPack->mostdLevel_].blockY, k * levelTable[paramPack->mostdLevel_].blockZ);
					tmpReadName = fileDir + std::string(line);
				}
				if (_access(tmpReadName.c_str(), 0) != 0) {
					printf("%s is invalid.\n",tmpReadName.c_str());
					//system("pause");
					return false;
				}
				printf("reading %s\n", tmpReadName.c_str());
				
				localLeftBottom << i * levelTable[paramPack->mostdLevel_].blockX, 
					j * levelTable[paramPack->mostdLevel_].blockY, k * levelTable[paramPack->mostdLevel_].blockZ;//global coordinate of image block
				localRightTop = localLeftBottom + Vec3i(levelTable[paramPack->mostdLevel_].blockX, 
					levelTable[paramPack->mostdLevel_].blockY, levelTable[paramPack->mostdLevel_].blockZ);

				localScaleLeftBottom = localLeftBottom / scale;
				
				std::shared_ptr<BlockCache16> cache = GetCache(tmpReadName);
				if (!cache) {//no cache data
					std::shared_ptr<BlockCache16> newCache = std::make_shared<BlockCache16>();
					reader->SetInputFileName(tmpReadName);
					reader->Update();
					auto tmpData = reader->ReleaseData();
					newCache->img = std::dynamic_pointer_cast<SVolume>(tmpData);
					newCache->fileName = tmpReadName;
					newCache->usedTime = time(0);
					cache = newCache;
					AddCache(newCache);
				}
				else {//use cache data
					printf("%s is read.\n", tmpReadName.c_str());
					std::shared_ptr<SVolume> cacheImg = cache->img;
					cache->usedTime = time(0);
				}
				//use cache to crop data
				Vec3i relativeLeftBottom, relativeRightTop;
				if (paramPack->mostdLevel_ <= maxLevel) {
					if (localLeftBottom(0) >= globalLeftBottom(0) && localLeftBottom(1) >= globalLeftBottom(1)
						&& localLeftBottom(2) >= globalLeftBottom(2) && localRightTop(0) <= globalRightTop(0)
						&& localRightTop(1) <= globalRightTop(1) && localRightTop(2) <= globalRightTop(2)) {

						relativeLeftBottom << (i * levelTable[paramPack->mostdLevel_].blockX - globalLeftBottom(0)) / scale,
							(j *levelTable[paramPack->mostdLevel_].blockY - globalLeftBottom(1)) / scale,
							(k *levelTable[paramPack->mostdLevel_].blockZ - globalLeftBottom(2)) / scale;
						for (int l = 0; l < cache->img->x(); ++l) {// here from 0
							for (int m = 0; m < cache->img->y(); ++m) {
								for (int n = 0; n < cache->img->z(); ++n) {
									(*image)(l+ relativeLeftBottom(0), 
										m + relativeLeftBottom(1), 
										n + relativeLeftBottom(2)) = cache->img->operator()(l,m,n);
								}
							}
						}
					}
					else {
						/*relativeLeftBottom(0) = std::max(localLeftBottom(0), globalLeftBottom(0)) / scale;
						relativeLeftBottom(1) = std::max(localLeftBottom(1), globalLeftBottom(1)) / scale;
						relativeLeftBottom(2) = std::max(localLeftBottom(2), globalLeftBottom(2)) / scale;
						relativeRightTop(0) = std::min(localRightTop(0), globalRightTop(0)) / scale;
						relativeRightTop(1) = std::min(localRightTop(1), globalRightTop(1)) / scale;
						relativeRightTop(2) = std::min(localRightTop(2), globalRightTop(2)) / scale;*/
						relativeLeftBottom(0) = std::max(localLeftBottom(0), globalLeftBottom(0));
						relativeLeftBottom(1) = std::max(localLeftBottom(1), globalLeftBottom(1)) ;
						relativeLeftBottom(2) = std::max(localLeftBottom(2), globalLeftBottom(2));
						//globalScaleLeftBottom = (globalLeftBottom - localLeftBottom) / scale;
						relativeLeftBottom /= scale;

						relativeRightTop(0) = std::min(localRightTop(0), globalRightTop(0));
						relativeRightTop(1) = std::min(localRightTop(1), globalRightTop(1));
						relativeRightTop(2) = std::min(localRightTop(2), globalRightTop(2));
						relativeRightTop /= scale;
						if (relativeRightTop(0) - globalScaleLeftBottom(0) >= (*image).x()) 
							relativeRightTop(0) = globalScaleLeftBottom(0) + (*image).x();
						if (relativeRightTop(1) - globalScaleLeftBottom(1) >= (*image).y())
							relativeRightTop(1) = globalScaleLeftBottom(1) + (*image).y();
						if (relativeRightTop(2) - globalScaleLeftBottom(2) >= (*image).z())
							relativeRightTop(2) = globalScaleLeftBottom(2) + (*image).z();
						
						//relativeRightTop = relativeLeftBottom + Vec3i((*image).x(), (*image).y(), (*image).z());
						
						for (int l = relativeLeftBottom(0); l < relativeRightTop(0); ++l) {//here from coordinate !!!
							for (int m = relativeLeftBottom(1); m < relativeRightTop(1); ++m) {
								for (int n = relativeLeftBottom(2); n < relativeRightTop(2); ++n) {
									(*image)(l - globalScaleLeftBottom(0), m - globalScaleLeftBottom(1), n - globalScaleLeftBottom(2))
										= cache->img->operator()(l - localScaleLeftBottom(0),
											m - localScaleLeftBottom(1),
											n - localScaleLeftBottom(2));
								}
							}
						}
					}
				}
				else {
					printf("what are you doing?\n");
					return false;
				}
			}
		}
	}
	double levelRes = std::pow(2.0, paramPack->mostdLevel_ - 1);
	image->SetResolution(paramPack->xRes_ * levelRes, paramPack->yRes_ * levelRes, paramPack->zRes_* levelRes);
	image->SetDataType(DATATYPE::IMAGE16);
	return true;
}

bool SparseBigDataReader::ScaleVolume(const SVolume *input, SVolume &output, int scale) {//nearest intepolate
	if (scale <= 1) {
		printf("Error scale: %d", scale);
		return false;
	}
	int ix = input->x();
	int iy = input->y();
	int iz = input->z();

	int ox = ix / scale;
	int oy = iy / scale;
	int oz = iz / scale;
	output.SetSize(ox, oy, oz);
	for (int i = 0; i < ox; ++i) {
		for (int j = 0; j < oy; ++j) {
			for (int k = 0; k < oz; ++k) {
				output(i, j, k) = (*input)(i*scale, j*scale, k*scale);
			}
		}
	}

	return true;
}

IDataPointer SparseBigDataReader::ReleaseData()
{
	m_Source->ReleaseProcessObject();
	IDataPointer tData(m_Source);
	m_Source.reset();
	return tData;
}

void SparseBigDataReader::ClearCache()
{
	imageCache_.clear();
}

void SparseBigDataReader::GetMaxRange(int& x, int& y, int& z)
{
	x = globalX;
	y = globalY;
	z = globalZ;
}

void SparseBigDataReader::AddCache(std::shared_ptr<BlockCache16> &arg)
{
	while (imageCache_.size() >= maxCache) {
		std::sort(imageCache_.begin(), imageCache_.end(), [](std::shared_ptr<BlockCache16>& arg1, std::shared_ptr<BlockCache16>& arg2) {
			return arg1->usedTime > arg2->usedTime; });
		imageCache_.pop_back();
	}
	arg->usedTime = time(0);
	imageCache_.push_back(arg);
}

std::shared_ptr<BlockCache16> SparseBigDataReader::GetCache(std::string &fileName)
{
	std::shared_ptr<BlockCache16> pointer;
	pointer.reset();
	auto it = std::find_if(imageCache_.begin(), imageCache_.end(), [&](std::shared_ptr<BlockCache16>& arg) {return arg->fileName == fileName; });
	if (it != imageCache_.end()) {
		pointer = *it;
	}
	return pointer;
}
