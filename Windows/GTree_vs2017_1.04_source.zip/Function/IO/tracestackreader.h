/**
 * @file imagereader.h
 * @brief Implementation class for reading tracing information file.
 * @details The postfix of target file is *.sta. STA file includes the path list of swc, 
 * the position of untracked neurite, tracing paramters, 3D rendering paramters and so on.
 * @author Zhou Hang
 * @license CopyRight Zhou Hang (Huazhong University of Science and Technology)
 */
#ifndef TRACESTACKREADER_H
#define TRACESTACKREADER_H
#include <memory>
#include <string>
#include "../ineuronio.h"
#include "ngtypes/soma.h"
#include "ngtypes/ParamPack.h"
//#include "../../ngtypes/ineurondataobject.h"
class INeuronDataObject;
//class Soma;
class TraceStackReader;
typedef std::shared_ptr<TraceStackReader> NGTraceStackReader;
/**
* @brief Implementation class for reading tracing information file.
*  This class can read tracing information file of which the postfix is *.sta. STA file includes the path list of swc,
 * the position of untracked neurite, tracing paramters, 3D rendering paramters and so on.
*/
class TraceStackReader : public INeuronIO
{
public:
    static NGTraceStackReader New(){return NGTraceStackReader(new TraceStackReader());}
    TraceStackReader();
    ~TraceStackReader();
    bool SetInputFileName(const std::string&);
    virtual ProcStatPointer Update();
    void SetParam(NGParamPack arg){paramPack = arg;}
    const std::vector<std::string>& GetSwcFileName(){ return swcNames; }

protected:
    bool SetOutputFileName(const std::string&){ return false; }
    IDataPointer ReleaseData(){ return m_Source; }
    ConstIDataPointer GetOutput(){ return m_Source; }
    void Split(const std::string& src, const std::string& separator, std::vector<std::string>& dest);
   

private:
    bool isFileValid;
    std::string filename;
    std::vector<std::string> swcNames;
    NGParamPack paramPack;
    
};

#endif // SOMAREADER_H
