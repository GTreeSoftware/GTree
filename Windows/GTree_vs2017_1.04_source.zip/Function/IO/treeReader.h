/**
 * @file treeReader.h
 * @brief Function class for swc file reading.
 * @details This class can open swc file which represents a neuron tree.
 * @license CopyRight Huazhong University of Science and Technology
 */
#ifndef TREEREADER_H
#define TREEREADER_H
#include <memory>
#include <string>
#include <vector>
#include "../ineuronio.h"
#include "ngtypes/ParamPack.h"
#pragma warning(disable:4996)
class INeuronDataObject;
class NeuronPopulation;
class TreeReader;
typedef std::shared_ptr<TreeReader> NGTreeReader;
/**
* @brief Function class for swc file reading.
*  This class can open swc file which represents a neuron tree. More information of swc file format can be seen
* at http://www.neuronland.org/NLMorphologyConverter/MorphologyFormats/SWC/Spec.html .
*/
class TreeReader :
	public INeuronIO
{
public:
	typedef std::shared_ptr<NeuronPopulation> NeuronPopulationPointer;
	static NGTreeReader New() { return NGTreeReader(new TreeReader()); }
	TreeReader(void);
	~TreeReader(void);
	void SetInputFileNameList(const std::vector<std::string>&);
	void SetTraverseFile(const std::vector<std::string>&);
	INEURONPROCESSOBJECT_DEFINE
		/*bool Update();
		IDataPointer ReleaseData();
		ConstIDataPointer GetOutput();*/
		bool ReadTraverseFile(const std::string &file, std::vector<Line5d>&);
	void SetParam(NGParamPack arg) { param = arg; }
private:
	void SetInput(ConstIDataPointer) {}
	bool SetInputFileName(const std::string &) { return false; }
	bool SetOutputFileName(const std::string&) { return false; }
	bool isFileValid;
	std::vector<std::string> fileNameList;
	std::vector<std::string> traverseNameList;
	NGParamPack param;
	//double xRes_, yRes_, zRes_;
	//2015-8-13
	//double xScale_, yScale_, zScale_;
	//NGParamPack paramPack;//TODO
};
#endif
