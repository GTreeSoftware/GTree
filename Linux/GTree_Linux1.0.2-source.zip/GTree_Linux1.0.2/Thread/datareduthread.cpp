#ifdef _WIN32
#include "direct.h"
#else
#include <unistd.h>
#endif
#include "datareduthread.h"
//#include "../DockWidget/datareductiondockwidget.h"
#include "../ngtypes/tree.h"
#include "Function/IO/treewriter.h"
#include <QReadWriteLock>

