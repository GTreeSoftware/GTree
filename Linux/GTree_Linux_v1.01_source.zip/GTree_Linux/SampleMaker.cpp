
#include <QtWidgets/QFileDialog>
#include <QtWidgets/QTextBrowser>
#include <vector>
#include <QDir>
#include <iostream>
#include "Function/IO/MOSTDReader.h"
#include "Function/IO/imagewriter.h"
#include "SampleMaker.h"
#include "ui_SampleMaker.h"
#include "ngtypes/volume.h"
#include <unistd.h>
#include <QtWidgets/QMessageBox>


SampleMaker::SampleMaker(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::SampleMakerWidget)
{
	ui->setupUi(this);
	setWindowFlags(Qt::Window | Qt::WindowSystemMenuHint |  Qt::WindowCloseButtonHint);//Qt::WindowStaysOnTopHint |
}


SampleMaker::~SampleMaker()
{
}

void SampleMaker::on_mostdPathButton_clicked()
{
	QString mostdFile = QFileDialog::getOpenFileName(this, "open mostd","","MOSTD (*.mostd)");
	if (0 ==access(mostdFile.toStdString().c_str(),0)){
		mostdReader_ = MOSTDReader::New();
		param_ = NGParamPack(new ParamPack());
		mostdReader_->SetParam(param_);
		mostdReader_->SetInputFileName(mostdFile.toStdString());
		ui->mostdPathEdit->setText(mostdFile);
		int xMaxRange, yMaxRange, zMaxRange;
		mostdReader_->GetMaxRange(xMaxRange, yMaxRange, zMaxRange);
		mostdInfo = tr("mostd range: %1 %2 %3\n").arg(xMaxRange).arg(yMaxRange).arg(zMaxRange);
		ui->xRangeEdit->setText(tr("0-%1").arg(xMaxRange-1));
		ui->yRangeEdit->setText(tr("0-%1").arg(yMaxRange-1));
		ui->zRangeEdit->setText(tr("0-%1").arg(zMaxRange-1));
		ui->textBrowser->clear();
		ui->textBrowser->setText(mostdInfo);
		ui->progressBar->setValue(0);
	}
	//else {
	//	//QMessageBox::warning(this, "Mostd file invalid", "please choose right mostd file.");
	//	ui->textBrowser->setText("Mostd file invalid, please choose right mostd file.");
	//	return;
	//}
}

void SampleMaker::on_dstPathButton_clicked()
{
	QString dstPath = QFileDialog::getExistingDirectory(this, "select save directory");
	if (!dstPath.isEmpty()) {
		ui->dstPathEdit->setText(dstPath);
	}
}

void SampleMaker::on_startButton_clicked()
{
	if (!Validate()) {
		//QMessageBox::warning(this, "parameters invalid", "Please Check the Parameters");
	}
	else {
		MakeSamples();
	}
}

void SampleMaker::on_stopButton_clicked()
{
	QMessageBox::information(this, "stop not implement", "not implement");
}

void SampleMaker::on_initTxtButton_clicked()
{
	ui->textBrowser->clear();
	if (!mostdInfo.isEmpty()) {
		ui->textBrowser->setText(mostdInfo);
	}
}

//check parameters
bool SampleMaker::Validate()
{
	//mostd file check,xrange,yrange,zrang,block
	
	xBlockSize = ui->xBlockBox->value();
	yBlockSize = ui->yBlockBox->value();
	zBlockSize = ui->zBlockBox->value();
	mostdReader_->GetMaxRange(xMaxRange, yMaxRange, zMaxRange);
	//block size check
	if (xBlockSize < 10 || yBlockSize < 10 || zBlockSize < 10) {
		ui->textBrowser->setText("block size too small.");
		return false;
	}
	//range check
	if (xBlockSize > xMaxRange || zBlockSize > zMaxRange || zBlockSize > zMaxRange) {
		ui->textBrowser->setText("mostd range is smaller than block size.");
		return false;
	}
	//crop range check
	bool ok = false;
	QString xstr = ui->xRangeEdit->text();
	QString ystr = ui->yRangeEdit->text();
	QString zstr = ui->zRangeEdit->text();
	
	QStringList xRangeList = xstr.split('-');
	QStringList yRangeList = ystr.split('-');
	QStringList zRangeList = zstr.split('-');
#define CHECKCROPRANGE(var, varlist, index, OK) var = varlist[index].toInt(&OK); \
 if(!OK) {ui->textBrowser->append(QString(#var)+QString(" value format is wrong.")); return false;}
	//xMin = xRangeList[0].toInt(&ok); if (!ok) return false;
	//xMax = xRangeList[1].toInt(&ok);
	CHECKCROPRANGE(xMin, xRangeList, 0, ok);
	CHECKCROPRANGE(xMax, xRangeList, 1, ok);
	CHECKCROPRANGE(yMin, yRangeList, 0, ok);
	CHECKCROPRANGE(yMax, yRangeList, 1, ok);
	CHECKCROPRANGE(zMin, zRangeList, 0, ok);
	CHECKCROPRANGE(zMax, zRangeList, 1, ok);

	if (xMax < xMin + 10 || yMax < yMin + 10 || zMax < zMin + 10 
		|| xMin < 0 || yMin < 0 || zMin < 0 || 
		xMax >=  xMaxRange || yMax >= yMaxRange || zMax >= zMaxRange) {
		ui->textBrowser->append("crop range is wrong.");
		return false;
	}
	
	//check files in destination directory
	QStringList dstDirFiles = QDir(ui->dstPathEdit->text()).entryList();
	if (dstDirFiles.size() > 2) {
		ui->textBrowser->append("Please Choose empty destination directory.");
		return false;
	}
	return true;
}

bool SampleMaker::MakeSamples()
{
	//int xMaxRange, yMaxRange, zMaxRange;
	//int xBlockSize = ui->xBlockBox->value();
	//int yBlockSize = ui->yBlockBox->value();
	//int zBlockSize = ui->zBlockBox->value();
	//mostdReader_->GetMaxRange(xMaxRange, yMaxRange, zMaxRange);
	QString pre = ui->prefixEdit->text();
	QString post = ui->postEdit->text();

	//crop to index list
	std::vector<std::pair<int, int> > xCropList;
	std::vector<std::pair<int, int> > yCropList;
	std::vector<std::pair<int, int> > zCropList;
	//xMin
	int ind = xMin;
	while (ind + xBlockSize - 1 <= xMax) {
		xCropList.push_back(std::make_pair(ind, ind + xBlockSize - 1));
		ind += xBlockSize;
	}
	if (ind < xMax - 10) {
		xCropList.push_back(std::make_pair(ind, xMax));
	}
	//yMin
	ind = yMin;
	while (ind + yBlockSize - 1 <= yMax) {
		yCropList.push_back(std::make_pair(ind, ind + yBlockSize -1 ));
		ind += yBlockSize;
	}
	if (ind < yMax - 10) {
		yCropList.push_back(std::make_pair(ind, yMax));
	}
	//zMin
	ind = zMin;
	while (ind + zBlockSize - 1 <= zMax) {
		zCropList.push_back(std::make_pair(ind, ind + zBlockSize - 1));
		ind += zBlockSize;
	}
	if (ind < zMax - 10) {
		zCropList.push_back(std::make_pair(ind, zMax));
	}
	//test
	/*std::cout << "x: " << std::endl;
	for (auto &it : xCropList) {
		std::cout << it.first << " " << it.second << std::endl;
	}
	std::cout << std::endl;
	std::cout << "y: " << std::endl;
	for (auto &it : yCropList) {
		std::cout << it.first << " " << it.second << std::endl;
	}
	std::cout << std::endl;
	std::cout << "z: " << std::endl;
	for (auto &it : zCropList) {
		std::cout << it.first << " " << it.second << std::endl;
	}
	std::cout << std::endl;
	return false;*/

	NGImageWriter writer = ImageWriter::New();
	QString savePrePath = ui->dstPathEdit->text();
	double blockSum = double(xCropList.size() * yCropList.size() * zCropList.size());
	double progress = 0.0;
	int iprogress = 0;
	for (auto &zit : zCropList) {
		for (auto &yit:yCropList) {
			for (auto &xit : xCropList) {
				param_->xMin_ = xit.first; param_->xMax_ = xit.second;
				param_->yMin_ = yit.first; param_->yMax_ = yit.second;
				param_->zMin_ = zit.first; param_->zMax_ = zit.second;
				auto res = mostdReader_->Update();
				if (!res->success()) {
					QMessageBox::warning(this, QString::fromStdString(res->ErrorClassName()), QString::fromStdString(res->ErrorInfo()));
					return false;
				}
				param_->OrigImage = mostdReader_->ReleaseData();
				
				QString saveName = savePrePath + '/' + pre + tr("%1_%2_%3").arg(xit.first,5,10, QLatin1Char('0')).arg(
					yit.first,5, 10, QLatin1Char('0')).arg(zit.first,5, 10, QLatin1Char('0')) + post + ".tif";
				//std::cout << saveName.toStdString() << std::endl;
				ui->textBrowser->setText(QString("save to ") + saveName);
				ui->textBrowser->update();
				std::shared_ptr<SVolume> tmpImg = std::dynamic_pointer_cast<SVolume>(param_->OrigImage);
				std::shared_ptr<SVolume> realImg = std::make_shared<SVolume>(); 
				realImg->SetSize(tmpImg->x(), tmpImg->y(), tmpImg->z());
				for (int x = 0; x < realImg->x(); ++x) {
					for (int y = 0; y < realImg->y(); ++y) {
						for (int z = 0; z < realImg->z(); ++z) {
							realImg->operator()(x, y, z) = (tmpImg->operator()(x,y,z));//unsigned char
						}
					}
				}
				writer->SetOutputFileName(saveName.toStdString());
				writer->SetInput(realImg);//OrigImage
				res = writer->Update();
				if (!res->success()) {
					QMessageBox::warning(this, QString::fromStdString(res->ErrorClassName()), QString::fromStdString(res->ErrorInfo()));
					return false;
				}
				//Sleep(1000);
				++iprogress;
				progress = double(iprogress) / blockSum * 100;
				ui->progressBar->setValue(int(progress));
				ui->progressBar->update();
				this->repaint();
				//return false;
			}
		}//return false;
	}
	ui->textBrowser->append(mostdInfo);
	return true;
}
