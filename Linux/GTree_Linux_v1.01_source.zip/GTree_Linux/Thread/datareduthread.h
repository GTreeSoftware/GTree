#ifndef DATAREDUTHREAD_H
#define DATAREDUTHREAD_H

#include <QThread>
#include <memory>
#include <algorithm>
#include "Function/ineuronprocessobject.h"
#include "ngtypes/ParamPack.h"
#include "Function/ineuronio.h"
#include "../ngtypes/soma.h"
#include "../Function/Trace/NeuroGPSTreeFilter.h"
#include "../ngtypes/tree.h"
#include "../ngtypes/basetypes.h"
#include "../Function/IO/MOSTDReader.h"
#include <QReadWriteLock>


#endif // DATAREDUTHREAD_H
