#include "direct.h"
#include "datareduthread.h"
//#include "../DockWidget/datareductiondockwidget.h"
#include "../ngtypes/tree.h"
#include "Function/IO/treewriter.h"
#include <QReadWriteLock>
DataReduThread::DataReduThread(QObject *parent)
	: QThread(parent)
{
	isInitParam = false;
	isInitVecParam = false;
	//datareduDock = new DataReductionDockWidget();
	
}

DataReduThread::~DataReduThread()
{

}

void DataReduThread::SetParam(const std::string &pth, NGParamPack &arg1){
	paramPack4Redu = std::make_shared<ParamPack>();
	*paramPack4Redu = *arg1;
	MostdFilePath = pth;
	mostdReader = MOSTDReader::New();
	mostdReader->SetParam(paramPack4Redu);
	mostdReader->SetInputFileName(pth);
	
	isInitParam = true;
}

void DataReduThread::SetVecParam(int &vt, Vec3i &vm, Vec3i &v, Vec3i &st, Vec3i &ex){
	VecTotal = vt;
	xVecMax = vm(0);
	yVecMax = vm(1);
	zVecMax = vm(2);
	//xVec = v(0);
	//yVec = v(1);
	//zVec = v(2);
	xStride = st(0);
	yStride = st(1);
	zStride = st(2);
	xExtract = ex(0);
	yExtract = ex(1);
	zExtract = ex(2);
	isInitVecParam = true;
}

void DataReduThread::run(){
	if (!isInitParam || !isInitVecParam){
		printf("there is not initialization.\n");//TODO
		return;
	}
	int xMin, yMin, zMin, xMax, yMax, zMax;
	int xVec, yVec, zVec, tmpz;
	//omp_set_num_threads(5);
//#pragma omp parallel 
//#pragma omp for private(zVec,tmpz,yVec,xVec,xMin,yMin,zMin,xMax,yMax,zMax)
	for (int curVec = 1; curVec <= VecTotal; ++curVec){
		//printf("current thread:%d\n", omp_get_thread_num());
		NGParamPack paramPack4thread = std::make_shared<ParamPack>();
		NGNeuronBigReader mostdReader4thread = MOSTDReader::New();
		*paramPack4thread = *paramPack4Redu;
		mostdReader4thread->SetParam(paramPack4thread);
		mostdReader4thread->SetInputFileName(MostdFilePath);
		zVec = 1 + floor(curVec / (xVecMax*yVecMax));
		tmpz = floor(curVec % (xVecMax*yVecMax));
		yVec = 1 + floor((tmpz - 1) / xVecMax);
		xVec = 1 + floor((tmpz - 1) % xVecMax);
		xMin = (xVec - 1)*xStride;
		yMin = (yVec - 1)*yStride;
		zMin = (zVec - 1)*zStride;
		xMax = std::min(xMin + xExtract, paramPack4Redu->xRangeMax_);
		yMax = std::min(yMin + yExtract, paramPack4Redu->yRangeMax_);
		zMax = std::min(zMin + zExtract, paramPack4Redu->zRangeMax_);
		paramPack4thread->xMin_ = xMin;
		paramPack4thread->yMin_ = yMin;
		paramPack4thread->zMin_ = zMin;
		paramPack4thread->xMax_ = xMax;
		paramPack4thread->yMax_ = yMax;
		paramPack4thread->zMax_ = zMax;
		if (!mostdReader4thread->Update()->success()){
			printf("Reading mostd is failed in ParallelTracer,%d %d %d %d %d %d\n", xMin, yMin, zMin, xMax, yMax, zMax);
		}
		printf("Image:%d %d %d %d %d %d\n", xMin, yMin, zMin, xMax, yMax, zMax);
		paramPack4thread->OrigImage = mostdReader4thread->ReleaseData();

		/* NeuroGPS Trace */
		{
			NG_CREATE_DYNAMIC_CAST(Soma, tmpSoma, paramPack4thread->SomaList);
			if (!tmpSoma) paramPack4thread->SomaList = std::make_shared<Soma>();
			NG_DYNAMIC_CAST(Soma, tmpSoma, paramPack4thread->SomaList);
		}
		NGNeuroGPSTreeFilter ngt = NeuroGPSTreeFilter::New();
		ngt->SetParam(paramPack4thread);
		ngt->SetSoma(paramPack4thread->SomaList);
		auto traceres = ngt->Update();
		if (!traceres->success()) {
			printf("Trace fail.\n");
			continue;
		}
		IDataPointer tmpNewSeparateTree = ngt->ReleaseData();
		NG_CREATE_DYNAMIC_CAST(NeuronPopulation, tmpTree, paramPack4thread->separateTree);
		NG_CREATE_DYNAMIC_CAST(NeuronPopulation, tmpNewTree, tmpNewSeparateTree);
		tmpTree->m_pop.clear();
		for (size_t i = 0; i < tmpNewTree->m_pop.size(); ++i) {
			tmpTree->m_pop.push_back(tmpNewTree->m_pop[i]);
		}
		printf("\n!!!!test!!!!\n Tree size:%d, \n\n", tmpTree->m_pop.size());
		Save(paramPack4thread,paramPack4thread->separateTree, xMin, yMin, zMin);
		paramPack4thread->SomaList = std::make_shared<Soma>();//delete soma
		emit ParallelTracerImagePosition_Signal(xMin, yMin, zMin);
	}
}

void DataReduThread::Save(NGParamPack& param, IDataPointer & MultiTree, int &xmin, int &ymin, int &zmin){
	QString  savePath = param->DataReduDir + QString("/%1_%2_%3").arg(xmin).arg(ymin).arg(zmin);
	if (mkdir(savePath.toStdString().c_str())) return;
	printf("%s\n", savePath.toStdString().c_str());
	
	NG_CREATE_DYNAMIC_CAST(NeuronPopulation, tmpTree, MultiTree);
	if (tmpTree->m_pop.size() == 0)	return;
	QString swcPath;
	std::vector<std::string> fileList;
	for (size_t i = 0; i < tmpTree->m_pop.size(); ++i) {
		//save tree iteratively
		swcPath = savePath + QString("/%1_%2_%3").arg(xmin).arg(ymin).arg(zmin) + QString(tr("_%1").arg(i, 3, 10, QChar('0'))) + QString(".swc");
		fileList.push_back(swcPath.toStdString());
	}
	auto writer = TreeWriter::New();
	writer->SetInput(MultiTree);
	writer->SetParam(param);
	writer->SetOutputFileName(fileList);
	auto res = writer->Update();
	if (!res->success()) {
		return;
	}
}