#pragma once
#include <vector>
#include <memory>
#include "ngtypes/basetypes.h"
#include "ngtypes/ParamPack.h"
#include "ngtypes/volume.h"
#include "ngtypes/ineurondataobject.h"
#include <time.h>

typedef Volume<unsigned char> CVolume;
typedef Volume<unsigned short> SVolume;

struct BlockCache16 {
	std::string fileName;
	time_t usedTime;
	std::shared_ptr<SVolume> img;
};

struct QueryTable {
	int blockX, blockY, blockZ;
	int xNum, yNum, zNum;
	unsigned char* table_ = 0;
	~QueryTable()
	{
		//printf("nima query\n");
		if (table_) delete[] table_;
		table_ = 0;
	}
};

//struct BlockCache8 {
//	CVolume img;
//};

class SparseBigDataReader
{
public:
	SparseBigDataReader();
	~SparseBigDataReader();

	void SetParam(NGParamPack arg) { paramPack = arg; }
    bool SetInputFileName(const std::string &arg);
	bool Update();
	bool ScaleVolume(const SVolume *input, SVolume &output, int scale);
	IDataPointer ReleaseData();
	void ClearCache();

	void GetMaxRange(int& x, int& y, int& z);

	void AddCache(std::shared_ptr<BlockCache16> &arg);
	std::shared_ptr<BlockCache16> GetCache(std::string &arg);

private:
	//DATATYPE dataType = DATATYPE::IMAGE16;
	NGParamPack paramPack;
	IDataPointer m_Source;
	std::vector<std::shared_ptr<BlockCache16> > imageCache_;
	int globalX, globalY, globalZ;
	int blockX, blockY, blockZ, dataType, maxLevel;
	//int xNum, yNum, zNum, xyNum;
	int maxCache = 10;
	int superMaxLevel;
	double resX, resY, resZ;
	std::string fileDir;
	std::vector<QueryTable> levelTable;
};

