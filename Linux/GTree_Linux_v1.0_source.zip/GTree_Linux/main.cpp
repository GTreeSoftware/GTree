#include "SparseTracer.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	SparseTracer w;
	w.show();
	return a.exec();
}
